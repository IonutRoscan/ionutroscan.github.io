// Fetch ALL local image URLs from your extension folder
const bgDarkUrl = chrome.runtime.getURL("background.jpg");
const bgCuteUrl = chrome.runtime.getURL("bg-cute.jpg");
const cornerDarkUrl = chrome.runtime.getURL("corner.png");
const cornerCuteUrl = chrome.runtime.getURL("corner-cute.png");
const sigilUrl = chrome.runtime.getURL("sigil.png");
const mascotUrl = chrome.runtime.getURL("anime-chibi_dance.gif"); 
const splashDarkUrl = chrome.runtime.getURL("splash-dark.png");
const splashCuteUrl = chrome.runtime.getURL("splash-cute.png");

// Inject Custom Grimoire CSS with Variables and Splash Animations
const style = document.createElement('style');
style.innerHTML = `
  @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&display=swap');
  
  :root {
    --g-bg-image: url('${bgDarkUrl}');
    --g-corner-image: url('${cornerDarkUrl}');
    --g-primary-color: #a67c00;
    --g-accent-color: #8e2de2;
    --g-text-color: #e6dcb8;
    --g-border-color: rgba(142, 45, 226, 0.4);
    --g-glow: rgba(166, 124, 0, 0.4);
    --g-input-bg: rgba(5, 3, 8, 0.8);
    --g-sigil-filter: none;
    --g-blend-mode: multiply;
    --g-btn-bg: rgba(0, 0, 0, 0.4);
    --g-btn-hover-bg: rgba(166, 124, 0, 0.3);
    --g-btn-hover-text: #fff;
  }

  .theme-cute {
    --g-bg-image: url('${bgCuteUrl}');
    --g-corner-image: url('${cornerCuteUrl}');
    --g-primary-color: #c44569;      /* Deeper rose pink for high contrast titles/buttons */
    --g-accent-color: #8a4b66;       /* Dark mauve for tags and subtext */
    --g-text-color: #301e28;         /* Very dark plum for the main input text */
    --g-border-color: rgba(196, 69, 105, 0.5);
    --g-glow: rgba(196, 69, 105, 0.3);
    --g-input-bg: rgba(255, 255, 255, 0.88); /* More solid white to block the busy paper texture */
    --g-sigil-filter: sepia(100%) hue-rotate(300deg) saturate(200%) opacity(0.12);
    --g-blend-mode: normal;
    --g-btn-bg: rgba(255, 255, 255, 0.65); /* Soft frosted white for the button */
    --g-btn-hover-bg: #c44569;       /* Solid rose pink on hover */
    --g-btn-hover-text: #ffffff;
  }
  
  @keyframes swoopin {
    0% { opacity: 0; transform: translateX(120%) translateY(20px) rotate(5deg); }
    100% { opacity: 1; transform: translateX(0) translateY(0) rotate(0); }
  }

  @keyframes splash-fade {
    0% { opacity: 1; filter: blur(0); transform: scale(1); }
    100% { opacity: 0; filter: blur(20px); transform: scale(1.1); pointer-events: none; }
  }

  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-5px); }
  }
  
  #grimoire-splash {
    position: fixed;
    top: 0; left: 0; width: 100vw; height: 100vh;
    background: rgba(10, 5, 12, 0.9);
    backdrop-filter: blur(8px);
    z-index: 9999999;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 40px;
    font-family: 'Cinzel', serif;
    color: #e6dcb8;
    transition: all 0.8s ease;
  }

  #grimoire-splash.hidden {
    animation: splash-fade 0.8s forwards;
  }

  .splash-title {
    font-size: 32px;
    letter-spacing: 6px;
    text-shadow: 0 0 15px rgba(166, 124, 0, 0.6);
  }

  .splash-options {
    display: flex;
    gap: 60px;
  }

  .splash-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.2, 0.8, 0.2, 1);
  }

  .splash-btn:hover {
    transform: scale(1.1) translateY(-10px);
  }

  .splash-btn img {
    width: 200px;
    height: 200px;
    object-fit: contain;
    filter: drop-shadow(0 10px 20px rgba(0,0,0,0.8));
    animation: float 4s infinite ease-in-out;
  }

  .splash-btn.cute img {
    animation-delay: -2s;
  }

  .splash-btn span {
    font-size: 14px;
    letter-spacing: 3px;
    color: inherit;
    text-transform: uppercase;
  }

  #grimoire-panel {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 380px;
    background-color: rgba(15, 12, 18, 0.95);
    background-image: var(--g-bg-image);
    background-size: cover;
    background-position: center;
    background-blend-mode: var(--g-blend-mode); 
    border: 1px solid var(--g-border-color);
    border-top: 2px solid var(--g-primary-color);
    border-bottom: 2px solid var(--g-primary-color);
    border-radius: 4px;
    padding: 22px;
    z-index: 999999;
    color: var(--g-text-color);
    font-family: 'Cormorant Garamond', serif;
    display: none; 
  }

  #grimoire-panel.visible {
    display: block;
    animation: swoopin 0.8s cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
  }
  
  #grimoire-panel.casting {
    border-color: #df00ff;
    box-shadow: 0 0 40px rgba(142, 45, 226, 0.3), inset 0 0 30px rgba(142, 45, 226, 0.2);
  }

  #grimoire-mascot {
    position: absolute;
    top: -75px; 
    left: 50%; 
    transform: translateX(-50%); 
    height: 80px; 
    pointer-events: none;
    z-index: 20;
    filter: drop-shadow(0px 4px 6px rgba(0,0,0,0.5)); 
  }

  .gothic-corner {
    position: absolute;
    width: 60px; 
    height: 60px;
    background-image: var(--g-corner-image);
    background-size: contain;
    background-repeat: no-repeat;
    pointer-events: none; 
    z-index: 10;
  }
  
  .corner-tl { top: -4px; left: -4px; }
  .corner-tr { top: -4px; right: -4px; transform: scaleX(-1); } 
  .corner-bl { bottom: -4px; left: -4px; transform: scaleY(-1); } 
  .corner-br { bottom: -4px; right: -4px; transform: scaleX(-1) scaleY(-1); } 
  
  #grimoire-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--g-glow);
    padding-bottom: 10px;
    margin-bottom: 15px;
    position: relative;
    z-index: 2;
  }
  
  #grimoire-title {
    margin: 0;
    font-size: 24px;
    color: var(--g-primary-color);
    font-family: 'Cinzel', serif; 
    letter-spacing: 4px;
    text-shadow: 0 0 10px var(--g-glow);
  }
  
  #grimoire-tag {
    font-size: 13px;
    color: var(--g-accent-color);
    font-style: italic;
    opacity: 0.9;
  }

  #file-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    position: relative;
    z-index: 2;
  }

  #file-label {
    font-size: 14px;
    color: var(--g-primary-color);
    font-style: italic;
    letter-spacing: 1px;
  }

  #browse-btn {
    font-size: 12px;
    color: var(--g-accent-color);
    cursor: pointer;
    font-family: 'Cinzel', serif;
    letter-spacing: 2px;
    transition: all 0.3s;
    border-bottom: 1px dashed transparent;
  }

  #browse-btn:hover {
    color: var(--g-text-color);
    border-bottom: 1px dashed var(--g-text-color);
  }

  #speed-control {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    position: relative;
    z-index: 2;
  }

  #speed-label {
    font-size: 12px;
    color: var(--g-accent-color);
    font-family: 'Cinzel', serif;
    letter-spacing: 1px;
    display: flex; 
    flex-direction: column; 
    gap: 2px;
  }

  #speed-slider {
    width: 140px;
    accent-color: var(--g-primary-color);
    cursor: pointer;
  }
  
  .input-wrapper {
    position: relative;
    overflow: hidden;
    border-radius: 4px;
    background: var(--g-input-bg);
    border: 1px solid var(--g-border-color);
    transition: all 0.4s ease;
    z-index: 2;
  }

  .input-wrapper:focus-within, .input-wrapper.drag-over {
    border-color: var(--g-primary-color);
    box-shadow: inset 0 0 20px var(--g-glow);
  }

  .magic-sigil {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 90px;
    height: 90px;
    background-image: url('${sigilUrl}');
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    pointer-events: none;
    z-index: 1;
    opacity: 0.2;
    filter: var(--g-sigil-filter);
    transition: all 0.5s cubic-bezier(0.2, 0.8, 0.2, 1);
  }

  .input-wrapper:focus-within .magic-sigil, 
  .input-wrapper.drag-over .magic-sigil {
    opacity: 0.7;
    width: 130px;
    height: 130px;
  }
  
  #md-input {
    position: relative;
    width: 100%;
    height: 140px;
    background: transparent; 
    color: var(--g-text-color);
    border: none;
    padding: 15px;
    box-sizing: border-box;
    font-family: 'Cormorant Garamond', serif;
    font-size: 16px;
    line-height: 1.4;
    resize: none;
    outline: none;
    z-index: 2;
  }
  
  #md-input::placeholder {
    color: var(--g-text-color);
    opacity: 0.65;
    font-style: italic;
  }
  
  #start-import {
    width: 100%;
    margin-top: 18px;
    padding: 12px;
    background: var(--g-btn-bg);
    color: var(--g-primary-color);
    border: 1px solid var(--g-primary-color);
    border-radius: 3px;
    cursor: pointer;
    font-family: 'Cinzel', serif;
    font-weight: 600;
    font-size: 16px;
    letter-spacing: 3px;
    transition: all 0.3s ease;
    text-transform: uppercase;
    position: relative;
    z-index: 2;
  }
  
  #start-import:hover {
    background: var(--g-btn-hover-bg);
    color: var(--g-btn-hover-text);
    box-shadow: 0 0 15px var(--g-glow);
  }
  
  #start-import:active {
    transform: scale(0.98);
  }
  
  #import-status {
    font-size: 15px;
    color: var(--g-accent-color);
    margin-bottom: 0;
    margin-top: 15px;
    text-align: center;
    min-height: 18px;
    font-style: italic;
    position: relative;
    z-index: 2;
  }

  #grimoire-warning {
    position: fixed;
    bottom: 320px;          
    right: 20px;
    width: 380px;
    z-index: 1000000;
    pointer-events: none;
    opacity: 0;
    transform: translateY(12px);
    transition: opacity 0.35s ease, transform 0.35s ease;
    font-family: 'Cormorant Garamond', serif;
  }

  #grimoire-warning.visible {
    opacity: 1;
    transform: translateY(0);
  }

  #grimoire-warning .warning-inner {
    background: rgba(25, 8, 12, 0.95);
    border: 1px solid rgba(166, 60, 60, 0.6);
    border-top: 2px solid #a63c3c;
    border-bottom: 2px solid #a63c3c;
    border-radius: 4px;
    padding: 14px 18px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.7),
                inset 0 0 20px rgba(166, 60, 60, 0.15);
    color: #e6dcb8;
  }
`;
document.head.appendChild(style);

// !THE MASTER CLOAK (SPA Router Protection)!
const masterContainer = document.createElement('div');
masterContainer.id = "grimoire-master";
masterContainer.style.display = "none";
document.body.appendChild(masterContainer);

// Create the Splash Screen UI
const splash = document.createElement('div');
splash.id = 'grimoire-splash';
splash.innerHTML = `
  <div class="splash-title">SUMMON YOUR TOME</div>
  <div class="splash-options">
    <div class="splash-btn dark" id="btn-dark">
      <img src="${splashDarkUrl}" alt="Abyssal Grimoire">
      <span style="color: #a67c00;">Abyssal Grimoire</span>
    </div>
    <div class="splash-btn cute" id="btn-cute">
      <img src="${splashCuteUrl}" alt="Celestial Diary">
      <span style="color: #ffb7b2;">Celestial Diary</span>
    </div>
  </div>
`;
masterContainer.appendChild(splash);

// Create the main Panel UI
const panel = document.createElement('div');
panel.id = 'grimoire-panel';
panel.innerHTML = `
  <img id="grimoire-mascot" src="${mascotUrl}" alt="Dancing Chibi">
  <div class="gothic-corner corner-tl"></div>
  <div class="gothic-corner corner-tr"></div>
  <div class="gothic-corner corner-bl"></div>
  <div class="gothic-corner corner-br"></div>

  <div id="grimoire-header">
    <h3 id="grimoire-title">GRIMOIRE</h3>
    <span id="grimoire-tag">made by SaltSaaalt</span>
  </div>
  <div id="file-controls">
    <span id="file-label">Arcane Source</span>
    <span id="browse-btn">[ SUMMON TOME ]</span>
    <input type="file" id="file-input" accept=".md,.txt" style="display: none;">
  </div>
  <div id="speed-control">
    <span id="speed-label">
      Ritual Pace
      <span style="font-size: 9px; opacity: 0.6; font-family: sans-serif; letter-spacing: 0; text-transform: none;">(don't touch unless too much skipping occurs. Best if left on default value (as is) and filled by hand what remains!)</span>
    </span>
    <input type="range" id="speed-slider" min="1" max="3" step="0.5" value="1" title="Increase to slow down the injection speed for better stability">
  </div>
  <div class="input-wrapper" id="drop-wrapper">
    <div class="magic-sigil"></div>
    <textarea id="md-input" placeholder="Inscribe raw lore here, or drop a .md / .txt tome directly into the void...&#10;&#10;Format Example:&#10;Title: Dunmoor Valley&#10;Keywords: region, valley, Millstone Valley&#10;Content: The rural farming region...&#10;&#10;Title: Fria&#10;Keywords: Queen of Chaos, protagonist&#10;Content: The main character..."></textarea>
  </div>
  <button id="start-import">Bind Lore</button>
  <p id="import-status">Awaiting incantation...</p>
`;
masterContainer.appendChild(panel);

// Warning overlay
const warning = document.createElement('div');
warning.id = 'grimoire-warning';
warning.innerHTML = `
  <div class="warning-inner">
    <span class="warning-icon" style="font-size: 22px; color: #ff6b6b; text-shadow: 0 0 8px rgba(255, 80, 80, 0.6);">⚠</span>
    <div class="warning-text" style="font-size: 15px; line-height: 1.35;">
      <strong style="font-family: 'Cinzel', serif; letter-spacing: 2px; color: #ff8a8a; font-size: 14px;">RITUAL IN PROGRESS</strong><br>
      Do not click, move the mouse, or press any keys<br>
      until the ritual finishes.
    </div>
  </div>
`;
masterContainer.appendChild(warning);

// Global State Variables
let isCasting = false;
let cancelRequested = false;

// URL TRACKER LOGIC
function checkVisibility() {
  const isLorebookTab = window.location.pathname.includes('your-characters') && window.location.search.includes('tab=lorebooks');
  
  if (isLorebookTab) {
    masterContainer.style.display = 'block';
  } else {
    masterContainer.style.display = 'none';
    // Safety Kill Switch: Abort if user navigates away while casting
    if (isCasting && !cancelRequested) {
      cancelRequested = true;
      const startBtn = document.getElementById('start-import');
      if (startBtn) startBtn.innerText = "HALTING...";
    }
  }
}
// Check immediately, then every 500ms
checkVisibility();
setInterval(checkVisibility, 500);


// Theme Selection & Entrance Logic
document.getElementById('btn-dark').addEventListener('click', () => {
  launchGrimoire('dark');
});

document.getElementById('btn-cute').addEventListener('click', () => {
  launchGrimoire('cute');
});

function launchGrimoire(theme) {
  if (theme === 'cute') {
    panel.classList.add('theme-cute');
    document.getElementById('grimoire-title').innerText = "DIARY";
  }
  
  splash.classList.add('hidden');
  
  setTimeout(() => {
    splash.remove(); 
    panel.classList.add('visible');
  }, 600);
}

// File Loading Logic 
const dropWrapper = document.getElementById('drop-wrapper');
const mdInput = document.getElementById('md-input');
const fileInput = document.getElementById('file-input');
const browseBtn = document.getElementById('browse-btn');
const statusText = document.getElementById('import-status');

browseBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', (e) => { if (e.target.files.length > 0) readLoreFile(e.target.files[0]); });
mdInput.addEventListener('dragover', (e) => { e.preventDefault(); dropWrapper.classList.add('drag-over'); });
mdInput.addEventListener('dragleave', (e) => { e.preventDefault(); dropWrapper.classList.remove('drag-over'); });
mdInput.addEventListener('drop', (e) => {
  e.preventDefault();
  dropWrapper.classList.remove('drag-over');
  if (e.dataTransfer.files.length > 0) {
    const file = e.dataTransfer.files[0];
    if (file.name.endsWith('.md') || file.name.endsWith('.txt')) {
      readLoreFile(file);
    } else {
      statusText.innerText = "Invalid artifact. Only .md or .txt accepted.";
    }
  }
});

function readLoreFile(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    mdInput.value = e.target.result;
    statusText.innerText = `Tome '${file.name}' deciphered.`;
  };
  reader.readAsText(file);
}

// CDP Coordinate Injection Helpers
function sleep(ms) {
  const speedSlider = document.getElementById('speed-slider');
  const multiplier = speedSlider ? parseFloat(speedSlider.value) : 1;
  return new Promise(r => setTimeout(r, ms * multiplier));
}

async function sendDebugger(action, payload = {}) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action, ...payload }, resolve);
  });
}

function scrollEntriesToBottom() {
  const anyEntry = document.querySelector('input[placeholder="entry title (required)"]')
    || document.querySelector('button'); 
  if (!anyEntry) return;

  let el = anyEntry;
  while (el && el !== document.body) {
    const style = window.getComputedStyle(el);
    if (/(auto|scroll)/.test(style.overflowY) && el.scrollHeight > el.clientHeight + 50) {
      el.scrollTop = el.scrollHeight;
      return;
    }
    el = el.parentElement;
  }
  window.scrollTo(0, document.body.scrollHeight);
}

async function realFocus(element) {
  if (!element) return;
  scrollEntriesToBottom();
  element.scrollIntoView({ behavior: "instant", block: "center" });
  await sleep(150);

  const rect = element.getBoundingClientRect();
  if (rect.width < 5 || rect.height < 5 || rect.top < 0) {
    scrollEntriesToBottom();
    element.scrollIntoView({ behavior: "instant", block: "center" });
    await sleep(250);
    const rect2 = element.getBoundingClientRect();
    if (rect2.width < 5 || rect2.height < 5) return; 
  }

  const x = Math.round(rect.left + rect.width / 2);
  const y = Math.round(rect.top + rect.height / 2);

  await sendDebugger("clickAt", { x, y });
  await sleep(100);

  element.focus({ preventScroll: true });
  await sleep(60);
}

async function injectTextCDP(element, text) {
  if (!element || cancelRequested) return;

  await realFocus(element);

  await sendDebugger("insertText", { text });
  await sleep(120);

  element.dispatchEvent(new Event("input",  { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
  element.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
  await sleep(220);
}

async function confirmCurrentEntry(titleInput) {
  if (!titleInput || cancelRequested) return;

  let card = titleInput;
  for (let i = 0; i < 6 && card; i++) {
    card = card.parentElement;
    if (!card) break;
    const btns = card.querySelectorAll("button");
    if (btns.length >= 2) break;
  }
  if (!card) return;

  const buttons = Array.from(card.querySelectorAll("button"));
  const checkBtn = buttons.find(b => {
    const html = b.innerHTML.toLowerCase();
    return !html.includes("trash") && !html.includes("delete") && !html.includes("remove");
  }) || buttons[0];

  if (checkBtn) {
    await realFocus(checkBtn);
    checkBtn.click();
    await sleep(450);
  }
}

// Execution Logic with KILL SWITCH
document.getElementById('start-import').addEventListener('click', async () => {
  const startBtn = document.getElementById('start-import');
  
  if (isCasting) {
    cancelRequested = true;
    startBtn.innerText = "HALTING...";
    startBtn.style.color = "#a63c3c";
    startBtn.style.borderColor = "#a63c3c";
    document.getElementById('grimoire-warning').classList.remove('visible');
    return; 
  }

  const text = mdInput.value;
  const entries = [];
  const regex = /Title:\s*(.*?)\r?\nKeywords:\s*(.*?)\r?\nContent:\s*([\s\S]*?)(?=\r?\nTitle:|$)/g;
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    entries.push({ title: match[1].trim(), keywords: match[2].trim(), content: match[3].trim() });
  }

  if (entries.length === 0) {
    statusText.innerText = "The incantation is malformed. Check syntax.";
    return;
  }

  const attachRes = await sendDebugger("attach");
  if (attachRes && attachRes.status === "error") {
    statusText.innerText = "Error: Cannot attach magic to this tab.";
    return;
  }

  isCasting = true;
  cancelRequested = false;
  panel.classList.add('casting');
  
  document.getElementById('grimoire-warning').classList.add('visible');
  startBtn.innerText = "STOP RITUAL";

  for (let i = 0; i < entries.length; i++) {
    if (cancelRequested) break;
    const entry = entries[i];
    statusText.innerText = `Inscribing ${i + 1}/${entries.length}: ${entry.title}`;

    scrollEntriesToBottom();
    await sleep(200);

    const buttons = Array.from(document.querySelectorAll("button"));
    const newEntryBtn = buttons.find(b => b.innerText.trim().includes("New entry"));
    if (!newEntryBtn) {
      statusText.innerText = "Ritual interrupted: '+ New entry' button missing.";
      break;
    }

    const titleCountBefore = document.querySelectorAll('input[placeholder="entry title (required)"]').length;
    newEntryBtn.click();

    let lastTitle = null;
    for (let attempt = 0; attempt < 50; attempt++) {
      if (cancelRequested) break;
      const titles = document.querySelectorAll('input[placeholder="entry title (required)"]');
      if (titles.length > titleCountBefore) {
        lastTitle = titles[titles.length - 1];
        const hasError = lastTitle.parentElement?.textContent?.includes("Entry title is required") ||
                         lastTitle.closest("div")?.textContent?.includes("Entry title is required");
        if (hasError || lastTitle.offsetParent) break;
      }
      await sleep(120);
    }

    if (!lastTitle || cancelRequested) {
      statusText.innerText = `Could not locate new title field for entry ${i + 1}.`;
      break;
    }

    await sleep(450);
    scrollEntriesToBottom();

    try {
      await injectTextCDP(lastTitle, entry.title);
      await sleep(450);

      if (cancelRequested) break;

      await sendDebugger("key", { key: "Tab", code: "Tab", keyCode: 9 });
      await sleep(280);

      await sendDebugger("insertText", { text: entry.keywords });
      await sleep(200);
      const active1 = document.activeElement;
      if (active1) {
        active1.dispatchEvent(new Event("input",  { bubbles: true }));
        active1.dispatchEvent(new Event("change", { bubbles: true }));
      }
      await sleep(280);

      if (cancelRequested) break;

      await sendDebugger("key", { key: "Tab", code: "Tab", keyCode: 9 });
      await sleep(280);

      await sendDebugger("insertText", { text: entry.content });
      await sleep(200);
      const active2 = document.activeElement;
      if (active2) {
        active2.dispatchEvent(new Event("input",  { bubbles: true }));
        active2.dispatchEvent(new Event("change", { bubbles: true }));
      }
      await sleep(550);

      const titlesNow = document.querySelectorAll('input[placeholder="entry title (required)"]');
      const currentTitle = titlesNow[titlesNow.length - 1] || lastTitle;
      await confirmCurrentEntry(currentTitle);
      await sleep(450);

    } catch (err) {
      statusText.innerText = `Corruption at block ${i + 1}. Halting.`;
      console.error(err);
      break;
    }
  } 

  await sendDebugger("detach");
  document.getElementById('grimoire-warning').classList.remove('visible');

  isCasting = false;
  cancelRequested = false;
  panel.classList.remove('casting');
  startBtn.innerText = "Bind Lore";
  startBtn.style.color = "var(--g-primary-color)";
  startBtn.style.borderColor = "var(--g-border-color)";

  if (!statusText.innerText.includes("Halting") &&
      !statusText.innerText.includes("mismatch") &&
      !statusText.innerText.includes("interrupted") &&
      !statusText.innerText.includes("Could not locate")) {
    if (statusText.innerText.includes("Inscribing")) {
      statusText.innerText = "Lore bound successfully. Review your entries.";
    } else {
      statusText.innerText = "Ritual aborted safely.";
    }
  }
});