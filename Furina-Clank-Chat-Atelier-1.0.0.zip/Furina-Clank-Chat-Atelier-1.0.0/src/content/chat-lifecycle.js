"use strict";

(() => {

    if (
        window.top !== window
    ) {
        return;
    }


    // ── NAMESPACE ─────────────────────────────────────────────────

    const Atelier =
        window.ClankAtelier;


    if (
        !Atelier ||
        !Atelier.SELECTORS
    ) {

        console.error(
            "[Clank Atelier] Core modules missing."
        );

        return;

    }


    const SELECTORS =
        Atelier.SELECTORS;
    
    /*
        Chat Lifecycle

        Clank is a single-page app. Opening another conversation usually does
        not reload this content script, so this module watches the current chat
        DOM, tags message parts for the renderer/theme CSS, and asks each
        feature manager to switch to the new conversation when the route changes.
    */

    // ── CHAT LIFECYCLE STATE ─────────────────────────────────────────────────────

    let chatObserver =
        null;

    let currentChat =
        null;
    let chatActive =
        false;


    // ── RENDER SCHEDULER ──────────────────────────────────────────

    const renderTimers =
        new WeakMap();


    function scheduleRender(
        message,
        delay = 70
    ) {

        if (
            !(message instanceof HTMLElement)
        ) {
            return;
        }


        const previous =
            renderTimers.get(
                message
            );


        if (previous) {

            clearTimeout(
                previous
            );

        }


        const timer =
            setTimeout(
                () => {

                    renderTimers.delete(
                        message
                    );


                    if (
                        !message.isConnected
                    ) {
                        return;
                    }


                    tagMessageBody(
                        message
                    );

                    tagAvatar(
                        message
                    );

                    tagMessageActions(
                        message
                    );


                    if (
                        typeof Atelier.renderMessage ===
                        "function"
                    ) {

                        Atelier.renderMessage(
                            message
                        );

                    }

                },
                delay
            );


        renderTimers.set(
            message,
            timer
        );

    }

    // ── MESSAGE CLASSIFICATION ────────────────────────────────────

    function classifyMessage(
        element
    ) {

        if (
            !(element instanceof HTMLElement)
        ) {
            return;
        }


        if (
            element.matches(
                SELECTORS.assistantMessage
            )
        ) {

            element.classList.add(
                "clank-atelier-message",
                "clank-atelier-message-assistant"
            );

            return "assistant";

        }


        if (
            element.matches(
                SELECTORS.userMessage
            )
        ) {

            element.classList.add(
                "clank-atelier-message",
                "clank-atelier-message-user"
            );

            return "user";

        }


        /*
            Resilience fallback for small Clank Tailwind changes.
            Keep it deliberately narrow: only direct chat children
            with a message-like body and row direction qualify.
        */

        const isDirectChatChild =
            currentChat &&
            element.parentElement ===
                currentChat;


        const hasMessageBody =
            Boolean(
                element.querySelector(
                    SELECTORS.messageBody
                ) ||
                element.querySelector(
                    "div.break-words"
                )
            );


        if (
            isDirectChatChild &&
            hasMessageBody
        ) {

            if (
                element.classList.contains(
                    "flex-row-reverse"
                )
            ) {

                element.classList.add(
                    "clank-atelier-message",
                    "clank-atelier-message-user"
                );

                return "user";

            }


            if (
                element.classList.contains(
                    "flex-row"
                )
            ) {

                element.classList.add(
                    "clank-atelier-message",
                    "clank-atelier-message-assistant"
                );

                return "assistant";

            }

        }


        return null;

    }


    // ── MESSAGE BODY ──────────────────────────────────────────────

    function tagMessageBody(
        message
    ) {

        const body =
            message.querySelector(
                SELECTORS.messageBody
            ) ||
            message.querySelector(
                "div.break-words"
            );


        if (!body) {
            return;
        }


        body.classList.add(
            "clank-atelier-message-body"
        );

        // ── NATIVE USER BUBBLE ────────────────────────────────────────

        if (
            message.classList.contains(
                "clank-atelier-message-user"
            )
        ) {

            const nativeBubble =
                body.parentElement;


            if (nativeBubble) {

                nativeBubble.classList.add(
                    "clank-atelier-user-bubble"
                );

            }

        }


        let paragraphs =
            body.querySelectorAll(
                SELECTORS.messageParagraph
            );


        if (
            paragraphs.length ===
            0
        ) {

            paragraphs =
                body.querySelectorAll(
                    "p"
                );

        }


        paragraphs.forEach(
            paragraph => {

                paragraph.classList.add(
                    "clank-atelier-paragraph"
                );

            }
        );

    }

    // ── AVATAR ────────────────────────────────────────────────────

    function tagAvatar(
        message
    ) {

        if (
            !(message instanceof HTMLElement)
        ) {
            return;
        }


        /*
            Find images belonging to the message row,
            but never images inside the actual message
            content / Furina renderer.
        */

        const images =
            message.querySelectorAll(
                "img"
            );


        for (
            const image
            of images
        ) {

            if (
                image.closest(
                    ".clank-atelier-message-body"
                )
            ) {
                continue;
            }


            if (
                image.closest(
                    ".clank-atelier-rendered"
                )
            ) {
                continue;
            }


            image.classList.add(
                "clank-atelier-avatar"
            );


            /*
                A message only has one actual avatar,
                so once we've found it we're done.
            */

            break;

        }

    }

    // ── Message actions ───────────────────────────────────────────

    function tagMessageActions(
        message
    ) {

        if (
            !(message instanceof HTMLElement)
        ) {
            return;
        }


        const actionButton =
            message.querySelector(
                [
                    'button[aria-label="Edit message"]',
                    'button[aria-label="Continue"]',
                    'button[aria-label="Continue as new message"]',
                    'button[aria-label="Continue as new message with direction"]',
                    'button[aria-label="Report bad response"]',
                    'button[aria-label="Like"]',
                    'button[aria-label="Previous"]',
                    'button[aria-label="Next"]'
                ].join(",")
            );


        if (!actionButton) {
            return;
        }


        /*
            Clank places the message controls inside one shared wrapper.
            Walk upward from a known action until we reach the smallest
            container that owns multiple message buttons.
        */

        let actions =
            actionButton.parentElement;


        while (
            actions &&
            actions !== message
        ) {

        if (
            actions.querySelectorAll(
                "button"
            ).length >= 2
        ) {

            actions.classList.add(
                "clank-atelier-message-actions"
            );


            return;

        }


        actions =
            actions.parentElement;

    }

}

    // ── PROCESS MESSAGE ───────────────────────────────────────────

    function processMessage(
        element,
        animateEntrance = false
    ) {

        if (
            !(element instanceof HTMLElement)
        ) {
            return;
        }


        if (
            element.dataset
                .clankAtelierProcessed ===
            "true"
        ) {
            return;
        }


        const type =
            classifyMessage(
                element
            );


        if (!type) {
            return;
        }


        tagMessageBody(
            element
        );

        tagAvatar(
            element
        );

        tagMessageActions(
            element
        );

        scheduleRender(
            element,
            0
        );


        if (
            Atelier.CosmeticsManager &&
            typeof Atelier.CosmeticsManager.decorateMessage ===
                "function"
        ) {

            Atelier.CosmeticsManager.decorateMessage(
                element,
                animateEntrance
            );

        }


        element.dataset
            .clankAtelierProcessed =
            "true";


    }


    // ── PROCESS CHAT ──────────────────────────────────────────────

    function processExistingMessages() {

        if (!currentChat) {
            return;
        }


        const children =
            Array.from(
                currentChat.children
            );


        for (
            const child
            of children
        ) {

            processMessage(
                child
            );

        }

    }


    // ── COMPOSER ──────────────────────────────────────────────────

    function processComposer() {

        const textarea =
            document.querySelector(
                SELECTORS.composer
            ) ||
            document.querySelector(
                ".clank-atelier-chat-shell form textarea"
            );


        if (!textarea) {
            return;
        }


        textarea.classList.add(
            "clank-atelier-composer"
        );


        const form =
            textarea.closest(
                "form"
            );


        if (form) {

            form.classList.add(
                "clank-atelier-composer-form"
            );

        }


        if (
            Atelier.DirectorManager
        ) {

            Atelier.DirectorManager
                .attachComposer(
                    textarea
                );

        }

    }


    // ── CHAT OBSERVER ─────────────────────────────────────────────

    function startChatObserver() {

        if (
            !currentChat
        ) {
            return;
        }


        if (
            chatObserver
        ) {

            chatObserver.disconnect();

        }


        chatObserver =
            new MutationObserver(
                mutations => {

                    const messagesToUpdate =
                        new Set();


                    for (
                        const mutation
                        of mutations
                    ) {

                        // ── IGNORE FURINA'S OWN OUTPUT ────────────────────────────────

                        let mutationElement =
                            mutation.target;


                        if (
                            mutationElement.nodeType ===
                            Node.TEXT_NODE
                        ) {

                            mutationElement =
                                mutationElement.parentElement;

                        }


                        if (
                            mutationElement instanceof HTMLElement &&
                            mutationElement.closest(
                                ".clank-atelier-rendered"
                            )
                        ) {

                            continue;

                        }


                        // ── ADDED NODES ───────────────────────────────────────────────

                        for (
                            const node
                            of mutation.addedNodes
                        ) {

                            if (
                                !(node instanceof HTMLElement)
                            ) {
                                continue;
                            }


                            if (
                                node.matches(
                                    ".clank-atelier-rendered"
                                ) ||
                                node.closest(
                                    ".clank-atelier-rendered"
                                )
                            ) {

                                continue;

                            }


                            // ------------------------------------------------
                            // ENTIRE NEW MESSAGE
                            // ------------------------------------------------

                            if (
                                node.matches(
                                    SELECTORS.assistantMessage
                                ) ||
                                node.matches(
                                    SELECTORS.userMessage
                                )
                            ) {

                                processMessage(
                                    node,
                                    true
                                );


                                continue;

                            }


                            // ------------------------------------------------
                            // NESTED NEW MESSAGES
                            // ------------------------------------------------

                            const nestedMessages =
                                node.querySelectorAll(
                                    [
                                        SELECTORS.assistantMessage,
                                        SELECTORS.userMessage
                                    ].join(",")
                                );


                            nestedMessages.forEach(
                                message =>
                                    processMessage(
                                        message,
                                        true
                                    )
                            );

                        }


                        // ── FIND EXISTING MESSAGE AFFECTED ────────────────────────────

                        let element =
                            mutation.target;


                        if (
                            element.nodeType ===
                            Node.TEXT_NODE
                        ) {

                            element =
                                element.parentElement;

                        }


                        if (
                            !(element instanceof HTMLElement)
                        ) {
                            continue;
                        }


                        const message =
                            element.closest(
                                ".clank-atelier-message"
                            );


                        if (message) {

                            messagesToUpdate.add(
                                message
                            );

                        }

                    }


                    // ── SCHEDULE AFFECTED MESSAGES ────────────────────────────────

                    for (
                        const message
                        of messagesToUpdate
                    ) {

                        /*
                            70ms is enough to combine streaming DOM updates
                            without making the visible output feel delayed.
                        */

                        scheduleRender(
                            message,
                            70
                        );

                    }

                }
            );


        chatObserver.observe(
            currentChat,
            {

                childList:
                    true,

                subtree:
                    true,

                characterData:
                    true

            }
        );


    }


    // ── ROUTE STATE ───────────────────────────────────────────────

    function isChatRoute() {

        return (
            window.location.pathname
                .startsWith(
                    "/chat/"
                )
        );

    }


    function deactivateChat() {

        if (
            chatObserver
        ) {

            chatObserver.disconnect();

        }


        chatObserver =
            null;


        currentChat =
            null;
        
        if (
            Atelier.StickerManager
        ) {

            Atelier.StickerManager
                .conversationId =
                null;


            Atelier.StickerManager
                .stickers =
                [];


            Atelier.StickerManager
                .setEditing(
                    false
                );


            if (
                Atelier.StickerManager
                    .layer
            ) {

                Atelier.StickerManager
                    .layer
                    .remove();


                Atelier.StickerManager
                    .layer =
                    null;

            }

            if (
                Atelier.StickerManager
                    .fixedLayer
            ) {

                Atelier.StickerManager
                    .fixedLayer
                    .remove();


                Atelier.StickerManager
                    .fixedLayer =
                    null;

            }

        }

        if (
            Atelier.AtmosphereManager
        ) {

            Atelier.AtmosphereManager.conversationId = null;
            Atelier.AtmosphereManager.settings =
                Atelier.AtmosphereManager.getDefaults();
            Atelier.AtmosphereManager.destroyLayer();

        }

        if (
            Atelier.AmbienceManager
        ) {

            Atelier.AmbienceManager
                .loadConversation(
                    null
                );

        }

        if (
            Atelier.ReaderManager
        ) {
            Atelier.ReaderManager
                .focusMode =
                false;

            Atelier.ReaderManager
                .conversationId =
                null;


            Atelier.ReaderManager
                .settings =
                Atelier.ReaderManager
                    .getDefaults();


            Atelier.ReaderManager
                .apply();

        }


        if (
            Atelier.DirectorManager
        ) {

            Atelier.DirectorManager
                .conversationId =
                null;


            Atelier.DirectorManager
                .settings =
                Atelier.DirectorManager
                    .getDefaults();

        }


        if (
            Atelier.AdvancedCssManager
        ) {

            Atelier.AdvancedCssManager
                .loadConversation(
                    null
                );

        }

        chatActive =
            false;


        document.documentElement
            .classList.remove(
                "clank-atelier-enabled"
            );
        
        if (
            Atelier.ThemeManager &&
            typeof Atelier.ThemeManager.clearVideoBackground ===
                "function"
        ) {

            Atelier.ThemeManager
                .clearVideoBackground();

        }

        if (
            Atelier.CosmeticsManager &&
            typeof Atelier.CosmeticsManager.leaveChat ===
                "function"
        ) {

            Atelier.CosmeticsManager.leaveChat();

        }

        document
            .querySelectorAll(
                ".clank-atelier-chat-shell"
            )
            .forEach(
                shell => {

                    shell.classList.remove(
                        "clank-atelier-chat-shell"
                    );

                }
            );


        document
            .querySelectorAll(
                ".clank-atelier-chat"
            )
            .forEach(
                chat => {

                    chat.classList.remove(
                        "clank-atelier-chat"
                    );

                }
            );


    }

    // ── Sidebar ───────────────────────────────────────────────────

    function tagSidebar() {

        const toggle =
            document.querySelector(
                [
                    'button[aria-label="Collapse sidebar"]',
                    'button[aria-label="Expand sidebar"]'
                ].join(",")
            );


        if (!toggle) {
            return;
        }


        const header =
            toggle.closest(
                "header"
            );


        if (!header) {
            return;
        }


        /*
            Current Clank structure:

            sidebar shell
                scroll container
                    header
                        collapse / expand button

            Tag the outer sidebar shell rather than depending on its
            Tailwind class string in Reader Mode CSS.
        */

        const sidebar =
            header.parentElement
                ?.parentElement;


        if (
            sidebar instanceof HTMLElement
        ) {

            sidebar.classList.add(
                "clank-atelier-sidebar"
            );


            /*
                The main conversation area is a sibling of Clank's sidebar.
                Tag it too so Reader Mode can reclaim the space normally
                reserved for the navigation column.
            */

            const layout =
                sidebar.parentElement;


            if (layout) {

                const mainContent =
                    Array.from(
                        layout.children
                    )
                        .find(
                            child => {

                                return (
                                    child instanceof HTMLElement &&
                                    child !== sidebar &&
                                    child.classList.contains(
                                        "flex-1"
                                    )
                                );

                            }
                        );


                if (
                    mainContent instanceof HTMLElement
                ) {

                    mainContent.classList.add(
                        "clank-atelier-main-content"
                    );

                }

            }

        }

    }

    // ── CHAT SHELL ────────────────────────────────────────────────

    function ensureChatShell() {

        if (
            !currentChat
        ) {
            return null;
        }


        let shell =
            currentChat.parentElement;


        while (
            shell &&
            shell !== document.body
        ) {

            if (
                shell.classList &&
                shell.classList.contains(
                    "group/layout"
                )
            ) {

                if (
                    !shell.classList.contains(
                        "clank-atelier-chat-shell"
                    )
                ) {

                    shell.classList.add(
                        "clank-atelier-chat-shell"
                    );


                }

                if (
                    Atelier.ThemeManager &&
                    typeof Atelier.ThemeManager.syncVideoBackground ===
                        "function"
                ) {

                    Atelier.ThemeManager
                        .syncVideoBackground(
                            shell
                        );

                }

                if (
                    Atelier.CosmeticsManager &&
                    typeof Atelier.CosmeticsManager.sync ===
                        "function"
                ) {

                    Atelier.CosmeticsManager.sync(
                        shell
                    );

                }

                return shell;

            }


            shell =
                shell.parentElement;

        }


        return null;

    }

    // ── INITIALIZE CHAT ───────────────────────────────────────────

    function initializeChat() {

        if (
            !isChatRoute()
        ) {

            if (
                chatActive ||
                currentChat
            ) {

                deactivateChat();

            }


            return false;

        }

        tagSidebar();

        const chat =
            document.querySelector(
                SELECTORS.chatScroller
            );


        if (!chat) {
            return false;
        }


        /*
            If we previously left a chat page,
            reactivate Furina when entering one again.
        */

        if (
            !chatActive
        ) {

            chatActive =
                true;


            if (
                Atelier.ThemeManager &&
                typeof Atelier.ThemeManager.apply ===
                "function"
            ) {

                Atelier.ThemeManager.apply();

            }

        }


        if (
            chat === currentChat
        ) {

            /*
                Clank may rebuild the surrounding layout
                when things such as the sidebar are toggled.

                The chat node can remain identical while its
                parent shell is replaced, so always verify
                the Furina shell here too.
            */

            const shell =
                ensureChatShell();


            if (
                Atelier.StickerManager
            ) {

                Atelier.StickerManager
                    .syncConversation(
                        shell
                    );

            }

            if (
                Atelier.ReaderManager
            ) {

                Atelier.ReaderManager
                    .syncConversation();

            }

            if (
                Atelier.DirectorManager
            ) {

                Atelier.DirectorManager
                    .syncConversation();

            }

        if (
            Atelier.AtmosphereManager
        ) {

            Atelier.AtmosphereManager
                .syncConversation(
                    shell
                );

        }

            if (
                Atelier.AmbienceManager
            ) {

                Atelier.AmbienceManager
                    .syncConversation();

            }

            if (
                Atelier.AdvancedCssManager
            ) {

                Atelier.AdvancedCssManager
                    .syncConversation();

            }

            processComposer();

            processExistingMessages();

            return true;

        }


        currentChat =
            chat;


        currentChat.classList.add(
            "clank-atelier-chat"
        );



        // ── CHAT SHELL ────────────────────────────────────────────────

        const shell =
            ensureChatShell();


        if (
            Atelier.StickerManager
        ) {

            Atelier.StickerManager
                .syncConversation(
                    shell
                );

        }

        if (
            Atelier.ReaderManager
        ) {

            Atelier.ReaderManager
                .syncConversation();

        }

        if (
            Atelier.DirectorManager
        ) {

            Atelier.DirectorManager
                .syncConversation();

        }

        if (
            Atelier.AtmosphereManager
        ) {

            Atelier.AtmosphereManager
                .syncConversation(
                    shell
                );

        }

        if (
            Atelier.AmbienceManager
        ) {

            Atelier.AmbienceManager
                .syncConversation();

        }

        if (
            Atelier.AdvancedCssManager
        ) {

            Atelier.AdvancedCssManager
                .syncConversation();

        }

        processExistingMessages();

        processComposer();

        startChatObserver();


        return true;

        }


    // ── PAGE / ROUTE OBSERVER ─────────────────────────────────────

    let lastPath =
        window.location.pathname;


    function syncPageState() {

        const currentPath =
            window.location.pathname;


        if (
            currentPath !== lastPath
        ) {

            lastPath =
                currentPath;


        }


        initializeChat();

    }


    let pageSyncScheduled =
        false;


    function schedulePageSync() {

        if (pageSyncScheduled) {
            return;
        }


        pageSyncScheduled =
            true;


        requestAnimationFrame(
            () => {

                pageSyncScheduled =
                    false;


                syncPageState();

            }
        );

    }


    function isFurinaOwnedMutationNode(
        node
    ) {

        let element =
            node;


        if (
            element?.nodeType ===
            Node.TEXT_NODE
        ) {

            element =
                element.parentElement;

        }


        if (
            !(element instanceof
                HTMLElement)
        ) {

            return false;

        }


        return Boolean(
            element.matches?.(
                [
                    '[data-furina-owned="true"]',
                    '[data-clank-atelier-owned="true"]',
                    "#furina-panel",
                    "#furina-launcher",
                    ".furina-ambience-player",
                    ".furina-atmosphere-layer",
                    ".furina-sticker-layer",
                    ".clank-atelier-lightbox",
                    ".clank-atelier-rendered"
                ].join(
                    ","
                )
            ) ||
            element.closest?.(
                [
                    '[data-furina-owned="true"]',
                    '[data-clank-atelier-owned="true"]',
                    "#furina-panel",
                    "#furina-launcher",
                    ".furina-ambience-player",
                    ".furina-atmosphere-layer",
                    ".furina-sticker-layer",
                    ".clank-atelier-lightbox",
                    ".clank-atelier-rendered"
                ].join(
                    ","
                )
            )
        );

    }


    function shouldSyncForMutations(
        records
    ) {

        return records.some(
            record => {

                if (
                    isFurinaOwnedMutationNode(
                        record.target
                    )
                ) {
                    return false;
                }


                const changedNodes = [
                    ...record.addedNodes,
                    ...record.removedNodes
                ];


                if (
                    changedNodes.length ===
                    0
                ) {
                    return true;
                }


                return changedNodes.some(
                    node =>
                        !isFurinaOwnedMutationNode(
                            node
                        )
                );

            }
        );

    }


    const pageObserver =
        new MutationObserver(
            records => {

                if (
                    shouldSyncForMutations(
                        records
                    )
                ) {

                    schedulePageSync();

                }

            }
        );


    pageObserver.observe(
        document.documentElement,
        {
            childList:
                true,

            subtree:
                true
        }
    );


    // ── HISTORY NAVIGATION ────────────────────────────────────────

    window.addEventListener(
        "keydown",
        event => {

            if (
                event.key !==
                "Escape"
            ) {
                return;
            }


            if (
                !Atelier.ReaderManager ||
                !Atelier.ReaderManager
                    .focusMode
            ) {
                return;
            }


            Atelier
                .ReaderManager
                .exitFocusMode();

        }
    );

    window.addEventListener(
        "popstate",
        syncPageState
    );


    // ── INITIAL ATTEMPT ───────────────────────────────────────────

    syncPageState();

})();