"use strict";

/*
    Furina Core Namespace

    Every Furina module shares one small global object named ClankAtelier.
    Modules attach their public managers and helper functions to this object
    instead of creating many unrelated globals on the page.

    Keeping this file tiny is intentional: it gives later files one reliable
    namespace without deciding which features must load first.
*/

window.ClankAtelier =
    window.ClankAtelier || {};

window.ClankAtelier.BUILD =
    "1.0.0";
