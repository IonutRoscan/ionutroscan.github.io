# Furina: Clank Chat Atelier

Furina is a client-side customization and roleplay utility layer for `clank.world` chat pages. Version **1.0.0** adds themed chat rendering, per-conversation visual settings, live/video wallpapers, cosmetic effects, Reader / Focus modes, stickers, Atmosphere effects, ambience controls, portable setups, Advanced CSS, and Director Notes without requiring a Furina backend.

## Install for testing / private sharing

1. Extract this folder somewhere permanent.
2. Open `chrome://extensions` in Chrome 118 or newer.
3. Enable **Developer mode**.
4. Choose **Load unpacked** and select the extracted Furina folder.
5. Open a `https://www.clank.world/chat/...` page.

The packaged ZIP itself must be extracted before using **Load unpacked**.

## Permissions and scope

- `storage`: saves Furina preferences using `chrome.storage.local`.
- `https://www.clank.world/*`: Furina is limited to Clank, and its content scripts only run on `/chat/*` pages.
- `src/features/ambience/soundcloud-bridge.js` is exposed only to `https://www.clank.world/*` so the SoundCloud widget can be controlled from the page context.

Furina does not include its own analytics, telemetry, advertising, or Furina-operated server API.

## Network behavior

The extension itself does not upload chat history to a Furina server. Network requests can still happen when a feature intentionally references third-party content:

- Markdown images, image/video chat backgrounds, stickers, and custom corner ornaments load the HTTP(S) URLs used in the conversation or supplied by the user.
- Direct ambience audio loads the URL supplied by the user.
- SoundCloud ambience embeds SoundCloud and uses SoundCloud's Widget API.
- Advanced CSS is user-authored; CSS such as `url(...)` can cause the browser to request that URL.

## Director Notes

When enabled for a conversation, Director Notes are inserted into the **actual outgoing message** before normal Clank sending. Furina-owned instructions begin with:

```text
ooc: furina-director:
[FURINA_DIRECTOR_NOTES]
...
[/FURINA_DIRECTOR_NOTES]
```

Furina hides only blocks containing its unique internal marker from its local rendered copy. Ordinary user-written `ooc:` messages are not hidden, and the underlying server-side message is not altered after sending.

Director Notes are not included in Full Setup export by default.

## Import / export safety

Theme and Full Setup imports are parsed as JSON and validated before preview or persistence. Imported URLs and numeric settings are restricted to the types/ranges Furina supports. A preview is temporary until **Keep Theme** / **Keep Setup** is chosen.


## Atelier Workspace

Furina's panel is organized as an application-style workspace instead of one long settings column:

- **Home** — current-chat status and quick resume
- **Look** — themes, chat presentation, messages, typography, cosmetic effects
- **Scene** — atmosphere, stickers, music, Reader / Focus, decorative layers
- **Director** — persistent RP guidance and continuity notes
- **Share** — theme/setup portability and presets
- **Tools** — Custom CSS, diagnostics, reset controls

The last workspace/tool is remembered when the panel closes or the page reloads. On narrow screens the desktop navigation rail becomes a horizontal strip.


## Cosmetic effects

The 1.0.0 build includes an optional visual-effects layer that remains theme-driven rather than creating a separate configuration system.

**Look → Effects** includes animated gradients, image/video wallpaper grading and mood presets, parallax, edge glow, message entrance animations, glass/texture bubbles, avatar frames/hover effects, speaker accents, panel glass/cursor styling, and the Furina accent sparkle.

**Scene → Decor** includes floating particles, decorative message separators, built-in/custom corner ornaments, and Screenshot Mode. Custom ornament images must use an HTTP(S) URL. Screenshot Mode is temporary and exits with `Esc`.

Motion-heavy effects respect `prefers-reduced-motion`, particles are capped, and the wallpaper implementation reuses a single native video element.

## Diagnostics

The **Copy DOM report** tool is an on-demand local diagnostic for Clank DOM changes. It only runs when the user presses the button. If clipboard access is unavailable, Furina no longer prints the report to the console.

## Browser compatibility

Chrome 118+ is required because Advanced CSS uses the native CSS `@scope` rule. Other Chromium browsers may work but are not declared as supported by this package.

## Chrome Web Store note

This package preserves the existing SoundCloud custom-player implementation, which dynamically loads SoundCloud's official remote Widget API in page context. Before submitting Furina to the Chrome Web Store, review or redesign that integration against the current Manifest V3 remotely-hosted-code policy. For unpacked/private testing, the feature remains functional as designed.

## Troubleshooting

If Clank changes its chat DOM, Furina may temporarily fail to recognize messages or the composer because those selectors deliberately target the current Clank structure. Use **Tools → Diagnostics → Copy DOM report** when diagnosing a site change.

If a SoundCloud track does not load, first verify the URL works in SoundCloud itself. Browser autoplay rules still require a user interaction before playback can begin.


## Source architecture

This build is modularized by responsibility. See [`ARCHITECTURE.md`](ARCHITECTURE.md) for the load order and module boundaries. The visible panel now uses the **Atelier Workspace** design: Home / Look / Scene / Director / Share / Tools, with only the active tool rendered at a time. See `ARCHITECTURE.md` for the workspace boundaries and load order.
