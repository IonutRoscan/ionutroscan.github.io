let attachedTabs = new Set();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  if (!tabId) return false;

  if (request.action === "attach") {
    if (!attachedTabs.has(tabId)) {
      chrome.debugger.attach({ tabId }, "1.3", () => {
        if (chrome.runtime.lastError) {
          sendResponse({ status: "error", message: chrome.runtime.lastError.message });
        } else {
          attachedTabs.add(tabId);
          sendResponse({ status: "attached" });
        }
      });
      return true;
    }
    sendResponse({ status: "already_attached" });
  }

  if (request.action === "detach") {
    if (attachedTabs.has(tabId)) {
      chrome.debugger.detach({ tabId }, () => {
        attachedTabs.delete(tabId);
        sendResponse({ status: "detached" });
      });
      return true;
    }
    sendResponse({ status: "not_attached" });
  }

  // Real mouse click at page coordinates forces OS-level focus
  if (request.action === "clickAt") {
    const { x, y } = request;
    const opts = { tabId };
    chrome.debugger.sendCommand(opts, "Input.dispatchMouseEvent", {
      type: "mousePressed", x, y, button: "left", clickCount: 1
    }, () => {
      chrome.debugger.sendCommand(opts, "Input.dispatchMouseEvent", {
        type: "mouseReleased", x, y, button: "left", clickCount: 1
      }, () => sendResponse({ status: "clicked" }));
    });
    return true;
  }

  // Bulk text insertion
  if (request.action === "insertText") {
    chrome.debugger.sendCommand(
      { tabId },
      "Input.insertText",
      { text: request.text },
      () => sendResponse({ status: "done" })
    );
    return true;
  }

  if (request.action === "key") {
    const { key, code, keyCode } = request;
    const opts = { tabId };
    chrome.debugger.sendCommand(opts, "Input.dispatchKeyEvent", {
      type: "keyDown", key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode
    }, () => {
      chrome.debugger.sendCommand(opts, "Input.dispatchKeyEvent", {
        type: "keyUp", key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode
      }, () => sendResponse({ status: "keyed" }));
    });
    return true;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => attachedTabs.delete(tabId));