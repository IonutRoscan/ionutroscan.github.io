# Daedalus: Clank Character Forge

Daedalus is a local creator IDE for ClankWorld's character creation page:

`https://www.clank.world/create`

It runs as a Manifest V3 browser extension and keeps unfinished character work in extension-local storage instead of relying on Clank's unsaved form state.

## Release: 1.0.0

This is the first stable Daedalus release, focused on a local, recoverable character-creation workflow for ClankWorld.

## Core workflow

- Full-page creator workspace layered over Clank's `/create` page
- ChatGPT-inspired neutral dark theme by default
- Persistent white/light theme toggle
- Proper extension icons for Chromium/Brave extension managers and toolbar surfaces
- Multiple local character projects
- Automatic local autosave and refresh recovery
- Project variants that preserve the original project
- Recovery snapshots with restore support
- Individual project JSON import/export
- Full Daedalus backup/restore for projects, custom rules, fragments, and preferences
- Private project scratchpad notes that never synchronize to Clank
- Import the current Clank creation form into Daedalus
- Apply individual sections or the full project back to Clank
- Live Clank sync status for Character, Dialogue, Scene, and Initial Messages
- Publish-readiness summary backed by the Inspector

## Character workspace

- Raw Character Prompt editor using Clank's 25,000-character limit
- Find & Replace with next/previous match, replace, replace all, and case-sensitive search
- One-click copy for raw editors
- Character Prompt outline generated from Markdown-style headings, with click-to-jump navigation
- `{{char}}` and `{{user}}` insertion helpers
- Focus mode for long-form editing
- Structured Character Builder for:
  - Identity
  - Appearance
  - Personality
  - Behavior
  - Voice & Speech
  - Relationships
  - Backstory
  - Goals
  - AI & Roleplay Rules
- Reorderable Builder compilation order
- Quick-start workflow templates that scaffold section order, rules, dialogue-example slots, and intro routes without generating the character's prose

## Quick-start templates

- Original Character
- Fandom / Canon Character
- Horror / Psychological Horror
- Romance / Slow Burn
- Adventure / RPG Companion
- Villain / Antagonist
- Multi-Character / Ensemble
- Narrator / Game Master

## AI & Roleplay Rules Studio

- Searchable built-in rule library
- Genre rule presets
- Append or replace presets
- Fully editable active rules
- Reusable custom rules with create/edit/delete
- Sync only the Roleplay Rules section into an existing Raw Prompt
- Rules remain part of the Character Prompt, while actual dialogue examples stay in the Dialogue tab

Current rule presets include:

- Immersive RP Core
- Cinematic / Narrative RP
- Horror / Psychological Horror
- Romance / Slow Burn
- Adventure / RPG Journey
- Slice of Life / Domestic
- Action / High Stakes
- Mystery / Investigation
- Multi-Character / Ensemble
- Fantasy Adventure
- Science Fiction
- Historical / Period RP
- Comedy / Lighthearted

## Dialogue workspace

- Raw Dialogue Example editor using Clank's 20,000-character limit
- Find & Replace and Focus mode
- Structured Dialogue Example Builder
- Named situations and separate `{{user}}` / `{{char}}` exchange fields
- Add, duplicate, reorder, and delete examples
- Compile structured examples into Clank's Dialogue Example format

## Scene workspace

- Scene Title editor using Clank's 200-character limit
- Raw Scene Prompt editor using Clank's 10,000-character limit
- Find & Replace and Focus mode
- Structured Scene Builder for location, time, atmosphere, situation, goals, user role, conflict, known/hidden information, and scene rules

## Initial Messages

- Multiple local opening routes
- Private Daedalus labels
- 10,000-character counters per message
- Add, duplicate, reorder, and delete messages
- `{{char}}` and `{{user}}` helpers
- Daedalus can ask Clank to add missing message fields when applying
- Extra Clank message fields are left untouched rather than deleted blindly

## Fragments

- Built-in reusable prompt pieces
- Custom reusable fragments
- Character, Dialogue, or Scene targets
- Local persistence across projects

## Inspector

- Errors, warnings, and optional suggestions rather than a fake quality score
- Clank character-limit checks
- Missing required-field notices
- Malformed variable detection
- Possible unfinished placeholders
- Roleplay-rule synchronization checks
- Duplicate long-paragraph detection
- Scene consistency checks
- Direct jump buttons from Inspector findings to the relevant workspace

## Keyboard shortcuts

- `Ctrl+S` / `Cmd+S`: save the current local project immediately
- `Ctrl+F` / `Cmd+F`: open Daedalus Find & Replace while in Character, Dialogue, or Scene raw editors
- `Esc`: leave editor Focus mode first, then close Daedalus

## Current limitations

- Character and Scene image file inputs remain manual. Browsers intentionally prevent extensions from restoring arbitrary local file paths into file pickers.
- Clank remains responsible for final publishing and server-side validation.
- Daedalus intentionally does not automate the character-tags widget.

## Installation

1. Extract the ZIP.
2. Open `chrome://extensions` or `brave://extensions`.
3. Enable **Developer mode**.
4. Choose **Load unpacked**.
5. Select the extracted Daedalus folder.
6. Open `https://www.clank.world/create`.
7. Use the Daedalus launcher in the lower-right corner.
