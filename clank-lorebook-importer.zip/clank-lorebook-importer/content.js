// 1. Fetch the local image URLs from your extension folder
const bgUrl = chrome.runtime.getURL("background.jpg");
const sigilUrl = chrome.runtime.getURL("sigil.png");
const cornerUrl = chrome.runtime.getURL("corner.png");
const mascotUrl = chrome.runtime.getURL("anime-chibi_dance.gif"); 

// 2. Inject Custom Grimoire CSS with your Images
const style = document.createElement('style');
style.innerHTML = `
  @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&display=swap');
  
  @keyframes materialize {
    0% { opacity: 0; transform: translateY(20px); filter: blur(8px); }
    100% { opacity: 1; transform: translateY(0); filter: blur(0); }
  }

  @keyframes aura-breathe {
    0% { box-shadow: 0 10px 40px rgba(0, 0, 0, 0.9), inset 0 0 20px rgba(100, 50, 150, 0.2); }
    50% { box-shadow: 0 10px 50px rgba(0, 0, 0, 0.9), inset 0 0 35px rgba(166, 124, 0, 0.3); }
    100% { box-shadow: 0 10px 40px rgba(0, 0, 0, 0.9), inset 0 0 20px rgba(100, 50, 150, 0.2); }
  }

  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-3px); }
  }
  
  #grimoire-panel {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 380px;
    background-color: rgba(15, 12, 18, 0.95);
    background-image: url('${bgUrl}');
    background-size: cover;
    background-position: center;
    background-blend-mode: multiply; 
    border: 1px solid rgba(142, 45, 226, 0.4);
    border-top: 2px solid #a67c00;
    border-bottom: 2px solid #a67c00;
    border-radius: 4px;
    padding: 22px;
    z-index: 999999;
    color: #e6dcb8;
    font-family: 'Cormorant Garamond', serif;
    animation: materialize 1s ease-out forwards, aura-breathe 8s infinite ease-in-out;
  }
  
  #grimoire-panel.casting {
    animation: float 2s infinite ease-in-out;
    border-color: #df00ff;
    box-shadow: 0 0 40px rgba(142, 45, 226, 0.3), inset 0 0 30px rgba(142, 45, 226, 0.2);
  }

  #grimoire-mascot {
    position: absolute;
    top: -75px; 
    left: 50%; 
    transform: translateX(-50%); 
    height: 80px; 
    pointer-events: none;
    z-index: 20;
    filter: drop-shadow(0px 4px 6px rgba(0,0,0,0.8)); 
  }

  .gothic-corner {
    position: absolute;
    width: 60px; 
    height: 60px;
    background-image: url('${cornerUrl}');
    background-size: contain;
    background-repeat: no-repeat;
    pointer-events: none; 
    z-index: 10;
  }
  
  .corner-tl { top: -4px; left: -4px; }
  .corner-tr { top: -4px; right: -4px; transform: scaleX(-1); } 
  .corner-bl { bottom: -4px; left: -4px; transform: scaleY(-1); } 
  .corner-br { bottom: -4px; right: -4px; transform: scaleX(-1) scaleY(-1); } 
  
  #grimoire-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid rgba(166, 124, 0, 0.3);
    padding-bottom: 10px;
    margin-bottom: 15px;
    position: relative;
    z-index: 2;
  }
  
  #grimoire-title {
    margin: 0;
    font-size: 24px;
    color: #e6dcb8;
    font-family: 'Cinzel', serif; 
    letter-spacing: 4px;
    text-shadow: 0 0 10px rgba(166, 124, 0, 0.4);
  }
  
  #grimoire-tag {
    font-size: 13px;
    color: #8e2de2;
    font-style: italic;
    opacity: 0.8;
  }

  #file-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    position: relative;
    z-index: 2;
  }

  #file-label {
    font-size: 14px;
    color: #a67c00;
    font-style: italic;
    letter-spacing: 1px;
  }

  #browse-btn {
    font-size: 12px;
    color: #bfa1ff;
    cursor: pointer;
    font-family: 'Cinzel', serif;
    letter-spacing: 2px;
    transition: all 0.3s;
    border-bottom: 1px dashed transparent;
  }

  #browse-btn:hover {
    color: #e6dcb8;
    border-bottom: 1px dashed #e6dcb8;
    text-shadow: 0 0 8px rgba(166, 124, 0, 0.6);
  }

  /* --- NEW SPEED CONTROLS --- */
  #speed-control {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    position: relative;
    z-index: 2;
  }

  #speed-label {
    font-size: 12px;
    color: #bfa1ff;
    font-family: 'Cinzel', serif;
    letter-spacing: 1px;
  }

  #speed-slider {
    width: 140px;
    accent-color: #a67c00;
    cursor: pointer;
  }
  
  .input-wrapper {
    position: relative;
    overflow: hidden;
    border-radius: 4px;
    background: rgba(5, 3, 8, 0.8);
    border: 1px solid rgba(142, 45, 226, 0.3);
    transition: all 0.4s ease;
    z-index: 2;
  }

  .input-wrapper:focus-within, .input-wrapper.drag-over {
    border-color: #a67c00;
    background: rgba(20, 15, 25, 0.9);
    box-shadow: inset 0 0 20px rgba(166, 124, 0, 0.2);
  }

  .magic-sigil {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 90px;
    height: 90px;
    background-image: url('${sigilUrl}');
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    pointer-events: none;
    z-index: 1;
    opacity: 0.2;
    transition: all 0.5s cubic-bezier(0.2, 0.8, 0.2, 1);
  }

  .input-wrapper:focus-within .magic-sigil, 
  .input-wrapper.drag-over .magic-sigil {
    opacity: 0.7;
    width: 130px;
    height: 130px;
    filter: drop-shadow(0 0 12px rgba(142, 45, 226, 0.6));
  }
  
  #md-input {
    position: relative;
    width: 100%;
    height: 140px;
    background: transparent; 
    color: #e6dcb8;
    border: none;
    padding: 15px;
    box-sizing: border-box;
    font-family: 'Cormorant Garamond', serif;
    font-size: 16px;
    line-height: 1.4;
    resize: none;
    outline: none;
    z-index: 2;
  }
  
  #md-input::placeholder {
    color: rgba(230, 220, 184, 0.4);
    font-style: italic;
  }
  
  #start-import {
    width: 100%;
    margin-top: 18px;
    padding: 12px;
    background: rgba(0,0,0,0.4);
    color: #a67c00;
    border: 1px solid rgba(166, 124, 0, 0.5);
    border-radius: 3px;
    cursor: pointer;
    font-family: 'Cinzel', serif;
    font-weight: 600;
    font-size: 16px;
    letter-spacing: 3px;
    transition: all 0.3s ease;
    text-transform: uppercase;
    position: relative;
    z-index: 2;
  }
  
  #start-import:hover {
    background: rgba(166, 124, 0, 0.2);
    color: #fff;
    border-color: #a67c00;
    box-shadow: 0 0 15px rgba(166, 124, 0, 0.3);
  }
  
  #start-import:active {
    transform: scale(0.98);
  }
  
  #import-status {
    font-size: 15px;
    color: #8e2de2;
    margin-bottom: 0;
    margin-top: 15px;
    text-align: center;
    min-height: 18px;
    font-style: italic;
    position: relative;
    z-index: 2;
  }

  #grimoire-warning {
    position: fixed;
    bottom: 320px;          
    right: 20px;
    width: 380px;
    z-index: 1000000;
    pointer-events: none;
    opacity: 0;
    transform: translateY(12px);
    transition: opacity 0.35s ease, transform 0.35s ease;
    font-family: 'Cormorant Garamond', serif;
  }

  #grimoire-warning.visible {
    opacity: 1;
    transform: translateY(0);
  }

  #grimoire-warning .warning-inner {
    background: rgba(25, 8, 12, 0.95);
    border: 1px solid rgba(166, 60, 60, 0.6);
    border-top: 2px solid #a63c3c;
    border-bottom: 2px solid #a63c3c;
    border-radius: 4px;
    padding: 14px 18px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.7),
                inset 0 0 20px rgba(166, 60, 60, 0.15);
    color: #e6dcb8;
  }

  #grimoire-warning .warning-icon {
    font-size: 22px;
    color: #ff6b6b;
    line-height: 1;
    text-shadow: 0 0 8px rgba(255, 80, 80, 0.6);
  }

  #grimoire-warning .warning-text {
    font-size: 15px;
    line-height: 1.35;
  }

  #grimoire-warning .warning-text strong {
    font-family: 'Cinzel', serif;
    letter-spacing: 2px;
    color: #ff8a8a;
    font-size: 14px;
  }
`;
document.head.appendChild(style);

// 3. Create the panel UI
const panel = document.createElement('div');
panel.id = 'grimoire-panel';
panel.innerHTML = `
  <img id="grimoire-mascot" src="${mascotUrl}" alt="Dancing Chibi">
  <div class="gothic-corner corner-tl"></div>
  <div class="gothic-corner corner-tr"></div>
  <div class="gothic-corner corner-bl"></div>
  <div class="gothic-corner corner-br"></div>

  <div id="grimoire-header">
    <h3 id="grimoire-title">GRIMOIRE</h3>
    <span id="grimoire-tag">made by SaltSaaalt</span>
  </div>
  <div id="file-controls">
    <span id="file-label">Arcane Source</span>
    <span id="browse-btn">[ SUMMON TOME ]</span>
    <input type="file" id="file-input" accept=".md,.txt" style="display: none;">
  </div>
  <div id="speed-control">
    <span id="speed-label" style="display: flex; flex-direction: column; gap: 2px;">
      Ritual Pace
      <span style="font-size: 9px; opacity: 0.6; font-family: sans-serif; letter-spacing: 0; text-transform: none;">(don't touch unless too much skipping occurs. Best if left on default value (as is) and filled by hand what remains!)</span>
    </span>
    <input type="range" id="speed-slider" min="1" max="3" step="0.5" value="1" title="Increase to slow down the injection speed for better stability">
  </div>
  <div class="input-wrapper" id="drop-wrapper">
    <div class="magic-sigil"></div>
    <textarea id="md-input" placeholder="Inscribe raw lore here, or drop a .md / .txt tome directly into the void...&#10;&#10;Format Example:&#10;Title: Dunmoor Valley&#10;Keywords: region, valley, Millstone Valley&#10;Content: The rural farming region...&#10;&#10;Title: Fria&#10;Keywords: Queen of Chaos, protagonist&#10;Content: The main character..."></textarea>
  </div>
  <button id="start-import">Bind Lore</button>
  <p id="import-status">Awaiting incantation...</p>
`;
document.body.appendChild(panel);

// Warning overlay that appears during the ritual
const warning = document.createElement('div');
warning.id = 'grimoire-warning';
warning.innerHTML = `
  <div class="warning-inner">
    <span class="warning-icon">⚠</span>
    <div class="warning-text">
      <strong>RITUAL IN PROGRESS</strong><br>
      Do not click, move the mouse, or press any keys<br>
      until the ritual finishes.
    </div>
  </div>
`;
document.body.appendChild(warning);

// 4. File Loading Logic 
const dropWrapper = document.getElementById('drop-wrapper');
const mdInput = document.getElementById('md-input');
const fileInput = document.getElementById('file-input');
const browseBtn = document.getElementById('browse-btn');
const statusText = document.getElementById('import-status');
const grimoirePanel = document.getElementById('grimoire-panel');

browseBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', (e) => { if (e.target.files.length > 0) readLoreFile(e.target.files[0]); });
mdInput.addEventListener('dragover', (e) => { e.preventDefault(); dropWrapper.classList.add('drag-over'); });
mdInput.addEventListener('dragleave', (e) => { e.preventDefault(); dropWrapper.classList.remove('drag-over'); });
mdInput.addEventListener('drop', (e) => {
  e.preventDefault();
  dropWrapper.classList.remove('drag-over');
  if (e.dataTransfer.files.length > 0) {
    const file = e.dataTransfer.files[0];
    if (file.name.endsWith('.md') || file.name.endsWith('.txt')) {
      readLoreFile(file);
    } else {
      statusText.innerText = "Invalid artifact. Only .md or .txt accepted.";
      statusText.style.color = "#a63c3c";
    }
  }
});

function readLoreFile(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    mdInput.value = e.target.result;
    statusText.innerText = `Tome '${file.name}' deciphered.`;
    statusText.style.color = "#a67c00"; 
  };
  reader.readAsText(file);
}

// 5. CDP Coordinate Injection Helpers
function sleep(ms) {
  // Read the slider value and multiply the delay
  const speedSlider = document.getElementById('speed-slider');
  const multiplier = speedSlider ? parseFloat(speedSlider.value) : 1;
  return new Promise(r => setTimeout(r, ms * multiplier));
}

async function sendDebugger(action, payload = {}) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action, ...payload }, resolve);
  });
}

/** Scroll the lorebook list so the newest entry is always fully visible */
function scrollEntriesToBottom() {
  const anyEntry = document.querySelector('input[placeholder="entry title (required)"]')
    || document.querySelector('button'); 
  if (!anyEntry) return;

  let el = anyEntry;
  while (el && el !== document.body) {
    const style = window.getComputedStyle(el);
    if (/(auto|scroll)/.test(style.overflowY) && el.scrollHeight > el.clientHeight + 50) {
      el.scrollTop = el.scrollHeight;
      return;
    }
    el = el.parentElement;
  }
  window.scrollTo(0, document.body.scrollHeight);
}

/** Force real OS-level focus by clicking the center of the element */
async function realFocus(element) {
  if (!element) return;
  scrollEntriesToBottom();
  element.scrollIntoView({ behavior: "instant", block: "center" });
  await sleep(150);

  const rect = element.getBoundingClientRect();
  if (rect.width < 5 || rect.height < 5 || rect.top < 0) {
    scrollEntriesToBottom();
    element.scrollIntoView({ behavior: "instant", block: "center" });
    await sleep(250);
    const rect2 = element.getBoundingClientRect();
    if (rect2.width < 5 || rect2.height < 5) {
      console.warn("realFocus: element still has no size", element);
      return; 
    }
  }

  const x = Math.round(rect.left + rect.width / 2);
  const y = Math.round(rect.top + rect.height / 2);

  await sendDebugger("clickAt", { x, y });
  await sleep(100);

  element.focus({ preventScroll: true });
  await sleep(60);
}

/** Insert text only after we know the OS cursor is inside the target */
async function injectTextCDP(element, text) {
  if (!element || cancelRequested) return;

  await realFocus(element);

  await sendDebugger("insertText", { text });
  await sleep(120);

  element.dispatchEvent(new Event("input",  { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
  element.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
  await sleep(220);
}

/** Click the green checkmark that sits next to the title of the newest entry */
async function confirmCurrentEntry(titleInput) {
  if (!titleInput || cancelRequested) return;

  let card = titleInput;
  for (let i = 0; i < 6 && card; i++) {
    card = card.parentElement;
    if (!card) break;
    const btns = card.querySelectorAll("button");
    if (btns.length >= 2) break;
  }
  if (!card) return;

  const buttons = Array.from(card.querySelectorAll("button"));
  const checkBtn = buttons.find(b => {
    const html = b.innerHTML.toLowerCase();
    return !html.includes("trash") && !html.includes("delete") && !html.includes("remove");
  }) || buttons[0];

  if (checkBtn) {
    await realFocus(checkBtn);
    checkBtn.click();
    await sleep(450);
  }
}

// 6. Execution Logic with KILL SWITCH
let isCasting = false;
let cancelRequested = false;

document.getElementById('start-import').addEventListener('click', async () => {
  const startBtn = document.getElementById('start-import');
  
  if (isCasting) {
    cancelRequested = true;
    startBtn.innerText = "HALTING...";
    startBtn.style.color = "#a63c3c";
    startBtn.style.borderColor = "#a63c3c";
    document.getElementById('grimoire-warning').classList.remove('visible');
    return; 
  }

  const text = mdInput.value;
  const entries = [];
  const regex = /Title:\s*(.*?)\r?\nKeywords:\s*(.*?)\r?\nContent:\s*([\s\S]*?)(?=\r?\nTitle:|$)/g;
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    entries.push({ title: match[1].trim(), keywords: match[2].trim(), content: match[3].trim() });
  }

  if (entries.length === 0) {
    statusText.innerText = "The incantation is malformed. Check syntax.";
    statusText.style.color = "#a63c3c";
    return;
  }

  const attachRes = await sendDebugger("attach");
  if (attachRes && attachRes.status === "error") {
    statusText.innerText = "Error: Cannot attach magic to this tab.";
    statusText.style.color = "#a63c3c";
    return;
  }

  isCasting = true;
  cancelRequested = false;
  grimoirePanel.classList.add('casting');
  statusText.style.color = "#e6dcb8";
  
  document.getElementById('grimoire-warning').classList.add('visible');
  
  startBtn.innerText = "STOP RITUAL";
  startBtn.style.color = "#a63c3c"; 
  startBtn.style.borderColor = "#a63c3c";

  for (let i = 0; i < entries.length; i++) {
    if (cancelRequested) break;
    const entry = entries[i];
    statusText.innerText = `Inscribing ${i + 1}/${entries.length}: ${entry.title}`;

    scrollEntriesToBottom();
    await sleep(200);

    const buttons = Array.from(document.querySelectorAll("button"));
    const newEntryBtn = buttons.find(b => b.innerText.trim().includes("New entry"));
    if (!newEntryBtn) {
      statusText.innerText = "Ritual interrupted: '+ New entry' button missing.";
      statusText.style.color = "#a63c3c";
      break;
    }

    const titleCountBefore = document.querySelectorAll('input[placeholder="entry title (required)"]').length;
    newEntryBtn.click();

    let lastTitle = null;
    for (let attempt = 0; attempt < 50; attempt++) {
      if (cancelRequested) break;
      const titles = document.querySelectorAll('input[placeholder="entry title (required)"]');
      if (titles.length > titleCountBefore) {
        lastTitle = titles[titles.length - 1];
        const hasError = lastTitle.parentElement?.textContent?.includes("Entry title is required") ||
                         lastTitle.closest("div")?.textContent?.includes("Entry title is required");
        if (hasError || lastTitle.offsetParent) break;
      }
      await sleep(120);
    }

    if (!lastTitle || cancelRequested) {
      statusText.innerText = `Could not locate new title field for entry ${i + 1}.`;
      statusText.style.color = "#a63c3c";
      break;
    }

    await sleep(450);
    scrollEntriesToBottom();

    try {
      await injectTextCDP(lastTitle, entry.title);
      await sleep(450);

      if (cancelRequested) break;

      await sendDebugger("key", { key: "Tab", code: "Tab", keyCode: 9 });
      await sleep(280);

      await sendDebugger("insertText", { text: entry.keywords });
      await sleep(200);
      const active1 = document.activeElement;
      if (active1) {
        active1.dispatchEvent(new Event("input",  { bubbles: true }));
        active1.dispatchEvent(new Event("change", { bubbles: true }));
      }
      await sleep(280);

      if (cancelRequested) break;

      await sendDebugger("key", { key: "Tab", code: "Tab", keyCode: 9 });
      await sleep(280);

      await sendDebugger("insertText", { text: entry.content });
      await sleep(200);
      const active2 = document.activeElement;
      if (active2) {
        active2.dispatchEvent(new Event("input",  { bubbles: true }));
        active2.dispatchEvent(new Event("change", { bubbles: true }));
      }
      await sleep(550);

      const titlesNow = document.querySelectorAll('input[placeholder="entry title (required)"]');
      const currentTitle = titlesNow[titlesNow.length - 1] || lastTitle;
      await confirmCurrentEntry(currentTitle);
      await sleep(450);

    } catch (err) {
      statusText.innerText = `Corruption at block ${i + 1}. Halting.`;
      statusText.style.color = "#a63c3c";
      console.error(err);
      break;
    }
  } 

  await sendDebugger("detach");
  
  document.getElementById('grimoire-warning').classList.remove('visible');

  isCasting = false;
  cancelRequested = false;
  grimoirePanel.classList.remove('casting');
  
  startBtn.innerText = "Bind Lore";
  startBtn.style.color = "#a67c00";
  startBtn.style.borderColor = "rgba(166, 124, 0, 0.5)";

  if (!statusText.innerText.includes("Halting") &&
      !statusText.innerText.includes("mismatch") &&
      !statusText.innerText.includes("interrupted") &&
      !statusText.innerText.includes("Could not locate")) {
    if (statusText.innerText.includes("Inscribing")) {
      statusText.innerText = "Lore bound successfully. Review your entries.";
      statusText.style.color = "#a67c00";
    } else {
      statusText.innerText = "Ritual aborted safely.";
      statusText.style.color = "#a67c00";
    }
  }
});