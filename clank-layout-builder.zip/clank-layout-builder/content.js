// OBELISK: CLANK LAYOUT BUILDER
// Version 1.6 — adds Pulse Indicator (SVG animate) and Hover Reveal Card (CSS :hover)
//
// Complete content.js
// Copy/paste this entire file into your extension's content.js.

(() => {
    'use strict';

    // ============================================================
    // 1. SAFETY / HELPERS
    // ============================================================

    if (window.__OBELISK_LOADED__) {
        return;
    }

    window.__OBELISK_LOADED__ = true;

    const escapeHTML = value =>
        String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');

    const obeliskEsc = escapeHTML;

    /*
     * Shared by the Badge tool's live preview and its onSubmit
     * output — single source of truth for the Style dropdown's
     * color mapping. These were previously defined separately in
     * each function and had drifted apart (preview always used
     * the theme accent color, ignoring the selected style).
     */

    const badgeStyleColor = (style, hex) =>
        style === 'Danger'
            ? '#d45c5c'
            : style === 'System'
                ? '#66b7ff'
                : style === 'Ghost'
                    ? '#888'
                    : hex;

    /*
     * Web font registry for the Styled Text tool (and any future
     * tool that wants a real font instead of relying on whatever
     * happens to be installed on the reader's OS). Confirmed via
     * manual test that Clank's Rehype pipeline preserves <style>
     * tags, so a Google Fonts @import survives — this replaces
     * the old OS-font list (Comic Sans MS / Brush Script MT),
     * which rendered inconsistently across platforms and often
     * fell back to a plain, non-cursive generic font on Mac/Linux.
     * Each entry's onSubmit/preview output wraps a <style> block
     * around a single @import — duplicate imports across multiple
     * components on the same page are harmless, the browser just
     * dedupes the request.
     */

    const OBELISK_WEB_FONTS = {
        inherit: { label: 'Default (System)', family: 'inherit', importParam: null },
        serif: { label: 'Elegant (Serif)', family: "'Playfair Display', Georgia, serif", importParam: 'Playfair+Display:wght@400;700' },
        mono: { label: 'Typewriter (Mono)', family: "'Courier Prime', 'Courier New', monospace", importParam: 'Courier+Prime:wght@400;700' },
        handwritten: { label: 'Handwritten (Casual)', family: "'Caveat', cursive", importParam: 'Caveat:wght@400;700' },
        romantic: { label: 'Romantic Script', family: "'Dancing Script', cursive", importParam: 'Dancing+Script:wght@400;700' },
        gothic: { label: 'Gothic / Horror', family: "'Creepster', cursive", importParam: 'Creepster' },
        comic: { label: 'Comic / Bold', family: "'Bangers', cursive", importParam: 'Bangers' },
        scifi: { label: 'Sci-Fi / Tech', family: "'Orbitron', sans-serif", importParam: 'Orbitron:wght@400;700;900' },
        impact: { label: 'Impact / Meme', family: "'Anton', Impact, sans-serif", importParam: 'Anton' }
    };

    const obeliskFontImportTag = fontKey => {
        const font = OBELISK_WEB_FONTS[fontKey] || OBELISK_WEB_FONTS.inherit;
        if (!font.importParam) return '';
        return `<style>@import url('https://fonts.googleapis.com/css2?family=${font.importParam}&display=swap');</style>\n`;
    };

    const STORAGE_KEY = 'obelisk-accent-color';

    let activeModal = null;
    let panel = null;

    let accentColor =
        localStorage.getItem(STORAGE_KEY) ||
        '#c4a35a';

    // ============================================================
    // 2. THEME
    // ============================================================

    const applyAccent = hex => {
        accentColor = hex || '#c4a35a';

        localStorage.setItem(
            STORAGE_KEY,
            accentColor
        );

        if (panel) {
            panel.style.setProperty(
                '--obelisk-accent',
                accentColor
            );
        }

        document
            .querySelectorAll('.obelisk-modal')
            .forEach(modal => {
                modal.style.setProperty(
                    '--obelisk-accent',
                    accentColor
                );
            });
    };

    // ============================================================
    // 3. TOASTS
    // ============================================================

    const showToast = (
        message,
        type = 'success'
    ) => {
        document
            .querySelectorAll('.obelisk-toast')
            .forEach(existing => {
                existing.remove();
            });

        const toast =
            document.createElement('div');

        toast.className =
            `obelisk-toast obelisk-toast-${type}`;

        toast.innerHTML = `
            <span class="obelisk-toast-mark">
                ${type === 'error' ? '!' : '◆'}
            </span>

            <span class="obelisk-toast-text">
                ${escapeHTML(message)}
            </span>
        `;

        document.body.appendChild(toast);

        requestAnimationFrame(() => {
            toast.classList.add(
                'obelisk-toast-visible'
            );
        });

        setTimeout(() => {
            toast.classList.remove(
                'obelisk-toast-visible'
            );

            setTimeout(() => {
                toast.remove();
            }, 250);
        }, 2400);
    };

    // ============================================================
    // 4. INJECTION
    // ============================================================

    /*
     * Clank's "about" field runs through a Markdown parser
     * before the raw HTML snippets we inject get rendered.
     * CommonMark treats any line that starts with 4+ spaces
     * of indentation, immediately after a blank line, as a
     * code block rather than continued HTML — and our tool
     * templates are written with nested indentation (for our
     * own readability in this file) plus blank lines between
     * elements. That combination was silently dropping nested
     * elements (e.g. the quote's author div, the accordion's
     * content div) into escaped <pre><code> blocks instead of
     * rendering them.
     *
     * Fix: strip leading whitespace and blank lines from every
     * injected snippet right before it hits the textarea, so
     * the whole thing survives as one unbroken HTML block
     * regardless of how it's indented in the source. Applied
     * once here rather than in each of the 17 tool templates.
     */

    const sanitizeMarkdownHtml = str =>
        str
            .split('\n')
            .map(line => line.trim())
            .filter(line => line.length > 0)
            .join('\n');

    /*
     * Finds the character's "Edit about" markdown textarea
     * specifically — not just any textarea on the page (a
     * character page can also have a short bio field, name
     * field, etc., and grabbing the wrong one was the bug).
     *
     * Matched by its placeholder text, which is the most
     * stable hook available without a data-testid from Clank.
     * If Clank ever changes that placeholder, add a fallback
     * selector here rather than widening back to "any textarea."
     */

    const findAboutEditor = () =>
        document.querySelector(
            'textarea[placeholder*="Write about your character"]'
        );

    const injectText = rawText => {
        if (!rawText) {
            return;
        }

        const text =
            sanitizeMarkdownHtml(rawText);

        /*
         * Always prefer the actual "Edit about" box, even if
         * some other field happens to be focused right now —
         * that's what was causing text to land in the wrong
         * place.
         */

        const aboutEditor =
            findAboutEditor();

        if (aboutEditor) {
            insertIntoElement(
                aboutEditor,
                text
            );

            showToast(
                'Component inserted.'
            );

            return;
        }

        const active =
            document.activeElement;

        /*
         * Fallback: the "Edit about" box wasn't found (maybe
         * Clank changed its markup), so fall back to whatever
         * is focused.
         */

        if (
            active &&
            (
                active.tagName === 'TEXTAREA' ||
                active.tagName === 'INPUT' ||
                active.isContentEditable
            )
        ) {
            insertIntoElement(
                active,
                text
            );

            showToast(
                'Component inserted.'
            );

            return;
        }

        /*
         * Last resort: any editable area at all.
         */

        const editor =
            document.querySelector(
                'textarea'
            ) ||
            document.querySelector(
                '[contenteditable="true"]'
            );

        if (editor) {
            insertIntoElement(
                editor,
                text
            );

            showToast(
                'Component inserted.'
            );

            return;
        }

        /*
         * Clipboard fallback.
         */

        navigator.clipboard
            ?.writeText(text)
            .then(() => {
                showToast(
                    'Copied component to clipboard.'
                );
            })
            .catch(() => {
                showToast(
                    'Could not find the editor.',
                    'error'
                );
            });
    };

    const insertIntoElement = (
        element,
        text
    ) => {
        if (
            element.tagName === 'TEXTAREA' ||
            element.tagName === 'INPUT'
        ) {
            const start =
                element.selectionStart ??
                element.value.length;

            const end =
                element.selectionEnd ??
                element.value.length;

            element.value =
                element.value.slice(
                    0,
                    start
                ) +
                text +
                element.value.slice(
                    end
                );

            element.selectionStart =
                start + text.length;

            element.selectionEnd =
                start + text.length;

            element.dispatchEvent(
                new Event(
                    'input',
                    {
                        bubbles: true
                    }
                )
            );

            return;
        }

        if (
            element.isContentEditable
        ) {
            document.execCommand(
                'insertText',
                false,
                text
            );

            element.dispatchEvent(
                new InputEvent(
                    'input',
                    {
                        bubbles: true,
                        inputType:
                            'insertText',
                        data: text
                    }
                )
            );
        }
    };

    // ============================================================
    // 5. MODAL SYSTEM
    // ============================================================

    const closeModal = () => {
        if (!activeModal) {
            return;
        }

        activeModal.classList.remove(
            'obelisk-modal-visible'
        );

        const modal =
            activeModal;

        setTimeout(() => {
            modal.remove();
        }, 220);

        activeModal = null;
    };

    const openModal = tool => {
        closeModal();

        const overlay =
            document.createElement('div');

        overlay.className =
            'obelisk-modal-overlay';

        const modal =
            document.createElement('div');

        modal.className =
            'obelisk-modal';

        modal.style.setProperty(
            '--obelisk-accent',
            accentColor
        );

        const title =
            tool.name.replace(
                /^[^A-Za-z]+/,
                ''
            );

        modal.innerHTML = `
            <div class="obelisk-modal-glow"></div>

            <div class="obelisk-modal-header">
                <div class="obelisk-modal-heading">
                    <span class="obelisk-modal-kicker">
                        OBELISK BUILDER
                    </span>

                    <strong>
                        ${escapeHTML(title)}
                    </strong>
                </div>

                <button
                    class="obelisk-modal-close"
                    type="button"
                    aria-label="Close"
                >
                    ×
                </button>
            </div>

            <div class="obelisk-modal-body">
                <div class="obelisk-modal-fields">
                    ${tool.fields
                        .map(field =>
                            renderField(
                                field
                            )
                        )
                        .join('')}
                </div>

                ${
                    tool.preview
                        ? `
                            <div class="obelisk-preview-block">
                                <div class="obelisk-preview-label">
                                    LIVE PREVIEW
                                </div>

                                <div
                                    class="obelisk-preview"
                                    id="obelisk-live-preview"
                                >
                                    ${tool.preview(
                                        getInitialValues(
                                            tool.fields
                                        ),
                                        accentColor
                                    )}
                                </div>
                            </div>
                        `
                        : ''
                }
            </div>

            <div class="obelisk-modal-footer">
                <button
                    type="button"
                    class="obelisk-btn obelisk-btn-secondary"
                    data-obelisk-cancel
                >
                    CANCEL
                </button>

                <button
                    type="button"
                    class="obelisk-btn obelisk-btn-primary"
                    data-obelisk-submit
                >
                    <span>◆</span>
                    INSERT
                </button>
            </div>
        `;

        overlay.appendChild(modal);

        document.body.appendChild(
            overlay
        );

        activeModal = overlay;

        requestAnimationFrame(() => {
            overlay.classList.add(
                'obelisk-modal-visible'
            );
        });

        wireModal(
            overlay,
            modal,
            tool
        );
    };

    const renderField = field => {
        const id =
            `obelisk-field-${field.key}`;

        const label =
            escapeHTML(
                field.label ||
                field.key
            );

        const description =
            field.description
                ? `
                    <small class="obelisk-field-description">
                        ${escapeHTML(
                            field.description
                        )}
                    </small>
                `
                : '';

        if (
            field.type === 'textarea'
        ) {
            return `
                <label
                    class="obelisk-field"
                    for="${id}"
                >
                    <span class="obelisk-field-label">
                        ${label}
                    </span>

                    ${description}

                    <textarea
                        id="${id}"
                        data-obelisk-field="${escapeHTML(
                            field.key
                        )}"
                        placeholder="${escapeHTML(
                            field.placeholder || ''
                        )}"
                        rows="${field.rows || 4}"
                    >${escapeHTML(
                        field.default || ''
                    )}</textarea>
                </label>
            `;
        }

        if (
            field.type === 'select'
        ) {
            return `
                <label
                    class="obelisk-field"
                    for="${id}"
                >
                    <span class="obelisk-field-label">
                        ${label}
                    </span>

                    ${description}

                    <select
                        id="${id}"
                        data-obelisk-field="${escapeHTML(
                            field.key
                        )}"
                    >
                        ${(field.options || [])
                            .map(option => {
                                const value =
                                    typeof option === 'string'
                                        ? option
                                        : option.value;

                                const text =
                                    typeof option === 'string'
                                        ? option
                                        : option.label;

                                return `
                                    <option
                                        value="${escapeHTML(
                                            value
                                        )}"
                                    >
                                        ${escapeHTML(
                                            text
                                        )}
                                    </option>
                                `;
                            })
                            .join('')}
                    </select>
                </label>
            `;
        }

        if (
            field.type === 'range'
        ) {
            const value =
                field.default ??
                field.min ??
                0;

            return `
                <label
                    class="obelisk-field"
                    for="${id}"
                >
                    <span class="obelisk-field-label-row">
                        <span class="obelisk-field-label">
                            ${label}
                        </span>

                        <output
                            data-obelisk-output="${escapeHTML(
                                field.key
                            )}"
                        >
                            ${escapeHTML(value)}
                        </output>
                    </span>

                    ${description}

                    <input
                        id="${id}"
                        type="range"
                        min="${field.min ?? 0}"
                        max="${field.max ?? 100}"
                        step="${field.step ?? 1}"
                        value="${value}"
                        data-obelisk-field="${escapeHTML(
                            field.key
                        )}"
                    >
                </label>
            `;
        }

        return `
            <label
                class="obelisk-field"
                for="${id}"
            >
                <span class="obelisk-field-label">
                    ${label}
                </span>

                ${description}

                <input
                    id="${id}"
                    type="${field.type || 'text'}"
                    value="${escapeHTML(
                        field.default || ''
                    )}"
                    placeholder="${escapeHTML(
                        field.placeholder || ''
                    )}"
                    data-obelisk-field="${escapeHTML(
                        field.key
                    )}"
                >
            </label>
        `;
    };

    const getInitialValues = fields => {
        const values = {};

        (fields || []).forEach(
            field => {
                values[field.key] =
                    field.default || '';
            }
        );

        return values;
    };

    const collectValues = modal => {
        const values = {};

        modal
            .querySelectorAll(
                '[data-obelisk-field]'
            )
            .forEach(field => {
                values[
                    field.dataset.obeliskField
                ] = field.value;
            });

        return values;
    };

    const wireModal = (
        overlay,
        modal,
        tool
    ) => {
        const closeButton =
            modal.querySelector(
                '.obelisk-modal-close'
            );

        const cancelButton =
            modal.querySelector(
                '[data-obelisk-cancel]'
            );

        const submitButton =
            modal.querySelector(
                '[data-obelisk-submit]'
            );

        closeButton?.addEventListener(
            'click',
            closeModal
        );

        cancelButton?.addEventListener(
            'click',
            closeModal
        );

        overlay.addEventListener(
            'click',
            event => {
                if (
                    event.target ===
                    overlay
                ) {
                    closeModal();
                }
            }
        );

        const updatePreview =
            () => {
                if (!tool.preview) {
                    return;
                }

                const preview =
                    modal.querySelector(
                        '#obelisk-live-preview'
                    );

                if (!preview) {
                    return;
                }

                preview.innerHTML =
                    tool.preview(
                        collectValues(modal),
                        accentColor
                    );
            };

        modal
            .querySelectorAll(
                '[data-obelisk-field]'
            )
            .forEach(field => {
                field.addEventListener(
                    'input',
                    () => {
                        const output =
                            modal.querySelector(
                                `[data-obelisk-output="${CSS.escape(
                                    field.dataset
                                        .obeliskField
                                )}"]`
                            );

                        if (output) {
                            output.value =
                                field.value;

                            output.textContent =
                                field.value;
                        }

                        updatePreview();
                    }
                );

                field.addEventListener(
                    'change',
                    updatePreview
                );
            });

        submitButton?.addEventListener(
            'click',
            () => {
                const values =
                    collectValues(modal);

                if (
                    tool.validate &&
                    !tool.validate(values)
                ) {
                    return;
                }

                if (
                    typeof tool.onSubmit ===
                    'function'
                ) {
                    tool.onSubmit(
                        values,
                        accentColor
                    );
                }

                closeModal();
            }
        );

        const firstInput =
            modal.querySelector(
                'input, textarea, select'
            );

        setTimeout(() => {
            firstInput?.focus();
        }, 100);
    };

    // ============================================================
    // 6. TOOL METADATA
    // ============================================================

    const obeliskMeta = {

        '✦ Divider': {
            category: 'DECORATION',
            icon: '✦',
            description:
                'Create an elegant visual section divider.'
        },

        '▣ Framed Image': {
            category: 'MEDIA',
            icon: '▣',
            description:
                'Create a polished framed image block.'
        },

        '▦ Card Grid': {
            category: 'LAYOUT',
            icon: '▦',
            description:
                'Build a grid of styled information cards.'
        },

        '◈ Stat / Skill Bar': {
            category: 'DATA',
            icon: '◈',
            description:
                'Create a visual stat or skill meter.'
        },

        '❝ Quote': {
            category: 'TEXT',
            icon: '❝',
            description:
                'Create a dramatic quote block.'
        },

        '⌄ Accordion': {
            category: 'CONTENT',
            icon: '⌄',
            description:
                'Create a collapsible lore section.'
        },

        '⚠ Warning Box': {
            category: 'CALLOUT',
            icon: '⚠',
            description:
                'Create a high-visibility warning panel.'
        },

        '♡ Relationship': {
            category: 'CHARACTERS',
            icon: '♡',
            description:
                'Create a character relationship card.'
        },

        '◌ Dialogue': {
            category: 'DIALOGUE',
            icon: '◌',
            description:
                'Build a two-sided dialogue exchange.'
        },

        '♙ Character Header': {
            category: 'CHARACTERS',
            icon: '♙',
            description:
                'Create a dramatic character introduction.'
        },

        '◆ Badge / Tag': {
            category: 'CHARACTERS',
            icon: '◆',
            description:
                'Create a compact title or classification tag.'
        },

        '▤ Lore Entry': {
            category: 'CONTENT',
            icon: '▤',
            description:
                'Create a polished lore or biography panel.'
        },

        '◷ Timeline Event': {
            category: 'CONTENT',
            icon: '◷',
            description:
                'Create a chronological story event.'
        },

        '✦ Scene Header': {
            category: 'DIALOGUE',
            icon: '✦',
            description:
                'Create a cinematic scene transition.'
        },

        '>_ Terminal Log': {
            category: 'CALLOUT',
            icon: '>_',
            description:
                'Create a futuristic system or terminal log.'
        },

        '▥ Stat Sheet': {
            category: 'DATA',
            icon: '▥',
            description:
                'Create a complete multi-stat character sheet.'
        },

        '▣ Classified File': {
            category: 'CALLOUT',
            icon: '▣',
            description:
                'Create a classified dossier-style information block.'
        },
        '🎀 Cutecore Box': {
            category: 'THEMES',
            icon: '🎀',
            description: 'A soft, pastel panel with rounded edges and dotted borders.'
        },

        '💌 Romance Letter': {
            category: 'THEMES',
            icon: '💌',
            description: 'An elegant, cursive love letter format with soft styling.'
        },

        '👁️ Abyssal Log': {
            category: 'THEMES',
            icon: '👁️',
            description: 'A jarring, cosmic horror block with deep shadows and blood accents.'
        },

        '📝 Styled Text': {
            category: 'TEXT',
            icon: '📝',
            description: 'A custom text block with font, size, and alignment controls.'
        },
        '💿 Now Playing': {
            category: 'MEDIA',
            icon: '💿',
            description: 'A stylized visual music player for character theme songs.'
        },
        '✨ Gradient Text': {
            category: 'DECORATION',
            icon: '✨',
            description: 'Create beautiful, multi-color holographic text effects.'
        },
        '🚨 Scrolling Ticker': {
            category: 'CALLOUT',
            icon: '🚨',
            description: 'An animated, scrolling marquee banner for alerts or news.'
        },
        '🎛️ Producer Tracklist': {
            category: 'MEDIA',
            icon: '🎛️',
            description: 'A stylized album tracklist for EPs or beat tapes.'
        },
        '⚙️ Mod Loadout': {
            category: 'DATA',
            icon: '⚙️',
            description: 'A structured node tree for loadouts, mods, or cybernetics.'
        },
        '🎵 SoundCloud Player': {
            category: 'MEDIA',
            icon: '🎵',
            description: 'EXPERIMENTAL: Injects an actual playable SoundCloud widget.'
        },
        '🎇 Cinematic GIF Box': {
            category: 'MEDIA',
            icon: '🎇',
            description: 'A lore box with an animated GIF background overlay.'
        },
        '🃏 3D Hologram Card': {
            category: 'MEDIA',
            icon: '🃏',
            description: 'Tilts an image in 3D space to look like a physical trading card.'
        },
        '🎮 Engine Inspector': {
            category: 'DATA',
            icon: '🎮',
            description: 'A technical stat block styled like a game engine UI.'
        },

        '💬 Chat Thread': {
            category: 'SOCIAL',
            icon: '💬',
            description: 'A texting/DM-style message thread with left/right bubbles.'
        },

        '📷 Memory Polaroid': {
            category: 'MEDIA',
            icon: '📷',
            description: 'A tilted polaroid-style photo with a handwritten caption.'
        },

        '💞 Pet Name Tag': {
            category: 'CHARACTERS',
            icon: '💞',
            description: 'A small rounded nickname tag for pet names and endearments.'
        },

        '💘 Compatibility Meter': {
            category: 'DATA',
            icon: '💘',
            description: 'A romantic-styled percentage meter for shipping or relationship stats.'
        },

        '😂 Meme Caption': {
            category: 'MEDIA',
            icon: '😂',
            description: 'Classic top/bottom impact-font meme caption over an image.'
        },

        '🔔 Fake Notification': {
            category: 'SOCIAL',
            icon: '🔔',
            description: 'A mock phone notification popup for comedic or in-universe alerts.'
        },

        '🏆 Achievement Unlocked': {
            category: 'CALLOUT',
            icon: '🏆',
            description: 'A game-style achievement popup banner.'
        },

        '👁️‍🗨️ Spoiler Reveal': {
            category: 'CONTENT',
            icon: '👁️‍🗨️',
            description: 'A click-to-reveal spoiler block for plot twists and secrets.'
        },

        '🚩 Content Warning': {
            category: 'CALLOUT',
            icon: '🚩',
            description: 'A standardized content/trigger warning tag list.'
        },

        '💭 OOC Note': {
            category: 'CALLOUT',
            icon: '💭',
            description: 'A muted, bracketed out-of-character note for RP context.'
        },

        '📌 Evidence Board': {
            category: 'LAYOUT',
            icon: '📌',
            description: 'A corkboard of pinned, handwritten note cards for mysteries and drama.'
        },

        '🌌 Page Background': {
            category: 'DECORATION',
            icon: '🌌',
            description: 'EXPERIMENTAL: A full-page fixed background pattern. Works today but relies on Clank page structure that could change without warning — see code comment.'
        },

        '💓 Pulse Indicator': {
            category: 'DECORATION',
            icon: '💓',
            description: 'A small live/status badge with a real SVG pulse-ring animation.'
        },

        '🖱️ Hover Reveal Card': {
            category: 'CONTENT',
            icon: '🖱️',
            description: 'A card that swaps its text on hover via real CSS — distinct from the click-based Spoiler Reveal.'
        }
    };

    // ============================================================
    // 7. TOOLS
    // ============================================================

    const tools = [

        // --------------------------------------------------------
        // DIVIDER
        // --------------------------------------------------------

        {
            name: '✦ Divider',

            fields: [
                {
                    key: 'style',
                    label: 'Divider Style',
                    type: 'select',
                    options: [
                        'Elegant',
                        'Gothic',
                        'Minimal',
                        'Double',
                        'Stars'
                    ],
                    default: 'Elegant'
                }
            ],

            preview: (values, hex) => `
                <div
                    style="
                        padding:18px 0;
                        text-align:center;
                        color:${hex};
                        letter-spacing:6px;
                    "
                >
                    ${
                        values.style === 'Stars'
                            ? '✦ ─── ✦ ─── ✦'
                            : values.style === 'Double'
                                ? '━━━━━━  ━━━━━━'
                                : values.style === 'Gothic'
                                    ? '◆ ───────── ◆'
                                    : values.style === 'Minimal'
                                        ? '────────────'
                                        : '✦ ───────── ✦'
                    }
                </div>
            `,

            onSubmit: (values, hex) => {

                let divider;

                switch (values.style) {
                    case 'Gothic':
                        divider = `
<div style="margin:28px 0; text-align:center; color:${hex}; letter-spacing:5px;">
◆ ───────────────── ◆
</div>
`;
                        break;

                    case 'Minimal':
                        divider = `
<div style="height:1px; margin:24px 0; background:${hex}; opacity:.55;"></div>
`;
                        break;

                    case 'Double':
                        divider = `
<div style="margin:28px 0; text-align:center; color:${hex}; letter-spacing:2px;">
━━━━━━  ━━━━━━
</div>
`;
                        break;

                    case 'Stars':
                        divider = `
<div style="margin:28px 0; text-align:center; color:${hex}; letter-spacing:5px;">
✦ ─── ✦ ─── ✦
</div>
`;
                        break;

                    default:
                        divider = `
<div style="margin:28px 0; text-align:center; color:${hex}; letter-spacing:4px;">
✦ ───────── ✦
</div>
`;
                }

                injectText(divider);
            }
        },

        // --------------------------------------------------------
        // FRAMED IMAGE
        // --------------------------------------------------------

        {
            name: '▣ Framed Image',

            fields: [
                {
                    key: 'url',
                    label: 'Image URL',
                    placeholder:
                        'https://...',
                    default: ''
                },

                {
                    key: 'caption',
                    label: 'Caption',
                    placeholder:
                        'Optional caption'
                },

                {
                    key: 'style',
                    label: 'Frame Style',
                    type: 'select',
                    options: [
                        'Royal',
                        'Cyber',
                        'Gothic',
                        'Minimal'
                    ],
                    default: 'Royal'
                }
            ],

            preview: values => `
                <div
                    style="
                        text-align:center;
                        padding:10px;
                    "
                >
                    ${
                        values.url
                            ? `
                                <img
                                    src="${escapeHTML(
                                        values.url
                                    )}"
                                    style="
                                        max-width:100%;
                                        max-height:160px;
                                        border-radius:8px;
                                        object-fit:cover;
                                    "
                                >
                            `
                            : `
                                <div
                                    style="
                                        height:100px;
                                        display:flex;
                                        align-items:center;
                                        justify-content:center;
                                        border:1px dashed #444;
                                        color:#777;
                                    "
                                >
                                    IMAGE PREVIEW
                                </div>
                            `
                    }

                    ${
                        values.caption
                            ? `
                                <div
                                    style="
                                        margin-top:8px;
                                        color:#888;
                                        font-size:.8em;
                                    "
                                >
                                    ${escapeHTML(
                                        values.caption
                                    )}
                                </div>
                            `
                            : ''
                    }
                </div>
            `,

            validate: values => {
                if (!values.url.trim()) {
                    showToast(
                        'Please enter an image URL.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                const styles = {
                    Royal: `
                        border:2px solid ${hex};
                        box-shadow:0 0 24px ${hex}33;
                    `,

                    Cyber: `
                        border:1px solid ${hex};
                        border-radius:2px;
                        box-shadow:0 0 12px ${hex}55;
                    `,

                    Gothic: `
                        border:1px solid #3b3326;
                        box-shadow:
                            inset 0 0 0 4px #111,
                            0 8px 30px rgba(0,0,0,.4);
                    `,

                    Minimal: `
                        border:1px solid #333;
                    `
                };

                const code = `
<div style="margin:24px 0; text-align:center;">
    <div style="
        display:inline-block;
        max-width:100%;
        padding:8px;
        background:#0d0d0f;
        border-radius:10px;
        ${styles[values.style] || styles.Royal}
    ">
        <img
            src="${escapeHTML(
                values.url.trim()
            )}"
            style="
                display:block;
                max-width:100%;
                height:auto;
                border-radius:4px;
            "
        >
    </div>

    ${
        values.caption.trim()
            ? `
                <div style="
                    margin-top:8px;
                    color:#888;
                    font-size:.8em;
                    letter-spacing:1px;
                ">
                    ${escapeHTML(
                        values.caption.trim()
                    )}
                </div>
            `
            : ''
    }
</div>
`;

                injectText(code);
            }
        },

        // --------------------------------------------------------
        // CARD GRID
        // --------------------------------------------------------

        {
            name: '▦ Card Grid',

            fields: [
                {
                    key: 'columns',
                    label: 'Columns',
                    type: 'range',
                    min: 1,
                    max: 4,
                    default: 3
                },

                {
                    key: 'title',
                    label: 'Card Title',
                    placeholder:
                        'Card title'
                },

                {
                    key: 'text',
                    label: 'Card Content',
                    type: 'textarea',
                    placeholder:
                        'Card information...'
                }
            ],

            preview: (values, hex) => `
                <div
                    style="
                        display:grid;
                        grid-template-columns:
                            repeat(
                                ${values.columns || 3},
                                1fr
                            );
                        gap:8px;
                    "
                >
                    ${Array.from({
                        length:
                            Number(
                                values.columns || 3
                            )
                    })
                        .map(
                            (_, i) => `
                                <div
                                    style="
                                        padding:10px;
                                        border:1px solid #333;
                                        border-top:2px solid ${hex};
                                        background:#111;
                                        border-radius:6px;
                                    "
                                >
                                    <strong
                                        style="
                                            color:${hex};
                                            font-size:.75em;
                                        "
                                    >
                                        ${
                                            escapeHTML(
                                                values.title
                                            ) ||
                                            `CARD ${i + 1}`
                                        }
                                    </strong>
                                </div>
                            `
                        )
                        .join('')}
                </div>
            `,

            onSubmit: (values, hex) => {

                const columns =
                    Math.max(
                        1,
                        Math.min(
                            4,
                            Number(
                                values.columns || 3
                            )
                        )
                    );

                const code = `
<div style="
    display:grid;
    grid-template-columns:repeat(${columns}, minmax(0, 1fr));
    gap:14px;
    margin:24px 0;
">
${Array.from({
    length: columns
})
    .map(
        (_, i) => `
    <div style="
        background:#111;
        border:1px solid #292929;
        border-top:3px solid ${hex};
        border-radius:10px;
        padding:16px;
        box-shadow:0 8px 24px rgba(0,0,0,.25);
    ">
        <div style="
            color:${hex};
            font-weight:700;
            margin-bottom:8px;
        ">
            ${escapeHTML(
                values.title.trim() ||
                `CARD ${i + 1}`
            )}
        </div>

        <div style="
            color:#aaa;
            line-height:1.6;
        ">
            ${escapeHTML(
                values.text.trim()
            )}
        </div>
    </div>
`
    )
    .join('')}
</div>
`;

                injectText(code);
            }
        },

        // --------------------------------------------------------
        // STAT BAR
        // --------------------------------------------------------

        {
            name: '◈ Stat / Skill Bar',

            fields: [
                {
                    key: 'name',
                    label: 'Stat Name',
                    placeholder:
                        'Strength'
                },

                {
                    key: 'value',
                    label: 'Value',
                    type: 'range',
                    min: 0,
                    max: 100,
                    default: 75
                }
            ],

            preview: (values, hex) => `
                <div style="
                    padding:10px 0;
                ">
                    <div style="
                        display:flex;
                        justify-content:space-between;
                        margin-bottom:6px;
                        color:#ddd;
                    ">
                        <span>
                            ${escapeHTML(
                                values.name ||
                                'STAT'
                            )}
                        </span>

                        <strong
                            style="color:${hex};"
                        >
                            ${values.value || 0}%
                        </strong>
                    </div>

                    <div style="
                        height:7px;
                        background:#222;
                        border-radius:99px;
                        overflow:hidden;
                    ">
                        <div style="
                            width:${values.value || 0}%;
                            height:100%;
                            background:${hex};
                            box-shadow:0 0 12px ${hex}88;
                        "></div>
                    </div>
                </div>
            `,

            validate: values => {
                if (!values.name.trim()) {
                    showToast(
                        'Please enter a stat name.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                const value =
                    Math.max(
                        0,
                        Math.min(
                            100,
                            Number(
                                values.value || 0
                            )
                        )
                    );

                const code = `
<div style="
    margin:16px 0;
">
    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        margin-bottom:6px;
    ">
        <span style="
            color:#ddd;
            font-weight:600;
        ">
            ${escapeHTML(
                values.name.trim()
            )}
        </span>

        <span style="
            color:${hex};
            font-weight:700;
        ">
            ${value}%
        </span>
    </div>

    <div style="
        height:7px;
        background:#1c1c1c;
        border-radius:999px;
        overflow:hidden;
    ">
        <div style="
            width:${value}%;
            height:100%;
            background:${hex};
            box-shadow:0 0 12px ${hex}88;
        "></div>
    </div>
</div>
`;

                injectText(code);
            }
        },

        // --------------------------------------------------------
        // QUOTE
        // --------------------------------------------------------

        {
            name: '❝ Quote',

            fields: [
                {
                    key: 'text',
                    label: 'Quote',
                    type: 'textarea',
                    placeholder:
                        'Enter the quote...',
                    rows: 4
                },

                {
                    key: 'author',
                    label: 'Author',
                    placeholder:
                        'Optional attribution'
                }
            ],

            preview: (values, hex) => `
                <div style="
                    border-left:3px solid ${hex};
                    padding:12px 16px;
                    color:#ccc;
                    font-style:italic;
                ">
                    “${
                        escapeHTML(
                            values.text ||
                            'Your quote...'
                        )
                    }”

                    ${
                        values.author
                            ? `
                                <div style="
                                    margin-top:8px;
                                    color:${hex};
                                    font-style:normal;
                                    font-size:.75em;
                                ">
                                    — ${escapeHTML(
                                        values.author
                                    )}
                                </div>
                            `
                            : ''
                    }
                </div>
            `,

            validate: values => {
                if (!values.text.trim()) {
                    showToast(
                        'Please enter a quote.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<blockquote style="
    margin:24px 0;
    padding:16px 20px;
    border-left:3px solid ${hex};
    background:#101010;
    color:#ccc;
    font-style:italic;
    line-height:1.7;
">
    “${escapeHTML(
        values.text.trim()
    )}”

    ${
        values.author.trim()
            ? `
                <div style="
                    margin-top:8px;
                    color:${hex};
                    font-size:.75em;
                    font-style:normal;
                    letter-spacing:1px;
                ">
                    — ${escapeHTML(
                        values.author.trim()
                    )}
                </div>
            `
            : ''
    }
</blockquote>
`);
            }
        },

        // --------------------------------------------------------
        // ACCORDION
        // --------------------------------------------------------

        {
            name: '⌄ Accordion',

            fields: [
                {
                    key: 'title',
                    label: 'Section Title',
                    placeholder:
                        'Character Lore'
                },

                {
                    key: 'content',
                    label: 'Content',
                    type: 'textarea',
                    placeholder:
                        'Hidden information...',
                    rows: 5
                }
            ],

            preview: (values, hex) => `
                <details
                    style="
                        background:#111;
                        border:1px solid #2a2a2a;
                        border-left:3px solid ${hex};
                        border-radius:8px;
                        padding:10px 14px;
                    "
                >
                    <summary
                        style="
                            color:${hex};
                            cursor:pointer;
                            font-weight:700;
                        "
                    >
                        ${escapeHTML(
                            values.title ||
                            'SECTION TITLE'
                        )}
                    </summary>

                    <div
                        style="
                            margin-top:10px;
                            color:#aaa;
                        "
                    >
                        ${escapeHTML(
                            values.content ||
                            'Hidden content...'
                        )}
                    </div>
                </details>
            `,

            validate: values => {
                if (
                    !values.title.trim() ||
                    !values.content.trim()
                ) {
                    showToast(
                        'Please complete the accordion.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<details style="
    margin:18px 0;
    background:#111;
    border:1px solid #2a2a2a;
    border-left:3px solid ${hex};
    border-radius:8px;
    padding:12px 16px;
">
    <summary style="
        color:${hex};
        cursor:pointer;
        font-weight:700;
        letter-spacing:.5px;
    ">
        ${escapeHTML(
            values.title.trim()
        )}
    </summary>

    <div style="
        margin-top:12px;
        color:#aaa;
        line-height:1.7;
    ">
        ${escapeHTML(
            values.content.trim()
        )}
    </div>
</details>
`);
            }
        },

        // --------------------------------------------------------
        // WARNING
        // --------------------------------------------------------

        {
            name: '⚠ Warning Box',

            fields: [
                {
                    key: 'title',
                    label: 'Warning Title',
                    placeholder:
                        'WARNING'
                },

                {
                    key: 'message',
                    label: 'Message',
                    type: 'textarea',
                    placeholder:
                        'Warning information...',
                    rows: 4
                }
            ],

            preview: (values, hex) => `
                <div style="
                    padding:14px;
                    background:#17130c;
                    border:1px solid #44351d;
                    border-left:3px solid ${hex};
                    border-radius:7px;
                ">
                    <strong
                        style="
                            color:${hex};
                            display:block;
                            margin-bottom:6px;
                        "
                    >
                        ⚠ ${
                            escapeHTML(
                                values.title ||
                                'WARNING'
                            )
                        }
                    </strong>

                    <span
                        style="
                            color:#aaa;
                        "
                    >
                        ${escapeHTML(
                            values.message ||
                            'Warning message...'
                        )}
                    </span>
                </div>
            `,

            validate: values => {
                if (
                    !values.title.trim() ||
                    !values.message.trim()
                ) {
                    showToast(
                        'Please complete the warning.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<div style="
    margin:20px 0;
    padding:16px;
    background:#17130c;
    border:1px solid #44351d;
    border-left:3px solid ${hex};
    border-radius:8px;
">
    <div style="
        color:${hex};
        font-weight:800;
        letter-spacing:1px;
        margin-bottom:7px;
    ">
        ⚠ ${escapeHTML(
            values.title.trim()
        )}
    </div>

    <div style="
        color:#aaa;
        line-height:1.6;
    ">
        ${escapeHTML(
            values.message.trim()
        )}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // RELATIONSHIP
        // --------------------------------------------------------

        {
            name: '♡ Relationship',

            fields: [
                {
                    key: 'name',
                    label: 'Character',
                    placeholder:
                        'Character name'
                },

                {
                    key: 'relationship',
                    label: 'Relationship',
                    placeholder:
                        'Trusted ally'
                },

                {
                    key: 'description',
                    label: 'Description',
                    type: 'textarea',
                    placeholder:
                        'Describe the relationship...',
                    rows: 4
                }
            ],

            preview: (values, hex) => `
                <div style="
                    padding:15px;
                    background:#111;
                    border:1px solid #2a2a2a;
                    border-top:3px solid ${hex};
                    border-radius:9px;
                ">
                    <div style="
                        color:${hex};
                        font-weight:800;
                    ">
                        ♡ ${
                            escapeHTML(
                                values.name ||
                                'CHARACTER'
                            )
                        }
                    </div>

                    <div style="
                        color:#777;
                        font-size:.75em;
                        margin-top:3px;
                    ">
                        ${
                            escapeHTML(
                                values.relationship ||
                                'RELATIONSHIP'
                            )
                        }
                    </div>

                    <div style="
                        margin-top:9px;
                        color:#aaa;
                    ">
                        ${escapeHTML(
                            values.description ||
                            'Relationship description...'
                        )}
                    </div>
                </div>
            `,

            validate: values => {
                if (
                    !values.name.trim() ||
                    !values.relationship.trim()
                ) {
                    showToast(
                        'Please enter the character and relationship.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<div style="
    margin:16px 0;
    padding:16px;
    background:#111;
    border:1px solid #292929;
    border-top:3px solid ${hex};
    border-radius:10px;
">
    <div style="
        color:${hex};
        font-weight:800;
        font-size:1.05em;
    ">
        ♡ ${escapeHTML(
            values.name.trim()
        )}
    </div>

    <div style="
        color:#777;
        font-size:.75em;
        margin-top:3px;
        letter-spacing:1px;
        text-transform:uppercase;
    ">
        ${escapeHTML(
            values.relationship.trim()
        )}
    </div>

    ${
        values.description.trim()
            ? `
                <div style="
                    margin-top:10px;
                    color:#aaa;
                    line-height:1.6;
                ">
                    ${escapeHTML(
                        values.description.trim()
                    )}
                </div>
            `
            : ''
    }
</div>
`);
            }
        },

        // --------------------------------------------------------
        // DIALOGUE
        // --------------------------------------------------------

        {
            name: '◌ Dialogue',

            fields: [
                {
                    key: 'charName',
                    label: 'Character Name',
                    placeholder:
                        'Character'
                },

                {
                    key: 'charText',
                    label: 'Character Dialogue',
                    type: 'textarea',
                    placeholder:
                        'What does the character say?',
                    rows: 3
                },

                {
                    key: 'responderName',
                    label: 'Your Name',
                    placeholder:
                        'YOU'
                },

                {
                    key: 'responderText',
                    label: 'Your Dialogue',
                    type: 'textarea',
                    placeholder:
                        'What do you say?',
                    rows: 3
                }
            ],

            preview: (values, hex) => `
                <div style="
                    display:flex;
                    flex-direction:column;
                    gap:10px;
                ">
                    <div
                        style="
                            align-self:flex-start;
                            max-width:85%;
                        "
                    >
                        <div style="
                            color:${hex};
                            font-size:.7em;
                            font-weight:700;
                            margin-bottom:3px;
                        ">
                            ${
                                escapeHTML(
                                    values.charName ||
                                    'CHARACTER'
                                )
                            }
                        </div>

                        <div style="
                            background:#111;
                            border-left:3px solid ${hex};
                            padding:10px 12px;
                            border-radius:8px;
                            color:#ccc;
                        ">
                            ${
                                escapeHTML(
                                    values.charText ||
                                    'Character dialogue...'
                                )
                            }
                        </div>
                    </div>

                    <div
                        style="
                            align-self:flex-end;
                            max-width:85%;
                            text-align:right;
                        "
                    >
                        <div style="
                            color:#777;
                            font-size:.7em;
                            font-weight:700;
                            margin-bottom:3px;
                        ">
                            ${
                                escapeHTML(
                                    values.responderName ||
                                    'YOU'
                                )
                            }
                        </div>

                        <div style="
                            background:#151515;
                            border-right:3px solid #555;
                            padding:10px 12px;
                            border-radius:8px;
                            color:#aaa;
                        ">
                            ${
                                escapeHTML(
                                    values.responderText ||
                                    'Your dialogue...'
                                )
                            }
                        </div>
                    </div>
                </div>
            `,

            validate: values => {

                if (
                    !values.charName.trim() ||
                    !values.charText.trim() ||
                    !values.responderText.trim()
                ) {
                    showToast(
                        'Please complete the dialogue.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                const charName =
                    escapeHTML(
                        values.charName.trim()
                    );

                const charText =
                    escapeHTML(
                        values.charText.trim()
                    );

                const responderName =
                    escapeHTML(
                        values.responderName.trim() ||
                        'YOU'
                    );

                const responderText =
                    escapeHTML(
                        values.responderText.trim()
                    );

                injectText(`
<div style="
    display:flex;
    flex-direction:column;
    gap:14px;
    margin:24px 0;
    font-size:.95em;
">

    <div style="
        display:flex;
        flex-direction:column;
        align-items:flex-start;
    ">
        <div style="
            color:${hex};
            font-size:.75em;
            font-weight:bold;
            margin-bottom:4px;
            margin-left:4px;
            letter-spacing:1px;
            text-transform:uppercase;
        ">
            ${charName}
        </div>

        <div style="
            background:#111;
            border:1px solid #222;
            border-left:3px solid ${hex};
            border-radius:12px 12px 12px 2px;
            padding:12px 16px;
            color:#ddd;
            max-width:85%;
            line-height:1.6;
            box-shadow:0 4px 10px rgba(0,0,0,.25);
        ">
            "${charText}"
        </div>
    </div>

    <div style="
        display:flex;
        flex-direction:column;
        align-items:flex-end;
    ">
        <div style="
            color:#777;
            font-size:.75em;
            font-weight:bold;
            margin-bottom:4px;
            margin-right:4px;
            letter-spacing:1px;
            text-transform:uppercase;
        ">
            ${responderName.toUpperCase()}
        </div>

        <div style="
            background:#151515;
            border:1px solid #2a2a2a;
            border-right:3px solid #555;
            border-radius:12px 12px 2px 12px;
            padding:12px 16px;
            color:#bbb;
            max-width:85%;
            line-height:1.6;
            text-align:right;
            box-shadow:0 4px 10px rgba(0,0,0,.25);
        ">
            "${responderText}"
        </div>
    </div>

</div>
`);
            }
        },

        // --------------------------------------------------------
        // CHARACTER HEADER
        // --------------------------------------------------------

        {
            name: '♙ Character Header',

            fields: [
                {
                    key: 'name',
                    label: 'Character Name',
                    placeholder:
                        'Character name'
                },

                {
                    key: 'title',
                    label: 'Title / Role',
                    placeholder:
                        'THE HEAD MAID'
                },

                {
                    key: 'tagline',
                    label: 'Tagline',
                    placeholder:
                        'Steady. Formal. Unreadable.'
                }
            ],

            preview: (values, hex) => `
                <div style="
                    padding:18px;
                    text-align:center;
                    border:1px solid #2a2a2a;
                    border-top:3px solid ${hex};
                    background:#101010;
                ">
                    <div style="
                        color:#777;
                        font-size:.65em;
                        letter-spacing:3px;
                    ">
                        ${escapeHTML(
                            values.title ||
                            'CHARACTER'
                        )}
                    </div>

                    <div style="
                        margin:6px 0;
                        color:${hex};
                        font-size:1.5em;
                        font-weight:800;
                    ">
                        ${escapeHTML(
                            values.name ||
                            'NAME'
                        )}
                    </div>

                    <div style="
                        color:#999;
                        font-style:italic;
                    ">
                        ${escapeHTML(
                            values.tagline ||
                            'Tagline'
                        )}
                    </div>
                </div>
            `,

            validate: values => {
                if (!values.name.trim()) {
                    showToast(
                        'Please enter a character name.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<div style="
    margin:28px 0;
    padding:24px 18px;
    text-align:center;
    border:1px solid #2a2a2a;
    border-top:3px solid ${hex};
    border-radius:10px;
    background:
        radial-gradient(
            circle at 50% 0%,
            ${hex}18,
            transparent 55%
        ),
        #101010;
">
    ${
        values.title.trim()
            ? `
                <div style="
                    color:#777;
                    font-size:.68em;
                    letter-spacing:3px;
                    text-transform:uppercase;
                ">
                    ${escapeHTML(
                        values.title.trim()
                    )}
                </div>
            `
            : ''
    }

    <div style="
        margin:7px 0;
        color:${hex};
        font-size:1.6em;
        font-weight:800;
        letter-spacing:1px;
    ">
        ${escapeHTML(
            values.name.trim()
        )}
    </div>

    ${
        values.tagline.trim()
            ? `
                <div style="
                    color:#999;
                    font-style:italic;
                ">
                    ${escapeHTML(
                        values.tagline.trim()
                    )}
                </div>
            `
            : ''
    }
</div>
`);
            }
        },

        // --------------------------------------------------------
        // BADGE
        // --------------------------------------------------------

        {
            name: '◆ Badge / Tag',

            fields: [
                {
                    key: 'text',
                    label: 'Badge Text',
                    placeholder:
                        'HEAD MAID'
                },

                {
                    key: 'style',
                    label: 'Style',
                    type: 'select',
                    options: [
                        'Gold',
                        'Danger',
                        'System',
                        'Ghost'
                    ],
                    default: 'Gold'
                }
            ],

            preview: (values, hex) => {
                const color =
                    badgeStyleColor(
                        values.style,
                        hex
                    );

                return `
                <span style="
                    display:inline-block;
                    padding:6px 12px;
                    border:1px solid ${color};
                    border-radius:999px;
                    color:${color};
                    font-size:.7em;
                    font-weight:800;
                    letter-spacing:1.5px;
                ">
                    ${escapeHTML(
                        values.text ||
                        'BADGE'
                    )}
                </span>
            `;
            },

            validate: values => {
                if (!values.text.trim()) {
                    showToast(
                        'Please enter badge text.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                const color =
                    badgeStyleColor(
                        values.style,
                        hex
                    );

                injectText(`
<span style="
    display:inline-block;
    margin:6px 4px;
    padding:6px 12px;
    border:1px solid ${color};
    border-radius:999px;
    color:${color};
    background:${color}12;
    font-size:.68em;
    font-weight:800;
    letter-spacing:1.5px;
    text-transform:uppercase;
">
    ${escapeHTML(
        values.text.trim()
    )}
</span>
`);
            }
        },

        // --------------------------------------------------------
        // LORE ENTRY
        // --------------------------------------------------------

        {
            name: '▤ Lore Entry',

            fields: [
                {
                    key: 'title',
                    label: 'Lore Title',
                    placeholder:
                        'Origins'
                },

                {
                    key: 'content',
                    label: 'Lore',
                    type: 'textarea',
                    placeholder:
                        'Write the lore entry...',
                    rows: 7
                }
            ],

            preview: (values, hex) => `
                <div style="
                    padding:16px;
                    border-left:2px solid ${hex};
                    background:#0f0f10;
                ">
                    <div style="
                        color:${hex};
                        font-size:.75em;
                        font-weight:800;
                        letter-spacing:1.5px;
                        text-transform:uppercase;
                        margin-bottom:8px;
                    ">
                        ${escapeHTML(
                            values.title ||
                            'LORE'
                        )}
                    </div>

                    <div style="
                        color:#aaa;
                        line-height:1.65;
                    ">
                        ${escapeHTML(
                            values.content ||
                            'Lore text...'
                        )}
                    </div>
                </div>
            `,

            validate: values => {
                if (
                    !values.title.trim() ||
                    !values.content.trim()
                ) {
                    showToast(
                        'Please complete the lore entry.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<div style="
    margin:24px 0;
    padding:18px;
    border-left:2px solid ${hex};
    background:
        linear-gradient(
            90deg,
            ${hex}08,
            transparent
        );
">
    <div style="
        color:${hex};
        font-size:.72em;
        font-weight:800;
        letter-spacing:2px;
        text-transform:uppercase;
        margin-bottom:9px;
    ">
        ${escapeHTML(
            values.title.trim()
        )}
    </div>

    <div style="
        color:#aaa;
        line-height:1.7;
    ">
        ${escapeHTML(
            values.content.trim()
        )}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // TIMELINE
        // --------------------------------------------------------

        {
            name: '◷ Timeline Event',

            fields: [
                {
                    key: 'date',
                    label: 'Date / Era',
                    placeholder:
                        'YEAR 01'
                },

                {
                    key: 'title',
                    label: 'Event',
                    placeholder:
                        'The Estate Was Founded'
                },

                {
                    key: 'description',
                    label: 'Description',
                    type: 'textarea',
                    placeholder:
                        'What happened?',
                    rows: 4
                }
            ],

            preview: (values, hex) => `
                <div style="
                    display:grid;
                    grid-template-columns:70px 1fr;
                    gap:12px;
                ">
                    <div style="
                        color:${hex};
                        font-weight:800;
                        font-size:.75em;
                    ">
                        ${escapeHTML(
                            values.date ||
                            'DATE'
                        )}
                    </div>

                    <div style="
                        border-left:1px solid #333;
                        padding-left:12px;
                    ">
                        <strong
                            style="
                                color:#ddd;
                            "
                        >
                            ${escapeHTML(
                                values.title ||
                                'EVENT'
                            )}
                        </strong>

                        <div style="
                            color:#888;
                            margin-top:5px;
                        ">
                            ${escapeHTML(
                                values.description ||
                                'Description...'
                            )}
                        </div>
                    </div>
                </div>
            `,

            validate: values => {
                if (
                    !values.title.trim() ||
                    !values.description.trim()
                ) {
                    showToast(
                        'Please complete the timeline event.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<div style="
    display:grid;
    grid-template-columns:80px 1fr;
    gap:14px;
    margin:18px 0;
">
    <div style="
        color:${hex};
        font-size:.72em;
        font-weight:800;
        padding-top:2px;
        letter-spacing:1px;
    ">
        ${escapeHTML(
            values.date.trim() ||
            'EVENT'
        )}
    </div>

    <div style="
        border-left:1px solid #333;
        padding-left:16px;
    ">
        <div style="
            color:#ddd;
            font-weight:700;
        ">
            ${escapeHTML(
                values.title.trim()
            )}
        </div>

        <div style="
            color:#888;
            margin-top:6px;
            line-height:1.6;
        ">
            ${escapeHTML(
                values.description.trim()
            )}
        </div>
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // SCENE HEADER
        // --------------------------------------------------------

        {
            name: '✦ Scene Header',

            fields: [
                {
                    key: 'title',
                    label: 'Scene Title',
                    placeholder:
                        'RAIN AND ROUTINE'
                },

                {
                    key: 'subtitle',
                    label: 'Subtitle',
                    placeholder:
                        'The estate settles into another quiet evening.'
                }
            ],

            preview: (values, hex) => `
                <div style="
                    padding:20px 0;
                    text-align:center;
                ">
                    <div style="
                        color:#555;
                        letter-spacing:4px;
                    ">
                        ✦
                    </div>

                    <div style="
                        margin:7px 0;
                        color:${hex};
                        font-size:1.15em;
                        font-weight:800;
                        letter-spacing:2px;
                    ">
                        ${escapeHTML(
                            values.title ||
                            'SCENE TITLE'
                        )}
                    </div>

                    <div style="
                        color:#777;
                        font-style:italic;
                    ">
                        ${escapeHTML(
                            values.subtitle ||
                            'Scene subtitle...'
                        )}
                    </div>
                </div>
            `,

            validate: values => {
                if (!values.title.trim()) {
                    showToast(
                        'Please enter a scene title.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<div style="
    margin:34px 0 26px;
    padding:20px 0;
    text-align:center;
    border-top:1px solid ${hex}44;
    border-bottom:1px solid ${hex}22;
">
    <div style="
        color:${hex};
        font-size:.65em;
        letter-spacing:4px;
    ">
        ✦
    </div>

    <div style="
        margin:7px 0;
        color:${hex};
        font-size:1.15em;
        font-weight:800;
        letter-spacing:2px;
        text-transform:uppercase;
    ">
        ${escapeHTML(
            values.title.trim()
        )}
    </div>

    ${
        values.subtitle.trim()
            ? `
                <div style="
                    color:#777;
                    font-style:italic;
                ">
                    ${escapeHTML(
                        values.subtitle.trim()
                    )}
                </div>
            `
            : ''
    }
</div>
`);
            }
        },

        // --------------------------------------------------------
        // TERMINAL LOG
        // --------------------------------------------------------

        {
            name: '>_ Terminal Log',

            fields: [
                {
                    key: 'label',
                    label: 'System Label',
                    placeholder:
                        'SYSTEM'
                },

                {
                    key: 'message',
                    label: 'Message',
                    type: 'textarea',
                    placeholder:
                        'Connection established...',
                    rows: 4
                },

                {
                    key: 'status',
                    label: 'Status',
                    type: 'select',
                    options: [
                        'ONLINE',
                        'WARNING',
                        'ERROR',
                        'OFFLINE'
                    ],
                    default: 'ONLINE'
                }
            ],

            preview: (values, hex) => {

                const color =
                    values.status === 'ERROR'
                        ? '#d55'
                        : values.status === 'WARNING'
                            ? '#d9a441'
                            : hex;

                return `
                    <div style="
                        background:#080a0b;
                        border:1px solid #252b2d;
                        padding:14px;
                        font-family:monospace;
                    ">
                        <div style="
                            color:${color};
                            font-size:.7em;
                            margin-bottom:8px;
                        ">
                            [${escapeHTML(
                                values.status ||
                                'ONLINE'
                            )}]
                        </div>

                        <div style="
                            color:#8da28f;
                        ">
                            ${escapeHTML(
                                values.message ||
                                'System message...'
                            )}
                        </div>
                    </div>
                `;
            },

            validate: values => {
                if (!values.message.trim()) {
                    showToast(
                        'Please enter a terminal message.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                const color =
                    values.status === 'ERROR'
                        ? '#d55'
                        : values.status === 'WARNING'
                            ? '#d9a441'
                            : values.status === 'OFFLINE'
                                ? '#777'
                                : hex;

                injectText(`
<div style="
    margin:20px 0;
    padding:16px;
    background:#080a0b;
    border:1px solid #252b2d;
    border-left:2px solid ${color};
    font-family:monospace;
">
    <div style="
        color:${color};
        font-size:.7em;
        margin-bottom:9px;
        letter-spacing:1px;
    ">
        [${escapeHTML(
            values.status
        )}]
        ${escapeHTML(
            values.label.trim() ||
            'SYSTEM'
        )}
    </div>

    <div style="
        color:#8da28f;
        line-height:1.7;
        white-space:pre-wrap;
    ">
        ${escapeHTML(
            values.message.trim()
        )}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // STAT SHEET
        // --------------------------------------------------------

        {
            name: '▥ Stat Sheet',

            fields: [
                {
                    key: 'title',
                    label: 'Sheet Title',
                    placeholder:
                        'CHARACTER PROFILE'
                },

                {
                    key: 'stats',
                    label: 'Stats',
                    type: 'textarea',
                    placeholder:
                        'Strength: 80\nAgility: 65\nIntelligence: 90',
                    rows: 7
                }
            ],

            preview: (values, hex) => {

                const lines =
                    String(
                        values.stats || ''
                    )
                        .split('\n')
                        .filter(Boolean)
                        .slice(0, 5);

                return `
                    <div style="
                        padding:14px;
                        background:#111;
                        border:1px solid #2a2a2a;
                    ">
                        <div style="
                            color:${hex};
                            font-weight:800;
                            letter-spacing:1px;
                            margin-bottom:10px;
                        ">
                            ${escapeHTML(
                                values.title ||
                                'CHARACTER PROFILE'
                            )}
                        </div>

                        ${lines
                            .map(line => {

                                const parts =
                                    line.split(':');

                                return `
                                    <div style="
                                        display:flex;
                                        justify-content:space-between;
                                        border-top:1px solid #222;
                                        padding:7px 0;
                                    ">
                                        <span>
                                            ${escapeHTML(
                                                parts[0]
                                            )}
                                        </span>

                                        <strong
                                            style="
                                                color:${hex};
                                            "
                                        >
                                            ${escapeHTML(
                                                parts
                                                    .slice(1)
                                                    .join(':')
                                                    .trim() ||
                                                '—'
                                            )}
                                        </strong>
                                    </div>
                                `;
                            })
                            .join('')}
                    </div>
                `;
            },

            validate: values => {
                if (!values.stats.trim()) {
                    showToast(
                        'Add at least one stat.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                const rows =
                    values.stats
                        .split('\n')
                        .map(line =>
                            line.trim()
                        )
                        .filter(Boolean);

                injectText(`
<div style="
    margin:24px 0;
    padding:18px;
    background:#111;
    border:1px solid #292929;
    border-top:3px solid ${hex};
    border-radius:10px;
">
    ${
        values.title.trim()
            ? `
                <div style="
                    color:${hex};
                    font-weight:800;
                    letter-spacing:1px;
                    margin-bottom:10px;
                ">
                    ${escapeHTML(
                        values.title.trim()
                    )}
                </div>
            `
            : ''
    }

    ${rows
        .map(line => {

            const parts =
                line.split(':');

            const label =
                parts.shift()
                    ?.trim() ||
                '';

            const value =
                parts.join(':')
                    .trim();

            return `
                <div style="
                    display:flex;
                    justify-content:space-between;
                    gap:20px;
                    padding:8px 0;
                    border-top:1px solid #222;
                ">
                    <span style="
                        color:#aaa;
                    ">
                        ${escapeHTML(
                            label
                        )}
                    </span>

                    <strong style="
                        color:${hex};
                    ">
                        ${escapeHTML(
                            value
                        )}
                    </strong>
                </div>
            `;
        })
        .join('')}
</div>
`);
            }
        },

        // --------------------------------------------------------
        // CLASSIFIED FILE
        // --------------------------------------------------------

        {
            name: '▣ Classified File',

            fields: [
                {
                    key: 'classification',
                    label: 'Classification',
                    placeholder:
                        'TOP SECRET'
                },

                {
                    key: 'title',
                    label: 'File Title',
                    placeholder:
                        'SUBJECT: UNKNOWN'
                },

                {
                    key: 'content',
                    label: 'File Content',
                    type: 'textarea',
                    placeholder:
                        'Classified information...',
                    rows: 6
                }
            ],

            preview: (values, hex) => `
                <div style="
                    padding:16px;
                    background:#111;
                    border:1px solid #333;
                    position:relative;
                ">
                    <div style="
                        display:flex;
                        justify-content:space-between;
                        color:#777;
                        font-size:.65em;
                        letter-spacing:2px;
                    ">
                        <span>
                            ${escapeHTML(
                                values.classification ||
                                'CLASSIFIED'
                            )}
                        </span>

                        <span>
                            OBELISK
                        </span>
                    </div>

                    <div style="
                        margin:14px 0 8px;
                        color:${hex};
                        font-weight:800;
                    ">
                        ${escapeHTML(
                            values.title ||
                            'FILE TITLE'
                        )}
                    </div>

                    <div style="
                        color:#999;
                        line-height:1.6;
                    ">
                        ${escapeHTML(
                            values.content ||
                            'Classified information...'
                        )}
                    </div>
                </div>
            `,

            validate: values => {

                if (
                    !values.title.trim() ||
                    !values.content.trim()
                ) {
                    showToast(
                        'Please complete the classified file.',
                        'error'
                    );

                    return false;
                }

                return true;
            },

            onSubmit: (values, hex) => {

                injectText(`
<div style="
    position:relative;
    margin:26px 0;
    padding:20px;
    background:#111;
    border:1px solid #333;
    border-top:3px solid ${hex};
    border-radius:3px;
    box-shadow:0 10px 30px rgba(0,0,0,.3);
">
    <div style="
        display:flex;
        justify-content:space-between;
        gap:12px;
        color:#666;
        font-size:.62em;
        letter-spacing:2px;
        text-transform:uppercase;
    ">
        <span>
            ${escapeHTML(
                values.classification.trim() ||
                'CLASSIFIED'
            )}
        </span>

        <span>
            OBELISK
        </span>
    </div>

    <div style="
        margin:16px 0 10px;
        color:${hex};
        font-weight:900;
        letter-spacing:1px;
        font-size:1.05em;
    ">
        ${escapeHTML(
            values.title.trim()
        )}
    </div>

    <div style="
        color:#999;
        line-height:1.7;
        white-space:pre-wrap;
    ">
        ${escapeHTML(
            values.content.trim()
        )}
    </div>

    <div style="
        margin-top:16px;
        padding-top:10px;
        border-top:1px solid #252525;
        color:#444;
        font-size:.6em;
        letter-spacing:2px;
    ">
        ACCESS RESTRICTED
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // STYLED TEXT BLOCK (PRO)
        // --------------------------------------------------------
        {
            name: '📝 Styled Text',
            fields: [
                {
                    key: 'font',
                    label: 'Font Style',
                    type: 'select',
                    options: Object.entries(OBELISK_WEB_FONTS).map(
                        ([value, f]) => ({ label: f.label, value })
                    ),
                    default: 'inherit'
                },
                {
                    key: 'align',
                    label: 'Alignment',
                    type: 'select',
                    options: ['left', 'center', 'right', 'justify'],
                    default: 'left'
                },
                {
                    key: 'size',
                    label: 'Text Size (%)',
                    type: 'range',
                    min: 70,
                    max: 200,
                    default: 100
                },
                {
                    key: 'spacing',
                    label: 'Letter Spacing (px)',
                    type: 'range',
                    min: 0,
                    max: 10,
                    default: 0
                },
                {
                    key: 'textColor',
                    label: 'Text Color Override',
                    placeholder: '#cccccc (Leave blank for default)'
                },
                {
                    key: 'content',
                    label: 'Text Content (Supports Markdown)',
                    type: 'textarea',
                    placeholder: 'Type your styled text here...',
                    rows: 4
                }
            ],
            preview: (values, hex) => {
                const color = values.textColor && values.textColor.trim() !== '' ? escapeHTML(values.textColor.trim()) : '#ccc';
                const font = OBELISK_WEB_FONTS[values.font] || OBELISK_WEB_FONTS.inherit;
                return `
                ${obeliskFontImportTag(values.font)}
                <div style="font-family:${font.family}; text-align:${escapeHTML(values.align)}; font-size:${values.size}%; letter-spacing:${values.spacing}px; color:${color}; padding: 10px;">
                    ${escapeHTML(values.content || 'Preview your text here...')}
                </div>
                `;
            },
            validate: values => values.content.trim() ? true : (showToast('Enter text.', 'error'), false),
            onSubmit: (values, hex) => {
                const color = values.textColor.trim() ? escapeHTML(values.textColor.trim()) : '#ccc';
                const font = OBELISK_WEB_FONTS[values.font] || OBELISK_WEB_FONTS.inherit;
                injectText(`
${obeliskFontImportTag(values.font)}<div style="margin:20px 0; font-family:${font.family}; text-align:${values.align}; font-size:${values.size}%; letter-spacing:${values.spacing}px; color:${color}; line-height:1.7;">
    ${escapeHTML(values.content.trim())}
</div>
`);
            }
        },

        // --------------------------------------------------------
        // THEME: CUTECORE (UPGRADED)
        // --------------------------------------------------------
        {
            name: '🎀 Cutecore Box',
            fields: [
                {
                    key: 'flavor',
                    label: 'Aesthetic Palette',
                    type: 'select',
                    options: [
                        { label: 'Strawberry (Pink)', value: 'pink' },
                        { label: 'Lavender (Purple)', value: 'purple' },
                        { label: 'Mint (Green)', value: 'green' }
                    ],
                    default: 'pink'
                },
                {
                    key: 'banner',
                    label: 'Decoration',
                    type: 'select',
                    options: ['✧･ﾟ: *✧･ﾟ:*', '🌸 🎀 🌸', '🍓 🍰 🍓', '☁️ ✨ ☁️'],
                    default: '✧･ﾟ: *✧･ﾟ:*'
                },
                { key: 'title', label: 'Cute Header', placeholder: 'Welcome!' },
                { key: 'content', label: 'Message', type: 'textarea', placeholder: 'Something sweet...', rows: 3 }
            ],
            preview: (values, hex) => {
                const palettes = {
                    pink: { bg: '#fff0f5', border: '#ffb6c1', textTop: '#ff69b4', textBody: '#ff91a4' },
                    purple: { bg: '#f4f0ff', border: '#d8b4fe', textTop: '#a855f7', textBody: '#c084fc' },
                    green: { bg: '#f0fdf4', border: '#bbf7d0', textTop: '#22c55e', textBody: '#4ade80' }
                };
                const p = palettes[values.flavor] || palettes.pink;
                return `
                <div style="background:${p.bg}; border:2px dotted ${p.border}; border-radius:12px; padding:12px; text-align:center; color:${p.textTop};">
                    <div style="font-size:0.7em; margin-bottom:5px;">${escapeHTML(values.banner)}</div>
                    <strong>${escapeHTML(values.title || 'Header')}</strong>
                    <div style="color:${p.textBody}; font-size:0.85em; margin-top:4px;">${escapeHTML(values.content || 'Content...')}</div>
                </div>
                `;
            },
            validate: values => values.content.trim() ? true : (showToast('Enter content.', 'error'), false),
            onSubmit: (values, hex) => {
                const palettes = {
                    pink: { bg: '#fff0f5', border: '#ffb6c1', textTop: '#ff69b4', textBody: '#ff91a4' },
                    purple: { bg: '#f4f0ff', border: '#d8b4fe', textTop: '#a855f7', textBody: '#c084fc' },
                    green: { bg: '#f0fdf4', border: '#bbf7d0', textTop: '#22c55e', textBody: '#4ade80' }
                };
                const p = palettes[values.flavor] || palettes.pink;

                injectText(`
<div style="margin:24px auto; max-width:85%; background:${p.bg}; border:3px dotted ${p.border}; border-radius:24px; padding:20px; text-align:center; box-shadow:0 8px 20px rgba(0,0,0,0.05);">
    <div style="color:${p.textTop}; font-size:1.1em; letter-spacing:2px; margin-bottom:4px;">
        ${values.banner}
    </div>
    <div style="color:${p.textTop}; font-size:1.3em; font-weight:900; letter-spacing:1px; margin-bottom:10px;">
        ${escapeHTML(values.title.trim() || '✧')}
    </div>
    <div style="color:${p.textBody}; line-height:1.6; font-size:0.95em;">
        ${escapeHTML(values.content.trim())}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // THEME: ROMANCE LETTER (UPGRADED)
        // --------------------------------------------------------
        {
            name: '💌 Romance Letter',
            fields: [
                {
                    key: 'paper',
                    label: 'Paper Stock',
                    type: 'select',
                    options: [
                        { label: 'Classic Cream', value: 'cream' },
                        { label: 'Rose Water', value: 'rose' },
                        { label: 'Old Parchment', value: 'parchment' }
                    ],
                    default: 'cream'
                },
                { key: 'greeting', label: 'Greeting', placeholder: 'My Dearest,' },
                { key: 'content', label: 'Letter Body', type: 'textarea', placeholder: 'Write your heart out...', rows: 4 },
                { key: 'signoff', label: 'Sign-off', placeholder: 'Forever yours,' },
                { key: 'seal', label: 'Wax Seal Initial (1 Letter)', placeholder: 'F' }
            ],
            preview: (values, hex) => {
                const papers = {
                    cream: { bg: '#faf8f5', border: '#e8e0d5', top: '#d4a373', text: '#5a4f44', wax: '#8a2b2b' },
                    rose: { bg: '#fff5f5', border: '#fed7d7', top: '#fc8181', text: '#704a4a', wax: '#b83232' },
                    parchment: { bg: '#f3eadd', border: '#d4c4b7', top: '#8c7a6b', text: '#3e362e', wax: '#4a0e0e' }
                };
                const p = papers[values.paper] || papers.cream;
                const initial = (values.seal || '♥').trim().charAt(0).toUpperCase();

                return `
                <div style="background:${p.bg}; border:1px solid ${p.border}; border-top:3px solid ${p.top}; padding:12px; font-family:Georgia, serif; color:${p.text}; position:relative;">
                    <em>${escapeHTML(values.greeting || 'Greeting,')}</em><br>
                    <div style="font-size:0.8em; margin-top:5px; line-height:1.4;">${escapeHTML(values.content || 'Body...')}</div>
                    <div style="text-align:right; margin-top:8px; font-style:italic; color:${p.top}; font-size:0.9em;">${escapeHTML(values.signoff || 'Sign-off')}</div>
                    <div style="position:absolute; bottom:5px; right:5px; width:22px; height:22px; background:${p.wax}; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; font-size:11px;">${initial}</div>
                </div>
                `;
            },
            validate: values => values.content.trim() ? true : (showToast('Enter letter content.', 'error'), false),
            onSubmit: (values, hex) => {
                const papers = {
                    cream: { bg: '#faf8f5', border: '#e8e0d5', top: '#d4a373', text: '#5a4f44', wax: '#8a2b2b' },
                    rose: { bg: '#fff5f5', border: '#fed7d7', top: '#fc8181', text: '#704a4a', wax: '#b83232' },
                    parchment: { bg: '#f3eadd', border: '#d4c4b7', top: '#8c7a6b', text: '#3e362e', wax: '#4a0e0e' }
                };
                const p = papers[values.paper] || papers.cream;
                const initial = values.seal.trim().charAt(0).toUpperCase() || '♥';

                injectText(`
<div style="margin:24px auto; max-width:90%; background:${p.bg}; border:1px solid ${p.border}; border-top:4px solid ${p.top}; padding:30px 30px 45px 30px; font-family:Georgia, 'Times New Roman', serif; color:${p.text}; box-shadow:0 10px 25px rgba(0,0,0,0.1); position:relative;">
    <div style="font-style:italic; font-size:1.1em; margin-bottom:16px;">
        ${escapeHTML(values.greeting.trim())}
    </div>
    <div style="line-height:1.8; font-size:0.95em; white-space:pre-wrap;">
        ${escapeHTML(values.content.trim())}
    </div>
    <div style="margin-top:20px; font-style:italic; text-align:right; font-size:1.05em; color:${p.top};">
        ${escapeHTML(values.signoff.trim())}
    </div>
    <div style="position:absolute; bottom:-20px; right:30px; width:40px; height:40px; background:${p.wax}; border-radius:50%; box-shadow: inset 0 0 10px rgba(0,0,0,0.5), 0 4px 6px rgba(0,0,0,0.3); display:flex; align-items:center; justify-content:center; color:#fff; font-family:serif; font-style:italic; font-size:1.2em; border:2px solid rgba(255,255,255,0.1);">
        ${initial}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // THEME: ABYSSAL LOG (UPGRADED)
        // --------------------------------------------------------
        {
            name: '👁️ Abyssal Log',
            fields: [
                {
                    key: 'anomaly',
                    label: 'Anomaly Type',
                    type: 'select',
                    options: [
                        { label: 'Blood / Flesh', value: 'blood' },
                        { label: 'Deep Ocean / Drown', value: 'ocean' },
                        { label: 'The Void / Static', value: 'void' }
                    ],
                    default: 'blood'
                },
                {
                    key: 'glitch',
                    label: 'Distortion Level',
                    type: 'select',
                    options: [
                        { label: 'Level 1: Uneasy', value: 'minor' },
                        { label: 'Level 2: Corrupted', value: 'heavy' }
                    ],
                    default: 'minor'
                },
                { key: 'title', label: 'Fragment Name', placeholder: 'MADNESS_LOG.TXT' },
                { key: 'content', label: 'Psychological Horror Text', type: 'textarea', placeholder: 'They are in the walls...', rows: 4 }
            ],
            preview: (values, hex) => {
                const types = {
                    blood: { line: '#8a0303', title: '#d41111', text: '#b3b3b3' },
                    ocean: { line: '#064e3b', title: '#14b8a6', text: '#94a3b8' },
                    void: { line: '#333333', title: '#ffffff', text: '#666666' }
                };
                const t = types[values.anomaly] || types.blood;
                const glitchEffect = values.glitch === 'heavy' ? `text-shadow: -1px 0 ${t.title}80, 1px 0 #00f8; letter-spacing: -0.5px;` : `text-shadow: 0 0 2px rgba(255,255,255,0.2);`;

                return `
                <div style="background:#000; border:1px solid #111; border-left:3px solid ${t.line}; padding:12px; font-family:monospace; color:${t.text};">
                    <strong style="color:${t.title}; letter-spacing:2px; ${glitchEffect}">${escapeHTML(values.title || 'TITLE')}</strong>
                    <div style="font-size:0.8em; margin-top:5px; ${glitchEffect}">${escapeHTML(values.content || 'Content...')}</div>
                </div>
                `;
            },
            validate: values => values.content.trim() ? true : (showToast('Enter eerie content.', 'error'), false),
            onSubmit: (values, hex) => {
                const types = {
                    blood: { line: '#8a0303', title: '#d41111', text: '#b3b3b3', glow: 'rgba(100,0,0,0.15)' },
                    ocean: { line: '#064e3b', title: '#14b8a6', text: '#94a3b8', glow: 'rgba(0,50,50,0.15)' },
                    void: { line: '#333333', title: '#ffffff', text: '#666666', glow: 'rgba(255,255,255,0.05)' }
                };
                const t = types[values.anomaly] || types.blood;
                const glitchEffect = values.glitch === 'heavy' 
                    ? `text-shadow: -2px 0 ${t.title}40, 2px 0 #00f4; letter-spacing: -0.5px;` 
                    : `text-shadow: 0 0 2px rgba(255,255,255,0.1);`;

                injectText(`
<div style="margin:24px 0; background:#000; border:1px solid #111; border-left:4px solid ${t.line}; padding:24px; font-family:'Courier New', Courier, monospace; color:${t.text}; box-shadow: inset 0 0 40px ${t.glow}, 0 10px 30px rgba(0,0,0,0.9);">
    <div style="color:${t.title}; font-weight:bold; letter-spacing:6px; margin-bottom:14px; text-shadow: 2px 0 4px ${t.line};">
        [ ${escapeHTML(values.title.trim())} ]
    </div>
    <div style="line-height:1.8; font-size:0.95em; white-space:pre-wrap; ${glitchEffect}">
        ${escapeHTML(values.content.trim())}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // NOW PLAYING WIDGET (VISUAL THEME SONG)
        // --------------------------------------------------------
        {
            name: '💿 Now Playing',
            fields: [
                { key: 'cover', label: 'Album Cover URL', placeholder: 'https://...' },
                { key: 'title', label: 'Song Title', placeholder: 'Bury the Light' },
                { key: 'artist', label: 'Artist Name', placeholder: 'Casey Edwards' },
                { key: 'time', label: 'Timestamp (e.g. 1:45)', placeholder: '1:45' }
            ],
            preview: (values, hex) => {
                const cover = values.cover && values.cover.trim() !== '' ? escapeHTML(values.cover) : 'https://placehold.co/100x100/111/333?text=COVER';
                return `
                <div style="display:flex; align-items:center; gap:12px; background:#111; padding:12px; border-radius:12px; border:1px solid #222;">
                    <img src="${cover}" style="width:45px; height:45px; border-radius:6px; object-fit:cover;">
                    <div style="flex:1;">
                        <strong style="color:#eee; font-size:11px;">${escapeHTML(values.title || 'Song Title')}</strong>
                        <div style="color:#888; font-size:9px;">${escapeHTML(values.artist || 'Artist')}</div>
                        <div style="height:3px; background:#333; margin-top:6px; border-radius:2px;"><div style="width:40%; height:100%; background:${hex}; border-radius:2px;"></div></div>
                    </div>
                </div>
                `;
            },
            validate: values => values.title.trim() ? true : (showToast('Enter a song title.', 'error'), false),
            onSubmit: (values, hex) => {
                const cover = values.cover && values.cover.trim() !== '' ? escapeHTML(values.cover) : 'https://placehold.co/200x200/111/333?text=COVER';
                const title = escapeHTML(values.title.trim());
                const artist = escapeHTML(values.artist.trim() || 'Unknown Artist');
                const time = escapeHTML(values.time.trim() || '1:15');
                
                injectText(`
<div style="display:flex; align-items:center; gap:16px; margin:24px auto; max-width:350px; background:linear-gradient(145deg, #151515, #0d0d0d); border:1px solid #2a2a2a; padding:14px; border-radius:16px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
    <img src="${cover}" style="width:65px; height:65px; border-radius:10px; object-fit:cover; box-shadow:0 4px 10px rgba(0,0,0,0.4);">
    <div style="flex:1; min-width:0;">
        <div style="color:#fff; font-weight:800; font-size:1.05em; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; letter-spacing:0.5px;">${title}</div>
        <div style="color:#888; font-size:0.85em; margin-top:2px;">${artist}</div>
        <div style="display:flex; align-items:center; gap:8px; margin-top:8px;">
            <div style="color:#555; font-size:0.7em;">${time}</div>
            <div style="flex:1; height:4px; background:#222; border-radius:2px; position:relative;">
                <div style="position:absolute; left:0; top:0; height:100%; width:45%; background:${hex}; border-radius:2px; box-shadow:0 0 8px ${hex}80;"></div>
            </div>
            <div style="color:#555; font-size:0.7em;">-2:30</div>
        </div>
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // GRADIENT / HOLOGRAPHIC TEXT
        // --------------------------------------------------------
        {
            name: '✨ Gradient Text',
            fields: [
                {
                    key: 'palette',
                    label: 'Gradient Style',
                    type: 'select',
                    options: [
                        { label: 'Cyberpunk (Neon Pink/Blue)', value: 'linear-gradient(90deg, #ff007f, #00f0ff)' },
                        { label: 'Royal Gold (Gold/White)', value: 'linear-gradient(90deg, #bf953f, #fcf6ba, #b38728)' },
                        { label: 'Pearlescent (Pastel Magic)', value: 'linear-gradient(90deg, #ff9a9e, #fecfef, #a1c4fd)' },
                        { label: 'Inferno (Red/Orange)', value: 'linear-gradient(90deg, #ff4b1f, #ff9068)' }
                    ],
                    default: 'linear-gradient(90deg, #ff007f, #00f0ff)'
                },
                { key: 'text', label: 'Text Content', placeholder: 'LEGENDARY ITEM' },
                { key: 'size', label: 'Font Size (em)', type: 'range', min: 1, max: 4, step: 0.1, default: 1.5 }
            ],
            preview: (values, hex) => `
                <div style="font-weight:900; font-size:${values.size}em; background:${values.palette}; -webkit-background-clip:text; -webkit-text-fill-color:transparent; text-align:center;">
                    ${escapeHTML(values.text || 'GRADIENT')}
                </div>
            `,
            validate: values => values.text.trim() ? true : (showToast('Enter text.', 'error'), false),
            onSubmit: (values, hex) => {
                injectText(`
<div style="margin:20px 0; text-align:center; font-weight:900; font-size:${values.size}em; letter-spacing:2px; background:${values.palette}; -webkit-background-clip:text; -webkit-text-fill-color:transparent; color:transparent; display:inline-block; width:100%;">
    ${escapeHTML(values.text.trim())}
</div>
`);
            }
        },

        // --------------------------------------------------------
        // SCROLLING TICKER (MARQUEE)
        // --------------------------------------------------------
        {
            name: '🚨 Scrolling Ticker',
            fields: [
                {
                    key: 'style',
                    label: 'Ticker Style',
                    type: 'select',
                    options: [
                        { label: 'System Alert (Red/Black)', value: 'alert' },
                        { label: 'News Feed (Theme Color)', value: 'news' },
                        { label: 'Cyber Matrix (Green/Black)', value: 'matrix' }
                    ],
                    default: 'news'
                },
                { key: 'text', label: 'Scrolling Message', placeholder: 'WARNING: CONTAINMENT BREACH DETECTED IN SECTOR 7...' },
                { key: 'speed', label: 'Scroll Speed', type: 'range', min: 1, max: 20, default: 8 }
            ],
            preview: (values, hex) => {
                const colors = {
                    alert: { bg: '#2a0808', text: '#ff4444', border: '#ff0000' },
                    news: { bg: '#111', text: hex, border: hex },
                    matrix: { bg: '#001a00', text: '#00ff00', border: '#003300' }
                };
                const c = colors[values.style];
                return `
                <div style="background:${c.bg}; border-top:1px solid ${c.border}; border-bottom:1px solid ${c.border}; padding:8px; color:${c.text}; font-family:monospace; font-weight:bold; font-size:10px; overflow:hidden; white-space:nowrap;">
                    > ${escapeHTML(values.text || 'SCROLLING TEXT...')}
                </div>
                `;
            },
            validate: values => values.text.trim() ? true : (showToast('Enter scrolling text.', 'error'), false),
            onSubmit: (values, hex) => {
                const colors = {
                    alert: { bg: '#1a0505', text: '#ff4444', border: '#ff0000' },
                    news: { bg: '#0d0d0d', text: hex, border: hex },
                    matrix: { bg: '#001100', text: '#00ff00', border: '#004400' }
                };
                const c = colors[values.style];
                
                // Using standard HTML marquee for animation without scripts!
                injectText(`
<div style="margin:24px 0; background:${c.bg}; border-top:2px solid ${c.border}; border-bottom:2px solid ${c.border}; padding:10px 0; box-shadow:0 0 15px ${c.border}40;">
    <marquee scrollamount="${values.speed}" style="color:${c.text}; font-family:monospace; font-weight:bold; letter-spacing:2px; font-size:0.9em; text-transform:uppercase;">
        ${escapeHTML(values.text.trim())} &nbsp;&nbsp;✦&nbsp;&nbsp; ${escapeHTML(values.text.trim())} &nbsp;&nbsp;✦&nbsp;&nbsp; ${escapeHTML(values.text.trim())}
    </marquee>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // PRODUCER TRACKLIST
        // --------------------------------------------------------
        {
            name: '🎛️ Producer Tracklist',
            fields: [
                { key: 'album', label: 'Project Title', placeholder: 'undrwtr' },
                { key: 'artist', label: 'Artist', placeholder: 'LOXXANI' },
                { key: 'track1', label: 'Track 01', placeholder: 'PULL EM OUT - 2:14' },
                { key: 'track2', label: 'Track 02', placeholder: 'Abyssal - 3:05' },
                { key: 'track3', label: 'Track 03', placeholder: 'Glitch - 1:58' }
            ],
            preview: (values, hex) => `
                <div style="background:#0a0a0a; border:1px solid #222; padding:12px; color:#ccc; font-family:monospace;">
                    <div style="color:${hex}; font-weight:bold; margin-bottom:10px;">EP: ${escapeHTML(values.album || 'ALBUM')}</div>
                    <div style="font-size:0.8em;">01. ${escapeHTML(values.track1 || 'Track')}</div>
                    <div style="font-size:0.8em; margin-top:4px;">02. ${escapeHTML(values.track2 || 'Track')}</div>
                </div>
            `,
            validate: values => values.album.trim() ? true : (showToast('Enter a project title.', 'error'), false),
            onSubmit: (values, hex) => {
                const trk = (num, text) => text.trim() ? `
                    <div style="display:flex; justify-content:space-between; border-bottom:1px dashed #222; padding:8px 0;">
                        <span style="color:#666;">0${num}.</span>
                        <span style="color:#bbb; flex:1; margin-left:12px; letter-spacing:1px;">${escapeHTML(text.split('-')[0].trim())}</span>
                        <span style="color:${hex}; font-size:0.9em;">${escapeHTML((text.split('-')[1] || '').trim())}</span>
                    </div>` : '';

                injectText(`
<div style="margin:24px auto; max-width:320px; background:#080808; border:1px solid #1a1a1a; padding:20px; border-radius:4px; box-shadow:0 10px 25px rgba(0,0,0,0.6); font-family:'Courier New', Courier, monospace;">
    <div style="text-align:center; margin-bottom:18px;">
        <div style="color:${hex}; font-weight:900; font-size:1.2em; letter-spacing:4px; text-transform:uppercase;">${escapeHTML(values.album.trim())}</div>
        <div style="color:#555; font-size:0.7em; letter-spacing:2px; margin-top:4px;">PROD. ${escapeHTML(values.artist.trim() || 'UNKNOWN')}</div>
    </div>
    ${trk(1, values.track1)}
    ${trk(2, values.track2)}
    ${trk(3, values.track3)}
</div>
`);
            }
        },

        // --------------------------------------------------------
        // MOD LOADOUT / NODE TREE
        // --------------------------------------------------------
        {
            name: '⚙️ Mod Loadout',
            fields: [
                { key: 'title', label: 'Loadout Name', placeholder: 'Vortex Configuration // Active' },
                { key: 'node1', label: 'Core Framework', placeholder: 'TerraHearts Mechanics Core' },
                { key: 'node2', label: 'Dependency 01', placeholder: 'Type 4 - Body' },
                { key: 'node3', label: 'Dependency 02', placeholder: 'Custom UI Overhaul' }
            ],
            preview: (values, hex) => `
                <div style="background:#111; padding:12px; border-left:2px solid ${hex}; color:#ccc; font-size:10px;">
                    <strong>${escapeHTML(values.title || 'Loadout')}</strong>
                    <div style="margin-top:6px; margin-left:10px; border-left:1px solid #444; padding-left:8px;">
                        <div>├─ ${escapeHTML(values.node1 || 'Mod 1')}</div>
                        <div>└─ ${escapeHTML(values.node2 || 'Mod 2')}</div>
                    </div>
                </div>
            `,
            validate: values => values.title.trim() ? true : (showToast('Enter a loadout name.', 'error'), false),
            onSubmit: (values, hex) => {
                const node = (text, isLast) => text.trim() ? `
                    <div style="display:flex; align-items:center; margin-top:8px;">
                        <div style="color:#444; margin-right:8px;">${isLast ? '└─' : '├─'}</div>
                        <div style="background:#151515; border:1px solid #2a2a2a; padding:6px 12px; border-radius:4px; font-size:0.85em; color:#aaa; flex:1; box-shadow:0 2px 8px rgba(0,0,0,0.2);">
                            ${escapeHTML(text.trim())}
                        </div>
                    </div>` : '';

                injectText(`
<div style="margin:24px 0; background:#0d0d0d; border:1px solid #1a1a1a; border-top:3px solid ${hex}; padding:18px; border-radius:6px;">
    <div style="color:${hex}; font-weight:800; letter-spacing:1px; margin-bottom:12px; font-size:0.9em;">
        ${escapeHTML(values.title.trim().toUpperCase())}
    </div>
    <div style="margin-left:8px; border-left:2px solid #222; padding-left:12px; padding-bottom:4px;">
        ${node(values.node1, !values.node2 && !values.node3)}
        ${node(values.node2, !values.node3)}
        ${node(values.node3, true)}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // EXPERIMENTAL SOUNDCLOUD EMBED
        // --------------------------------------------------------
        {
            name: '🎵 SoundCloud Player',
            fields: [
                { key: 'url', label: 'SoundCloud Track URL', placeholder: 'https://soundcloud.com/artist/track' }
            ],
            preview: (values, hex) => `
                <div style="padding:12px; background:#111; border:1px dashed #ff5500; color:#ff5500; text-align:center; font-size:10px;">
                    Will attempt to inject SoundCloud iframe for:<br>
                    ${escapeHTML(values.url || 'URL')}
                </div>
            `,
            validate: values => values.url.trim() ? true : (showToast('Enter a SoundCloud URL.', 'error'), false),
            onSubmit: (values, hex) => {
                // SoundCloud's standard visual player iframe. 
                // We use the visual=true flag to get the nice square album art player.
                const encodedUrl = encodeURIComponent(values.url.trim());
                injectText(`
<div style="margin:24px auto; max-width:400px; box-shadow:0 8px 20px rgba(0,0,0,0.5); border-radius:8px; overflow:hidden;">
    <iframe width="100%" height="300" scrolling="no" frameborder="no" allow="autoplay" 
        src="https://w.soundcloud.com/player/?url=${encodedUrl}&color=%23${hex.replace('#', '')}&auto_play=false&hide_related=true&show_comments=false&show_user=true&show_reposts=false&show_teaser=false&visual=true">
    </iframe>
</div>
`);
            }
        },
        // --------------------------------------------------------
        // CINEMATIC GIF BOX
        // --------------------------------------------------------
        {
            name: '🎇 Cinematic GIF Box',
            fields: [
                { 
                    key: 'effect', 
                    label: 'Background GIF URL', 
                    placeholder: 'https://... (Link to a looping GIF)' 
                },
                { key: 'title', label: 'Title', placeholder: 'ATMOSPHERE' },
                { key: 'content', label: 'Content', type: 'textarea', placeholder: 'The rain poured relentlessly...', rows: 4 }
            ],
            // ... (keep the rest of the preview, validate, and onSubmit exactly the same!)
            preview: (values, hex) => {
                const bgUrl = values.effect && values.effect.trim() !== '' ? escapeHTML(values.effect.trim()) : 'https://placehold.co/400x200/111/333?text=NO+GIF';
                return `
                <div style="position:relative; padding:12px; border:1px solid #333; overflow:hidden;">
                    <div style="position:absolute; inset:0; background:url('${bgUrl}') center/cover; opacity:0.3;"></div>
                    <div style="position:relative; color:#fff; z-index:1;"><strong>${escapeHTML(values.title || 'TITLE')}</strong><br><span style="font-size:0.8em;">${escapeHTML(values.content || 'Content')}</span></div>
                </div>
                `;
            },
            validate: values => {
                if (!values.effect.trim()) {
                    showToast('Enter a GIF URL', 'error');
                    return false;
                }
                if (!values.content.trim()) {
                    showToast('Enter text', 'error');
                    return false;
                }
                return true;
            },
            onSubmit: (values, hex) => {
                injectText(`
<div style="margin:24px 0; position:relative; padding:30px; border:1px solid #1a1a1a; border-radius:8px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,0.8);">
    <!-- The Animated Particle Layer -->
    <div style="position:absolute; inset:0; background:url('${escapeHTML(values.effect.trim())}') center/cover; opacity:0.25; mix-blend-mode:screen; pointer-events:none;"></div>
    <!-- The Darkening Gradient -->
    <div style="position:absolute; inset:0; background:linear-gradient(180deg, rgba(0,0,0,0.4), rgba(0,0,0,0.9)); pointer-events:none;"></div>
    
    <!-- The Actual Content -->
    <div style="position:relative; z-index:1; text-align:center;">
        <div style="color:${hex}; font-size:1.1em; font-weight:900; letter-spacing:4px; margin-bottom:12px; text-shadow:0 2px 10px rgba(0,0,0,1);">
            ${escapeHTML(values.title.trim())}
        </div>
        <div style="color:#d9dadd; line-height:1.7; font-size:0.95em; text-shadow:0 1px 5px rgba(0,0,0,1);">
            ${escapeHTML(values.content.trim())}
        </div>
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // 3D HOLOGRAPHIC CARD
        // --------------------------------------------------------
        {
            name: '🃏 3D Hologram Card',
            fields: [
                { key: 'url', label: 'Image URL', placeholder: 'https://...' },
                { key: 'caption', label: 'Card Name', placeholder: 'QUEEN OF CHAOS' }
            ],
            preview: (values, hex) => `
                <div style="text-align:center; color:${hex}; font-size:10px;">Will render tilted in 3D space!</div>
            `,
            validate: values => values.url.trim() ? true : (showToast('Enter image URL', 'error'), false),
            onSubmit: (values, hex) => {
                injectText(`
<div style="margin:40px auto; display:flex; justify-content:center; perspective:1000px;">
    <!-- 3D Transform Container -->
    <div style="transform:rotateY(-15deg) rotateX(10deg); transform-style:preserve-3d; position:relative; background:#000; padding:10px; border-radius:12px; border:2px solid ${hex}; box-shadow:-20px 20px 30px rgba(0,0,0,0.6), inset 0 0 20px ${hex}80;">
        <img src="${escapeHTML(values.url.trim())}" style="display:block; max-width:280px; width:100%; border-radius:6px; box-shadow:0 0 10px rgba(0,0,0,0.8);">
        
        <!-- Gloss Reflection Overlay -->
        <div style="position:absolute; inset:0; background:linear-gradient(115deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 40%, rgba(255,255,255,0) 100%); pointer-events:none; border-radius:12px;"></div>
        
        <div style="position:absolute; bottom:-12px; left:50%; transform:translateX(-50%) translateZ(20px); background:#111; border:1px solid ${hex}; color:#fff; padding:4px 12px; border-radius:4px; font-weight:900; letter-spacing:2px; font-size:0.8em; white-space:nowrap; box-shadow:0 5px 15px rgba(0,0,0,0.9);">
            ${escapeHTML(values.caption.trim())}
        </div>
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // ENGINE INSPECTOR UI
        // --------------------------------------------------------
        {
            name: '🎮 Engine Inspector',
            fields: [
                { key: 'node', label: 'Node Name', placeholder: 'PlayerCharacter' },
                { key: 'prop1', label: 'Property 1 (e.g. max_health : int)', placeholder: 'max_health : int = 100' },
                { key: 'prop2', label: 'Property 2', placeholder: 'movement_speed : float = 4.5' },
                { key: 'prop3', label: 'Property 3', placeholder: 'is_active : bool = true' }
            ],
            preview: (values, hex) => `
                <div style="background:#202531; color:#ccc; font-family:monospace; padding:8px; font-size:9px;">
                    <div style="background:#2d3342; padding:4px;">▼ ${escapeHTML(values.node || 'Node')}</div>
                    <div style="padding:4px 12px; color:#ff7b72;">${escapeHTML(values.prop1 || 'prop')}</div>
                </div>
            `,
            validate: values => values.node.trim() ? true : (showToast('Enter node name', 'error'), false),
            onSubmit: (values, hex) => {
                const row = (text, bg) => text.trim() ? `
                    <div style="display:flex; justify-content:space-between; background:${bg}; padding:6px 12px; border-bottom:1px solid #1a1e27;">
                        <span style="color:#79c0ff;">${escapeHTML(text.split('=')[0].trim())}</span>
                        <span style="color:#ff7b72;">${escapeHTML((text.split('=')[1] || '').trim())}</span>
                    </div>` : '';
                
                // Uses classic dark engine theme colors
                injectText(`
<div style="margin:24px auto; max-width:400px; background:#0d1117; border:1px solid #30363d; border-radius:6px; font-family:Consolas, 'Courier New', monospace; font-size:0.85em; overflow:hidden; box-shadow:0 8px 24px rgba(0,0,0,0.5);">
    <div style="background:#161b22; padding:8px 12px; border-bottom:1px solid #30363d; display:flex; align-items:center; gap:8px;">
        <span style="color:${hex}; font-size:1.2em;">⚙</span>
        <strong style="color:#e6edf3; letter-spacing:1px;">Inspector</strong>
    </div>
    
    <div style="background:#21262d; padding:6px 12px; border-bottom:1px solid #30363d; color:#e6edf3; font-weight:bold;">
        ▼ Node: <span style="color:#d2a8ff;">${escapeHTML(values.node.trim())}</span>
    </div>
    
    <div>
        ${row(values.prop1, '#0d1117')}
        ${row(values.prop2, '#161b22')}
        ${row(values.prop3, '#0d1117')}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // CHAT THREAD
        // --------------------------------------------------------
        {
            name: '💬 Chat Thread',
            fields: [
                {
                    key: 'style', label: 'Thread Style', type: 'select',
                    options: [
                        { label: 'iMessage (Blue/Gray)', value: 'imessage' },
                        { label: 'Discord (Dark)', value: 'discord' },
                        { label: 'Theme Color', value: 'theme' }
                    ],
                    default: 'imessage'
                },
                { key: 'leftName', label: 'Left Sender Name', placeholder: 'Them' },
                { key: 'rightName', label: 'Right Sender Name (You)', placeholder: 'You' },
                { key: 'msg1', label: 'Message 1', type: 'textarea', placeholder: 'hey...', rows: 2 },
                { key: 'side1', label: 'Message 1 Side', type: 'select', options: [{ label: 'Left', value: 'left' }, { label: 'Right', value: 'right' }], default: 'left' },
                { key: 'msg2', label: 'Message 2', type: 'textarea', placeholder: 'you up?', rows: 2 },
                { key: 'side2', label: 'Message 2 Side', type: 'select', options: [{ label: 'Left', value: 'left' }, { label: 'Right', value: 'right' }], default: 'left' },
                { key: 'msg3', label: 'Message 3', type: 'textarea', placeholder: 'yeah, what\'s up?', rows: 2 },
                { key: 'side3', label: 'Message 3 Side', type: 'select', options: [{ label: 'Left', value: 'left' }, { label: 'Right', value: 'right' }], default: 'right' },
                { key: 'msg4', label: 'Message 4 (optional)', type: 'textarea', placeholder: '', rows: 2 },
                { key: 'side4', label: 'Message 4 Side', type: 'select', options: [{ label: 'Left', value: 'left' }, { label: 'Right', value: 'right' }], default: 'left' },
                { key: 'msg5', label: 'Message 5 (optional)', type: 'textarea', placeholder: '', rows: 2 },
                { key: 'side5', label: 'Message 5 Side', type: 'select', options: [{ label: 'Left', value: 'left' }, { label: 'Right', value: 'right' }], default: 'right' }
            ],
            preview: (values, hex) => {
                const theme = obeliskChatTheme(values.style, hex);
                const rows = [1, 2, 3].map(n => obeliskChatBubbleHTML(
                    values[`msg${n}`] || `Message ${n}...`,
                    values[`side${n}`] || (n === 3 ? 'right' : 'left'),
                    theme,
                    true
                )).join('');
                return `
                <div style="display:flex; flex-direction:column; gap:6px; padding:8px; background:${theme.bg};">
                    ${rows}
                </div>
                `;
            },
            validate: values => {
                const hasAny = [1, 2, 3, 4, 5].some(n => (values[`msg${n}`] || '').trim());
                if (!hasAny) {
                    showToast('Enter at least one message.', 'error');
                    return false;
                }
                return true;
            },
            onSubmit: (values, hex) => {
                const theme = obeliskChatTheme(values.style, hex);
                const leftName = escapeHTML((values.leftName || 'Them').trim() || 'Them');
                const rightName = escapeHTML((values.rightName || 'You').trim() || 'You');

                const bubbles = [1, 2, 3, 4, 5]
                    .filter(n => (values[`msg${n}`] || '').trim())
                    .map(n => obeliskChatBubbleHTML(values[`msg${n}`].trim(), values[`side${n}`] || 'left', theme, false))
                    .join('\n');

                injectText(`
<div style="margin:24px auto; max-width:420px; background:${theme.bg}; border:1px solid ${theme.border}; border-radius:14px; padding:16px; box-shadow:0 10px 30px rgba(0,0,0,0.5); font-family:-apple-system, 'Segoe UI', sans-serif;">
    <div style="display:flex; justify-content:space-between; padding:0 6px 12px 6px; border-bottom:1px solid ${theme.border}; margin-bottom:12px;">
        <span style="color:${theme.leftLabel}; font-size:.75em; font-weight:700; letter-spacing:1px; text-transform:uppercase;">${leftName}</span>
        <span style="color:${theme.rightLabel}; font-size:.75em; font-weight:700; letter-spacing:1px; text-transform:uppercase;">${rightName}</span>
    </div>
    <div style="display:flex; flex-direction:column; gap:8px;">
        ${bubbles}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // MEMORY POLAROID
        // --------------------------------------------------------
        {
            name: '📷 Memory Polaroid',
            fields: [
                { key: 'url', label: 'Image URL', placeholder: 'https://...' },
                { key: 'caption', label: 'Handwritten Caption', placeholder: 'that one summer...' },
                { key: 'tilt', label: 'Tilt Angle', type: 'range', min: -12, max: 12, default: -3 }
            ],
            preview: (values, hex) => `
                ${obeliskFontImportTag('handwritten')}
                <div style="text-align:center; padding:10px;">
                    <div style="display:inline-block; background:#f4f1ea; padding:8px 8px 22px 8px; transform:rotate(${values.tilt || -3}deg); box-shadow:0 4px 10px rgba(0,0,0,.4);">
                        ${values.url
                            ? `<img src="${escapeHTML(values.url)}" style="width:140px; height:100px; object-fit:cover; display:block;">`
                            : `<div style="width:140px; height:100px; display:flex; align-items:center; justify-content:center; background:#ddd; color:#888; font-size:.7em;">PHOTO</div>`
                        }
                        <div style="font-family:'Caveat', cursive; color:#333; font-size:1.1em; text-align:center; margin-top:6px;">
                            ${escapeHTML(values.caption || 'a memory...')}
                        </div>
                    </div>
                </div>
            `,
            validate: values => values.url.trim() ? true : (showToast('Enter an image URL.', 'error'), false),
            onSubmit: (values, hex) => {
                const tilt = values.tilt || -3;
                injectText(`
${obeliskFontImportTag('handwritten')}<div style="margin:28px 0; text-align:center;">
    <div style="display:inline-block; background:#f4f1ea; padding:14px 14px 34px 14px; transform:rotate(${tilt}deg); box-shadow:0 10px 25px rgba(0,0,0,.45); border-radius:2px;">
        <img src="${escapeHTML(values.url.trim())}" style="width:260px; max-width:100%; height:190px; object-fit:cover; display:block; filter:sepia(.15) contrast(1.05);">
        <div style="font-family:'Caveat', cursive; color:#3a3530; font-size:1.4em; text-align:center; margin-top:10px; letter-spacing:.5px;">
            ${escapeHTML(values.caption.trim() || 'a memory...')}
        </div>
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // PET NAME TAG
        // --------------------------------------------------------
        {
            name: '💞 Pet Name Tag',
            fields: [
                { key: 'name', label: 'Pet Name', placeholder: 'Sunshine' },
                {
                    key: 'style', label: 'Tag Style', type: 'select',
                    options: [
                        { label: 'Soft Pink', value: 'pink' },
                        { label: 'Lavender', value: 'lavender' },
                        { label: 'Theme Color', value: 'theme' }
                    ],
                    default: 'pink'
                }
            ],
            preview: (values, hex) => {
                const c = values.style === 'lavender' ? '#b9a3e3' : values.style === 'theme' ? hex : '#f2a6c1';
                return `
                <div style="display:inline-flex; align-items:center; gap:4px; background:${c}22; border:1px solid ${c}; color:${c}; padding:4px 12px; border-radius:20px; font-size:.8em; font-weight:700; letter-spacing:.5px;">
                    ♡ ${escapeHTML(values.name || 'nickname')}
                </div>
                `;
            },
            validate: values => values.name.trim() ? true : (showToast('Enter a pet name.', 'error'), false),
            onSubmit: (values, hex) => {
                const c = values.style === 'lavender' ? '#b9a3e3' : values.style === 'theme' ? hex : '#f2a6c1';
                injectText(`
<span style="display:inline-flex; align-items:center; gap:5px; background:${c}22; border:1px solid ${c}; color:${c}; padding:5px 16px; border-radius:20px; font-size:.85em; font-weight:700; letter-spacing:.5px; margin:4px;">
    ♡ ${escapeHTML(values.name.trim())}
</span>
`);
            }
        },

        // --------------------------------------------------------
        // COMPATIBILITY METER
        // --------------------------------------------------------
        {
            name: '💘 Compatibility Meter',
            fields: [
                { key: 'label', label: 'Meter Label', placeholder: 'Compatibility' },
                { key: 'percent', label: 'Percent', type: 'range', min: 0, max: 100, default: 78 },
                {
                    key: 'style', label: 'Color', type: 'select',
                    options: [
                        { label: 'Romantic Pink/Red', value: 'romance' },
                        { label: 'Theme Color', value: 'theme' }
                    ],
                    default: 'romance'
                }
            ],
            preview: (values, hex) => {
                const c = values.style === 'theme' ? hex : '#e05a7a';
                return `
                <div style="padding:6px;">
                    <div style="display:flex; justify-content:space-between; color:#ccc; font-size:.75em; margin-bottom:4px;">
                        <span>${escapeHTML(values.label || 'Compatibility')}</span>
                        <span style="color:${c}; font-weight:700;">${values.percent || 78}%</span>
                    </div>
                    <div style="background:#222; border-radius:8px; height:10px; overflow:hidden;">
                        <div style="width:${values.percent || 78}%; height:100%; background:${c};"></div>
                    </div>
                </div>
                `;
            },
            validate: values => values.label.trim() ? true : (showToast('Enter a label.', 'error'), false),
            onSubmit: (values, hex) => {
                const c = values.style === 'theme' ? hex : '#e05a7a';
                const pct = Math.max(0, Math.min(100, Number(values.percent) || 0));
                injectText(`
<div style="margin:20px 0; max-width:340px;">
    <div style="display:flex; justify-content:space-between; color:#bbb; font-size:.8em; font-weight:700; letter-spacing:.5px; text-transform:uppercase; margin-bottom:6px;">
        <span>♡ ${escapeHTML(values.label.trim())}</span>
        <span style="color:${c};">${pct}%</span>
    </div>
    <div style="background:#1a1a1a; border:1px solid #2a2a2a; border-radius:10px; height:14px; overflow:hidden; box-shadow:inset 0 2px 4px rgba(0,0,0,.4);">
        <div style="width:${pct}%; height:100%; background:linear-gradient(90deg, ${c}aa, ${c}); box-shadow:0 0 10px ${c}88;"></div>
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // MEME CAPTION
        // --------------------------------------------------------
        {
            name: '😂 Meme Caption',
            fields: [
                { key: 'url', label: 'Image URL', placeholder: 'https://...' },
                { key: 'top', label: 'Top Text', placeholder: 'WHEN THE PLOT TWIST HITS' },
                { key: 'bottom', label: 'Bottom Text', placeholder: '' }
            ],
            preview: (values, hex) => `
                ${obeliskFontImportTag('impact')}
                <div style="position:relative; display:inline-block; max-width:100%;">
                    ${values.url
                        ? `<img src="${escapeHTML(values.url)}" style="max-width:100%; max-height:160px; display:block; border-radius:4px;">`
                        : `<div style="width:200px; height:120px; display:flex; align-items:center; justify-content:center; background:#222; color:#666; font-size:.7em;">IMAGE</div>`
                    }
                    <div style="position:absolute; top:4px; left:0; right:0; text-align:center; font-family:'Anton', Impact, sans-serif; color:#fff; -webkit-text-stroke:1px #000; text-transform:uppercase; font-size:1em; line-height:1.1; padding:0 4px;">
                        ${escapeHTML(values.top || '')}
                    </div>
                    <div style="position:absolute; bottom:4px; left:0; right:0; text-align:center; font-family:'Anton', Impact, sans-serif; color:#fff; -webkit-text-stroke:1px #000; text-transform:uppercase; font-size:1em; line-height:1.1; padding:0 4px;">
                        ${escapeHTML(values.bottom || '')}
                    </div>
                </div>
            `,
            validate: values => values.url.trim() ? true : (showToast('Enter an image URL.', 'error'), false),
            onSubmit: (values, hex) => {
                injectText(`
${obeliskFontImportTag('impact')}<div style="margin:24px auto; position:relative; display:inline-block; max-width:100%; text-align:center;">
    <img src="${escapeHTML(values.url.trim())}" style="max-width:100%; display:block; border-radius:6px;">
    <div style="position:absolute; top:12px; left:0; right:0; text-align:center; font-family:'Anton', Impact, sans-serif; color:#fff; -webkit-text-stroke:2px #000; text-shadow:2px 2px 0 #000, -2px -2px 0 #000, 2px -2px 0 #000, -2px 2px 0 #000; text-transform:uppercase; font-size:1.8em; line-height:1.1; letter-spacing:1px; padding:0 10px;">
        ${escapeHTML(values.top.trim())}
    </div>
    <div style="position:absolute; bottom:12px; left:0; right:0; text-align:center; font-family:'Anton', Impact, sans-serif; color:#fff; -webkit-text-stroke:2px #000; text-shadow:2px 2px 0 #000, -2px -2px 0 #000, 2px -2px 0 #000, -2px 2px 0 #000; text-transform:uppercase; font-size:1.8em; line-height:1.1; letter-spacing:1px; padding:0 10px;">
        ${escapeHTML(values.bottom.trim())}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // FAKE NOTIFICATION
        // --------------------------------------------------------
        {
            name: '🔔 Fake Notification',
            fields: [
                { key: 'app', label: 'App Name', placeholder: 'Messages' },
                { key: 'icon', label: 'App Icon (emoji)', placeholder: '💬' },
                { key: 'message', label: 'Notification Text', placeholder: 'is typing...' },
                { key: 'time', label: 'Time Label', placeholder: 'now' }
            ],
            preview: (values, hex) => `
                <div style="background:#1c1c1e; border:1px solid #2c2c2e; border-radius:14px; padding:10px 12px; display:flex; gap:8px; align-items:flex-start; max-width:280px; box-shadow:0 6px 16px rgba(0,0,0,.4);">
                    <div style="width:28px; height:28px; border-radius:7px; background:${hex}; display:flex; align-items:center; justify-content:center; font-size:.9em; flex-shrink:0;">
                        ${escapeHTML(values.icon || '🔔')}
                    </div>
                    <div style="flex:1; min-width:0;">
                        <div style="display:flex; justify-content:space-between; color:#8e8e93; font-size:.65em; font-weight:700; text-transform:uppercase;">
                            <span>${escapeHTML(values.app || 'App')}</span>
                            <span>${escapeHTML(values.time || 'now')}</span>
                        </div>
                        <div style="color:#e9e9eb; font-size:.8em; margin-top:2px;">${escapeHTML(values.message || 'Notification text...')}</div>
                    </div>
                </div>
            `,
            validate: values => values.message.trim() ? true : (showToast('Enter notification text.', 'error'), false),
            onSubmit: (values, hex) => {
                injectText(`
<div style="margin:20px auto; background:rgba(28,28,30,0.92); backdrop-filter:blur(10px); border:1px solid #2c2c2e; border-radius:16px; padding:14px 16px; display:flex; gap:10px; align-items:flex-start; max-width:340px; box-shadow:0 10px 30px rgba(0,0,0,.5); font-family:-apple-system, 'Segoe UI', sans-serif;">
    <div style="width:36px; height:36px; border-radius:9px; background:${hex}; display:flex; align-items:center; justify-content:center; font-size:1.1em; flex-shrink:0;">
        ${escapeHTML(values.icon.trim() || '🔔')}
    </div>
    <div style="flex:1; min-width:0;">
        <div style="display:flex; justify-content:space-between; color:#8e8e93; font-size:.7em; font-weight:700; letter-spacing:.5px; text-transform:uppercase;">
            <span>${escapeHTML(values.app.trim() || 'App')}</span>
            <span>${escapeHTML(values.time.trim() || 'now')}</span>
        </div>
        <div style="color:#e9e9eb; font-size:.9em; margin-top:3px; line-height:1.4;">${escapeHTML(values.message.trim())}</div>
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // ACHIEVEMENT UNLOCKED
        // --------------------------------------------------------
        {
            name: '🏆 Achievement Unlocked',
            fields: [
                { key: 'icon', label: 'Icon (emoji)', placeholder: '🏆' },
                { key: 'title', label: 'Achievement Title', placeholder: 'Survived the First Night' },
                { key: 'subtitle', label: 'Subtitle', placeholder: 'Somehow. Barely.' }
            ],
            preview: (values, hex) => `
                <div style="background:#0d0d0d; border:1px solid ${hex}; border-radius:8px; padding:10px 14px; display:flex; gap:10px; align-items:center; max-width:300px; box-shadow:0 0 16px ${hex}44;">
                    <div style="font-size:1.6em;">${escapeHTML(values.icon || '🏆')}</div>
                    <div>
                        <div style="color:${hex}; font-size:.6em; font-weight:700; letter-spacing:1.5px; text-transform:uppercase;">Achievement Unlocked</div>
                        <div style="color:#eee; font-weight:700; font-size:.85em;">${escapeHTML(values.title || 'Title')}</div>
                    </div>
                </div>
            `,
            validate: values => values.title.trim() ? true : (showToast('Enter an achievement title.', 'error'), false),
            onSubmit: (values, hex) => {
                injectText(`
<div style="margin:20px auto; background:linear-gradient(135deg, #0d0d0d, #151515); border:1px solid ${hex}; border-radius:10px; padding:16px 20px; display:flex; gap:14px; align-items:center; max-width:380px; box-shadow:0 0 24px ${hex}55, 0 10px 25px rgba(0,0,0,.5);">
    <div style="font-size:2.2em; filter:drop-shadow(0 0 6px ${hex});">${escapeHTML(values.icon.trim() || '🏆')}</div>
    <div>
        <div style="color:${hex}; font-size:.7em; font-weight:900; letter-spacing:2px; text-transform:uppercase;">Achievement Unlocked</div>
        <div style="color:#f2f2f2; font-weight:800; font-size:1.1em; margin-top:2px;">${escapeHTML(values.title.trim())}</div>
        ${values.subtitle.trim() ? `<div style="color:#999; font-size:.85em; margin-top:2px;">${escapeHTML(values.subtitle.trim())}</div>` : ''}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // SPOILER REVEAL
        // --------------------------------------------------------
        {
            name: '👁️‍🗨️ Spoiler Reveal',
            fields: [
                { key: 'label', label: 'Reveal Label', placeholder: 'SPOILER — Click to Reveal' },
                { key: 'content', label: 'Hidden Content', type: 'textarea', placeholder: 'The thing nobody\'s supposed to know yet...', rows: 4 }
            ],
            preview: (values, hex) => `
                <details style="background:#0a0a0a; border:1px solid #333; border-radius:6px; padding:8px 12px;">
                    <summary style="color:#888; cursor:pointer; font-size:.75em; font-weight:700; letter-spacing:1px; text-transform:uppercase;">
                        ⚠ ${escapeHTML(values.label || 'SPOILER — Click to Reveal')}
                    </summary>
                    <div style="margin-top:8px; color:#ccc; font-size:.85em;">
                        ${escapeHTML(values.content || 'Hidden content...')}
                    </div>
                </details>
            `,
            validate: values => values.content.trim() ? true : (showToast('Enter the hidden content.', 'error'), false),
            onSubmit: (values, hex) => {
                injectText(`
<details style="margin:18px 0; background:#0a0a0a; border:1px dashed #444; border-radius:8px; padding:12px 16px;">
    <summary style="color:#999; cursor:pointer; font-weight:700; letter-spacing:1px; text-transform:uppercase; font-size:.85em;">
        ⚠ ${escapeHTML(values.label.trim() || 'SPOILER — Click to Reveal')}
    </summary>
    <div style="margin-top:12px; padding-top:12px; border-top:1px solid #222; color:#ddd; line-height:1.7;">
        ${escapeHTML(values.content.trim())}
    </div>
</details>
`);
            }
        },

        // --------------------------------------------------------
        // CONTENT WARNING
        // --------------------------------------------------------
        {
            name: '🚩 Content Warning',
            fields: [
                { key: 'tags', label: 'Warning Topics (comma-separated)', placeholder: 'violence, mild gore, death' },
                { key: 'note', label: 'Extra Note (optional)', placeholder: 'Proceed with care.' }
            ],
            preview: (values, hex) => `
                <div style="background:#1a1010; border:1px solid #4a2222; border-radius:6px; padding:8px 12px; color:#d99;">
                    <div style="font-size:.75em; font-weight:700; letter-spacing:1px;">🚩 CONTENT WARNING</div>
                    <div style="font-size:.75em; color:#c88; margin-top:3px;">${escapeHTML(values.tags || 'topic, topic')}</div>
                </div>
            `,
            validate: values => values.tags.trim() ? true : (showToast('Enter at least one warning topic.', 'error'), false),
            onSubmit: (values, hex) => {
                const tags = values.tags.split(',').map(t => t.trim()).filter(Boolean);
                const tagHTML = tags.map(t => `
                    <span style="background:#2a1414; border:1px solid #4a2222; color:#e08; color:#d99; padding:3px 10px; border-radius:12px; font-size:.75em; margin:2px;">${escapeHTML(t)}</span>
                `).join('');
                injectText(`
<div style="margin:18px 0; background:#150d0d; border:1px solid #4a2222; border-left:3px solid #a33; border-radius:8px; padding:12px 16px;">
    <div style="color:#d99; font-weight:800; letter-spacing:1px; text-transform:uppercase; font-size:.8em; margin-bottom:8px;">🚩 Content Warning</div>
    <div style="display:flex; flex-wrap:wrap; gap:4px;">
        ${tagHTML}
    </div>
    ${values.note.trim() ? `<div style="color:#a88; font-size:.85em; margin-top:8px; font-style:italic;">${escapeHTML(values.note.trim())}</div>` : ''}
</div>
`);
            }
        },

        // --------------------------------------------------------
        // OOC NOTE
        // --------------------------------------------------------
        {
            name: '💭 OOC Note',
            fields: [
                { key: 'text', label: 'Out-of-Character Note', type: 'textarea', placeholder: 'This character is written for slow-burn RP, not instant romance.', rows: 3 }
            ],
            preview: (values, hex) => `
                <div style="background:#111; border:1px dashed #444; border-radius:6px; padding:8px 12px; color:#999; font-style:italic; font-size:.8em;">
                    ( OOC: ${escapeHTML(values.text || 'note...')} )
                </div>
            `,
            validate: values => values.text.trim() ? true : (showToast('Enter a note.', 'error'), false),
            onSubmit: (values, hex) => {
                injectText(`
<div style="margin:16px 0; background:#0f0f0f; border:1px dashed #3a3a3a; border-radius:8px; padding:12px 16px; color:#999; font-style:italic; font-size:.9em; line-height:1.6;">
    ( OOC: ${escapeHTML(values.text.trim())} )
</div>
`);
            }
        },

        // --------------------------------------------------------
        // EVIDENCE BOARD
        // --------------------------------------------------------
        {
            name: '📌 Evidence Board',
            fields: [
                { key: 'note1', label: 'Note 1', type: 'textarea', placeholder: 'She was seen near the docks.', rows: 2 },
                { key: 'note2', label: 'Note 2', type: 'textarea', placeholder: 'The letter was never sent.', rows: 2 },
                { key: 'note3', label: 'Note 3', type: 'textarea', placeholder: 'Nobody remembers the third guest.', rows: 2 },
                { key: 'note4', label: 'Note 4 (optional)', type: 'textarea', placeholder: '', rows: 2 }
            ],
            preview: (values, hex) => {
                const notes = [1, 2, 3, 4].map(n => values[`note${n}`]).filter(t => t && t.trim());
                const cards = (notes.length ? notes : ['note...', 'note...']).map((t, i) => `
                    <div style="background:#f2ecd8; color:#222; padding:8px; font-size:.65em; transform:rotate(${(i % 2 === 0 ? -3 : 2)}deg); box-shadow:0 3px 6px rgba(0,0,0,.4); border-radius:2px;">
                        📌 ${escapeHTML(t)}
                    </div>
                `).join('');
                return `
                <div style="background:#3b2f22; padding:10px; border-radius:6px; display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                    ${cards}
                </div>
                `;
            },
            validate: values => {
                const hasAny = [1, 2, 3, 4].some(n => (values[`note${n}`] || '').trim());
                if (!hasAny) {
                    showToast('Enter at least one note.', 'error');
                    return false;
                }
                return true;
            },
            onSubmit: (values, hex) => {
                const notes = [1, 2, 3, 4].map(n => values[`note${n}`]).filter(t => t && t.trim());
                const tilts = [-4, 3, -2, 5];
                const cards = notes.map((t, i) => `
    <div style="background:#f2ecd8; color:#241f16; padding:14px; font-family:'Caveat', cursive; font-size:1.15em; line-height:1.3; transform:rotate(${tilts[i % tilts.length]}deg); box-shadow:0 6px 14px rgba(0,0,0,.5); border-radius:2px; position:relative;">
        <div style="position:absolute; top:-8px; left:50%; transform:translateX(-50%); color:${hex}; font-size:1.4em;">📌</div>
        ${escapeHTML(t.trim())}
    </div>`).join('\n');

                injectText(`
${obeliskFontImportTag('handwritten')}<div style="margin:24px 0; background:#3b2f22; background-image:radial-gradient(#4a3c2c 1px, transparent 1px); background-size:12px 12px; padding:20px; border-radius:8px; border:1px solid #241d14; box-shadow:inset 0 0 30px rgba(0,0,0,.5);">
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(140px, 1fr)); gap:20px 24px;">
        ${cards}
    </div>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // PAGE BACKGROUND (EXPERIMENTAL — see obeliskMeta note)
        // --------------------------------------------------------
        /*
         * Confirmed working via manual testing: a position:fixed,
         * full-viewport div injected into the about-editor content
         * escapes its container and paints behind the entire
         * Clank page, including while scrolling past other content.
         *
         * This is fragile in a way the rest of the toolkit isn't —
         * it only works because nothing between this div and the
         * page root currently has a `transform`, `filter`, or
         * `contain` CSS property (any of those creates a new
         * containing block and would trap the fixed positioning
         * inside whatever component wraps it). If Clank ever
         * changes their page markup in a way that adds one of
         * those properties higher up the tree, this tool will
         * silently start rendering as a small decorative box
         * instead of a real background — nothing to fix on our
         * end, just something that could break without warning.
         */
        {
            name: '🌌 Page Background',
            fields: [
                {
                    key: 'pattern', label: 'Pattern', type: 'select',
                    options: [
                        { label: 'Diagonal Stripes', value: 'stripes' },
                        { label: 'Dot Grid', value: 'dots' },
                        { label: 'Solid Wash', value: 'solid' },
                        { label: 'Radial Glow', value: 'glow' }
                    ],
                    default: 'stripes'
                },
                { key: 'secondary', label: 'Secondary Color (optional)', placeholder: '#000000' },
                { key: 'opacity', label: 'Opacity (%)', type: 'range', min: 5, max: 60, default: 20 }
            ],
            preview: (values, hex) => {
                const bg = obeliskBackgroundCSS(values.pattern, hex, values.secondary || '#000000');
                const op = (values.opacity || 20) / 100;
                return `
                <div style="position:relative; height:80px; border-radius:6px; overflow:hidden; border:1px solid #333;">
                    <div style="position:absolute; inset:0; background:${bg}; opacity:${op};"></div>
                    <div style="position:relative; color:#fff; font-size:.7em; text-align:center; padding-top:32px;">PREVIEW ONLY — actual effect covers the full page</div>
                </div>
                `;
            },
            onSubmit: (values, hex) => {
                const bg = obeliskBackgroundCSS(values.pattern, hex, values.secondary.trim() || '#000000');
                const op = Math.max(0.05, Math.min(0.6, (Number(values.opacity) || 20) / 100));
                injectText(`
<div style="position:fixed; top:0; left:0; width:100vw; height:100vh; background:${bg}; opacity:${op}; pointer-events:none; z-index:9999;"></div>
`);
                showToast('Background injected. If it stops working after a Clank update, this tool may need to be revisited.');
            }
        },

        // --------------------------------------------------------
        // LIVE PULSE INDICATOR (SVG <animate>, no <style> needed)
        // --------------------------------------------------------
        {
            name: '💓 Pulse Indicator',
            fields: [
                { key: 'label', label: 'Label Text', placeholder: 'LIVE' },
                {
                    key: 'style', label: 'Color', type: 'select',
                    options: [
                        { label: 'Theme Color', value: 'theme' },
                        { label: 'Alert Red', value: 'red' },
                        { label: 'Signal Green', value: 'green' }
                    ],
                    default: 'theme'
                }
            ],
            preview: (values, hex) => {
                const c = values.style === 'red' ? '#ff4444' : values.style === 'green' ? '#44ff88' : hex;
                return `
                <div style="display:inline-flex; align-items:center; gap:8px; background:#111; border:1px solid #2a2a2a; padding:6px 12px; border-radius:20px;">
                    <svg width="14" height="14" viewBox="0 0 14 14">
                        <circle cx="7" cy="7" r="3" fill="${c}">
                            <animate attributeName="opacity" values="1;0.3;1" dur="1.4s" repeatCount="indefinite" />
                        </circle>
                        <circle cx="7" cy="7" r="3" fill="none" stroke="${c}" stroke-width="1">
                            <animate attributeName="r" values="3;7" dur="1.4s" repeatCount="indefinite" />
                            <animate attributeName="opacity" values="0.6;0" dur="1.4s" repeatCount="indefinite" />
                        </circle>
                    </svg>
                    <span style="color:${c}; font-size:.75em; font-weight:700; letter-spacing:1px;">${escapeHTML(values.label || 'LIVE')}</span>
                </div>
                `;
            },
            validate: values => values.label.trim() ? true : (showToast('Enter a label.', 'error'), false),
            onSubmit: (values, hex) => {
                const c = values.style === 'red' ? '#ff4444' : values.style === 'green' ? '#44ff88' : hex;
                injectText(`
<div style="display:inline-flex; align-items:center; gap:10px; background:#0d0d0d; border:1px solid ${c}44; padding:8px 16px; border-radius:20px; margin:8px 0;">
    <svg width="16" height="16" viewBox="0 0 16 16">
        <circle cx="8" cy="8" r="3.5" fill="${c}">
            <animate attributeName="opacity" values="1;0.3;1" dur="1.4s" repeatCount="indefinite" />
        </circle>
        <circle cx="8" cy="8" r="3.5" fill="none" stroke="${c}" stroke-width="1.5">
            <animate attributeName="r" values="3.5;8" dur="1.4s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.7;0" dur="1.4s" repeatCount="indefinite" />
        </circle>
    </svg>
    <span style="color:${c}; font-size:.8em; font-weight:800; letter-spacing:1.5px; text-transform:uppercase;">${escapeHTML(values.label.trim())}</span>
</div>
`);
            }
        },

        // --------------------------------------------------------
        // HOVER REVEAL CARD (CSS :hover in <style>)
        // --------------------------------------------------------
        {
            name: '🖱️ Hover Reveal Card',
            fields: [
                { key: 'front', label: 'Front Text', placeholder: 'What they show the world' },
                { key: 'back', label: 'Reveal Text (on hover)', type: 'textarea', placeholder: 'What they hide from everyone else...', rows: 3 }
            ],
            preview: (values, hex) => `
                <div style="background:#111; border:1px solid ${hex}; border-radius:8px; padding:14px; text-align:center; color:#ccc; font-size:.8em;">
                    ${escapeHTML(values.front || 'Front text')}
                    <div style="color:#666; font-size:.75em; margin-top:6px;">(hover to reveal — preview not interactive)</div>
                </div>
            `,
            validate: values => (values.front.trim() && values.back.trim()) ? true : (showToast('Enter both front and reveal text.', 'error'), false),
            onSubmit: (values, hex) => {
                const uid = 'ob' + Math.random().toString(36).slice(2, 9);
                injectText(`
<style>
.${uid} { position:relative; background:#111; border:1px solid ${hex}; border-radius:10px; padding:20px; text-align:center; overflow:hidden; cursor:pointer; min-height:80px; }
.${uid} .front { color:#eee; font-weight:700; transition:opacity .3s; }
.${uid} .back { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; padding:20px; color:${hex}; opacity:0; transition:opacity .3s; background:#0a0a0a; }
.${uid}:hover .front { opacity:0; }
.${uid}:hover .back { opacity:1; }
</style>
<div class="${uid}">
    <div class="front">${escapeHTML(values.front.trim())}</div>
    <div class="back">${escapeHTML(values.back.trim())}</div>
</div>
`);
            }
        }
    ];

    /*
     * Shared pattern-to-CSS mapping for the Page Background tool's
     * preview and onSubmit — single source of truth, same pattern
     * as badgeStyleColor and obeliskChatTheme above.
     */

    function obeliskBackgroundCSS(pattern, hex, secondary) {
        if (pattern === 'dots') {
            return `radial-gradient(${hex} 1.5px, ${secondary} 1.5px) 0 0/22px 22px`;
        }
        if (pattern === 'solid') {
            return hex;
        }
        if (pattern === 'glow') {
            return `radial-gradient(circle at 50% 30%, ${hex}, ${secondary} 70%)`;
        }
        // stripes (default)
        return `repeating-linear-gradient(45deg, ${hex} 0 20px, ${secondary} 20px 40px)`;
    }

    /*
     * Shared bubble color logic for the Chat Thread tool's live
     * preview and its onSubmit output — same pattern as
     * badgeStyleColor above, single source of truth so preview
     * and final output never drift apart.
     */

    function obeliskChatTheme(style, hex) {
        if (style === 'discord') {
            return {
                bg: '#2b2d31', border: '#1e1f22',
                leftBubble: '#383a40', leftText: '#dbdee1',
                rightBubble: '#404249', rightText: '#dbdee1',
                leftLabel: '#949ba4', rightLabel: '#949ba4'
            };
        }
        if (style === 'theme') {
            return {
                bg: '#0d0d0d', border: '#252525',
                leftBubble: '#1a1a1a', leftText: '#ddd',
                rightBubble: hex, rightText: '#0a0a0a',
                leftLabel: '#777', rightLabel: hex
            };
        }
        // imessage (default)
        return {
            bg: '#000000', border: '#1c1c1e',
            leftBubble: '#26262a', leftText: '#e9e9eb',
            rightBubble: '#0a84ff', rightText: '#ffffff',
            leftLabel: '#8e8e93', rightLabel: '#0a84ff'
        };
    }

    function obeliskChatBubbleHTML(text, side, theme, isPreview) {
        const isRight = side === 'right';
        const bg = isRight ? theme.rightBubble : theme.leftBubble;
        const color = isRight ? theme.rightText : theme.leftText;
        const radius = isRight
            ? '16px 16px 4px 16px'
            : '16px 16px 16px 4px';

        return `
        <div style="display:flex; justify-content:${isRight ? 'flex-end' : 'flex-start'};">
            <div style="max-width:${isPreview ? '90%' : '75%'}; background:${bg}; color:${color}; padding:${isPreview ? '6px 10px' : '10px 14px'}; border-radius:${radius}; font-size:${isPreview ? '.75em' : '.95em'}; line-height:1.4; box-shadow:0 2px 6px rgba(0,0,0,.3);">
                ${escapeHTML(text)}
            </div>
        </div>`;
    }

    // ============================================================
    // 8. PANEL
    // ============================================================

    const injectObelisk = () => {

        if (
            document.querySelector(
                '#obelisk-panel'
            )
        ) {
            return;
        }

        panel =
            document.createElement('aside');

        panel.id =
            'obelisk-panel';

        panel.style.setProperty(
            '--obelisk-accent',
            accentColor
        );

        const momoiSrc = chrome.runtime.getURL('momoi-dancing-avatar.gif');

        panel.innerHTML = `
            <img src="${momoiSrc}" class="obelisk-mascot" alt="Momoi" />
            <div class="obelisk-panel-inner">

                <header class="obelisk-header">

                    <div class="obelisk-brand">
                        <div class="obelisk-brand-mark">
                            ◆
                        </div>

                        <div>
                            <div class="obelisk-brand-title">
                                OBELISK
                            </div>

                            <div class="obelisk-brand-subtitle">
                                CLANK LAYOUT BUILDER
                            </div>
                        </div>
                    </div>

                    <div class="obelisk-header-status">
                        <span></span>
                        ONLINE
                    </div>

                </header>

                <div class="obelisk-theme-card">

                    <div class="obelisk-theme-heading">
                        <span>THEME ACCENT</span>

                        <output
                            id="obelisk-color-value"
                        >
                            ${escapeHTML(
                                accentColor
                            )}
                        </output>
                    </div>

                    <div class="obelisk-theme-controls">

                        <input
                            id="obelisk-color"
                            type="color"
                            value="${escapeHTML(
                                accentColor
                            )}"
                        >

                        <div class="obelisk-color-presets">

                            ${[
                                '#c4a35a',
                                '#b56cff',
                                '#5da9ff',
                                '#5de0b5',
                                '#e66b8f',
                                '#e6e6e6'
                            ]
                                .map(
                                    color => `
                                        <button
                                            type="button"
                                            class="obelisk-color-preset"
                                            data-color="${color}"
                                            style="
                                                --preset:${color};
                                            "
                                            aria-label="${color}"
                                        ></button>
                                    `
                                )
                                .join('')}

                        </div>

                    </div>

                </div>

                <div class="obelisk-search-wrap">

                    <span class="obelisk-search-icon">
                        /
                    </span>

                    <input
                        id="obelisk-search"
                        type="search"
                        placeholder="Search tools..."
                        autocomplete="off"
                        spellcheck="false"
                    >

                    <kbd>/</kbd>

                </div>

                <div
                    id="obelisk-tool-area"
                    class="obelisk-tool-area"
                ></div>

                <footer class="obelisk-footer">

                    <span>
                        OBELISK
                    </span>

                    <span class="obelisk-footer-status">
                        ${tools.length} TOOLS READY
                    </span>

                </footer>

            </div>

            <button
                id="obelisk-toggle"
                class="obelisk-toggle"
                type="button"
                aria-label="Toggle Obelisk"
            >
                <span>◆</span>
            </button>
        `;

        applyAccent(
            accentColor
        );

        wirePanel();

        renderTools();

        document.body.appendChild(
            panel
        );
    };

    // ============================================================
    // 9. TOOL RENDERING
    // ============================================================

    const toolArea =
        () => panel?.querySelector(
            '#obelisk-tool-area'
        );

    const searchInput =
        () => panel?.querySelector(
            '#obelisk-search'
        );

    const renderTools = (
        filter = ''
    ) => {

        const area =
            toolArea();

        if (!area) {
            return;
        }

        const query =
            filter
                .trim()
                .toLowerCase();

        area.innerHTML = '';

        const visible =
            tools.filter(tool => {

                const meta =
                    obeliskMeta[
                        tool.name
                    ] || {};

                return (
                    !query ||
                    tool.name
                        .toLowerCase()
                        .includes(query) ||
                    String(
                        meta.category
                    )
                        .toLowerCase()
                        .includes(query) ||
                    String(
                        meta.description
                    )
                        .toLowerCase()
                        .includes(query)
                );
            });

        const groups = {};

        visible.forEach(tool => {

            const meta =
                obeliskMeta[
                    tool.name
                ] || {
                    category:
                        'TOOLS',
                    description:
                        '',
                    icon:
                        '◆'
                };

            (
                groups[
                    meta.category
                ] ||= []
            ).push({
                tool,
                meta
            });
        });

        const order = [
            'DECORATION',
            'MEDIA',
            'LAYOUT',
            'DATA',
            'TEXT',
            'CONTENT',
            'CALLOUT',
            'CHARACTERS',
            'DIALOGUE',
            'SOCIAL',
            'THEMES'
        ];

        Object.keys(groups)
            .sort(
                (a, b) =>
                    order.indexOf(a) -
                    order.indexOf(b)
            )
            .forEach(
                category => {

                    const section =
                        document.createElement(
                            'section'
                        );

                    section.className =
                        'obelisk-tool-section';

                    const heading =
                        document.createElement(
                            'div'
                        );

                    heading.className =
                        'obelisk-category-title';

                    heading.innerHTML = `
                        <span>
                            ${escapeHTML(
                                category
                            )}
                        </span>

                        <i></i>
                    `;

                    section.appendChild(
                        heading
                    );

                    const grid =
                        document.createElement(
                            'div'
                        );

                    grid.className =
                        'obelisk-tool-grid';

                    groups[
                        category
                    ].forEach(
                        ({
                            tool,
                            meta
                        }) => {

                            const button =
                                document.createElement(
                                    'button'
                                );

                            button.className =
                                'obelisk-tool-card';

                            button.type =
                                'button';

                            button.innerHTML = `
                                <span
                                    class="obelisk-tool-icon"
                                >
                                    ${obeliskEsc(
                                        meta.icon
                                    )}
                                </span>

                                <span
                                    class="obelisk-tool-copy"
                                >
                                    <strong>
                                        ${obeliskEsc(
                                            tool.name.replace(
                                                /^[^A-Za-z]+/,
                                                ''
                                            )
                                        )}
                                    </strong>

                                    <small>
                                        ${obeliskEsc(
                                            meta.description
                                        )}
                                    </small>
                                </span>

                                <span
                                    class="obelisk-tool-arrow"
                                >
                                    ›
                                </span>
                            `;

                            button.addEventListener(
                                'click',
                                event => {

                                    event.preventDefault();

                                    openModal(
                                        tool
                                    );
                                }
                            );

                            grid.appendChild(
                                button
                            );
                        }
                    );

                    section.appendChild(
                        grid
                    );

                    area.appendChild(
                        section
                    );
                }
            );

        if (!visible.length) {

            area.innerHTML = `
                <div class="obelisk-empty">

                    <div class="obelisk-empty-mark">
                        ◇
                    </div>

                    <strong>
                        NO TOOLS FOUND
                    </strong>

                    <span>
                        Try a different search.
                    </span>

                </div>
            `;
        }
    };

    // ============================================================
    // 10. PANEL EVENTS
    // ============================================================

    const wirePanel = () => {

        const toggle =
            panel.querySelector(
                '#obelisk-toggle'
            );

        toggle?.addEventListener(
            'click',
            event => {

                event.preventDefault();

                panel.classList.toggle(
                    'obelisk-open'
                );
            }
        );

        const colorInput =
            panel.querySelector(
                '#obelisk-color'
            );

        const colorValue =
            panel.querySelector(
                '#obelisk-color-value'
            );

        colorInput?.addEventListener(
            'input',
            () => {

                applyAccent(
                    colorInput.value
                );

                if (colorValue) {
                    colorValue.textContent =
                        colorInput.value;
                }
            }
        );

        panel
            .querySelectorAll(
                '.obelisk-color-preset'
            )
            .forEach(
                button => {

                    button.addEventListener(
                        'click',
                        () => {

                            const color =
                                button.dataset
                                    .color;

                            colorInput.value =
                                color;

                            applyAccent(
                                color
                            );

                            if (colorValue) {
                                colorValue.textContent =
                                    color;
                            }
                        }
                    );
                }
            );

        const search =
            panel.querySelector(
                '#obelisk-search'
            );

        search?.addEventListener(
            'input',
            () => {

                renderTools(
                    search.value
                );
            }
        );
    };

    // ============================================================
    // 11. KEYBOARD
    // ============================================================

    document.addEventListener(
        'keydown',
        event => {

            if (
                event.key === '/' &&
                document.activeElement !==
                    searchInput() &&
                panel?.classList.contains(
                    'obelisk-open'
                ) &&
                !activeModal
            ) {

                event.preventDefault();

                searchInput()?.focus();

                return;
            }

            if (
                event.key === 'Escape'
            ) {

                if (activeModal) {
                    closeModal();
                    return;
                }

                if (
                    panel?.classList.contains(
                        'obelisk-open'
                    )
                ) {

                    const search =
                        searchInput();

                    if (search) {
                        search.value = '';
                        search.blur();
                    }

                    renderTools();
                }
            }

            if (
                event.ctrlKey &&
                event.key === 'Enter' &&
                activeModal
            ) {

                const submit =
                    activeModal.querySelector(
                        '[data-obelisk-submit]'
                    );

                submit?.click();
            }
        }
    );

    // ============================================================
    // 12. INTRO SEQUENCE & ROUTER
    // ============================================================

    let wasEditPage = false; // Tracks our state so the intro doesn't loop endlessly

    const playIntro = () => {
        // Removed the memory cache! This will now play every time you enter the edit page.
        const intro = document.createElement('div');
        intro.className = 'obelisk-intro-overlay';
        intro.style.setProperty('--obelisk-accent', accentColor);

        intro.innerHTML = `
            <div class="obelisk-intro-content">
                <div class="obelisk-intro-logo">◆</div>
                <div class="obelisk-intro-text">
                    <span class="obelisk-intro-type">[ OBELISK ENGINE ONLINE // EDIT MODE DETECTED ]</span>
                </div>
            </div>
        `;

        document.body.appendChild(intro);

        // Remove overlay smoothly after the boot sequence finishes
        setTimeout(() => {
            intro.classList.add('obelisk-intro-fade');
            setTimeout(() => intro.remove(), 800);
        }, 2800);
    };

    const checkRoute = () => {
        // Check if the current URL contains "/edit/"
        const isEditPage = window.location.href.includes('/edit/');
        const panelEl = document.querySelector('#obelisk-panel');

        if (isEditPage) {
            // If we just crossed the boundary INTO an edit page, trigger the sequence!
            if (!wasEditPage) {
                wasEditPage = true;
                
                if (!panelEl) {
                    injectObelisk(); // Inject the panel if it doesn't exist yet
                } else {
                    panelEl.classList.remove('obelisk-hidden-route'); // Unhide it if it does
                }
                
                playIntro(); // Fire the intro animation!
            }
        } else {
            // If we crossed the boundary OUT of an edit page, hide everything
            if (wasEditPage) {
                wasEditPage = false;
                if (panelEl) {
                    panelEl.classList.add('obelisk-hidden-route');
                    closeModal(); // Close any open tool windows just in case
                }
            }
        }
    };

    // ============================================================
    // 13. INITIALIZATION & WATCHER
    // ============================================================

    const initialize = () => {
        if (!document.body) {
            setTimeout(initialize, 500);
            return;
        }
        // Run the route check immediately on load
        checkRoute();
    };

    initialize();

    // Constantly monitor for URL changes (Single Page App friendly)
    setInterval(checkRoute, 1000);

})();