"use strict";

/*
    Home Workspace

    Home is a status dashboard, not another settings page. It summarizes the
    current conversation and gives the user short paths back into the tools
    they are most likely to use.
*/

(() => {

    const Atelier = window.ClankAtelier;
    const { createElement } = Atelier.PanelUI;

    function themeSummary() {
        const manager = Atelier.ThemeManager;

        if (!manager) {
            return {
                value: "Unavailable",
                meta: "Theme engine is not ready."
            };
        }

        const presetId = manager.settings?.preset;
        const preset = Atelier.THEME_PRESETS?.[presetId];
        const presetName = preset?.name ||
            (presetId === "custom" ? "Custom theme" : "Current theme");

        return {
            value: presetName,
            meta: manager.scope === "conversation"
                ? "Conversation override"
                : "Global theme"
        };
    }

    function sceneSummary() {
        const parts = [];
        const atmosphere = Atelier.AtmosphereManager;
        const ambience = Atelier.AmbienceManager;
        const stickers = Atelier.StickerManager;

        if (atmosphere?.settings?.enabled) {
            const label = String(atmosphere.settings.effect || "effect")
                .replace(/(^|[_-])(\w)/g, (_, prefix, letter) =>
                    `${prefix ? " " : ""}${letter.toUpperCase()}`
                );
            parts.push(label.trim());
        }

        if (stickers?.stickers?.length) {
            parts.push(
                `${stickers.stickers.length} sticker${
                    stickers.stickers.length === 1 ? "" : "s"
                }`
            );
        }

        if (ambience?.settings?.url) {
            parts.push(
                ambience.isPlaying?.()
                    ? "Music playing"
                    : "Music loaded"
            );
        }

        return {
            value: parts.length ? parts.join(" · ") : "Quiet",
            meta: parts.length
                ? "Conversation scene tools"
                : "No atmosphere, stickers, or music active"
        };
    }

    function directorSummary() {
        const manager = Atelier.DirectorManager;

        if (!manager) {
            return {
                value: "Unavailable",
                meta: "Director engine is not ready."
            };
        }

        const structured = Array.isArray(manager.settings?.notes)
            ? manager.settings.notes.filter(note => note?.enabled).length
            : 0;
        const base = String(manager.settings?.note || "").trim() ? 1 : 0;
        const total = structured + base;

        return {
            value: manager.settings?.enabled ? "Enabled" : "Off",
            meta: total
                ? `${total} active reminder${total === 1 ? "" : "s"}`
                : "No active notes"
        };
    }

    function readerSummary() {
        const manager = Atelier.ReaderManager;

        if (!manager) {
            return {
                value: "Unavailable",
                meta: "Reader engine is not ready."
            };
        }

        return {
            value: manager.focusMode
                ? "Focus Mode"
                : manager.settings?.enabled
                    ? "Reader Mode"
                    : "Off",
            meta: manager.settings?.enabled
                ? "Reading preferences are active"
                : "Normal chat layout"
        };
    }

    function createStatusCard(config) {
        const card = createElement("button", "furina-home-card");
        card.type = "button";
        card.addEventListener("click", () => {
            Atelier.PanelShell?.navigate?.(config.workspace, config.tool);
        });

        const top = createElement("div", "furina-home-card-top");
        const icon = createElement("span", "furina-home-card-icon", config.icon);
        icon.setAttribute("aria-hidden", "true");
        const label = createElement("span", "furina-home-card-label", config.label);
        const arrow = createElement("span", "furina-home-card-arrow", "→");
        arrow.setAttribute("aria-hidden", "true");
        top.append(icon, label, arrow);

        const value = createElement("div", "furina-home-card-value", config.value);
        const meta = createElement("div", "furina-home-card-meta", config.meta);

        card.append(top, value, meta);
        return card;
    }

    function createHomeWorkspace() {
        const root = createElement("div", "furina-home");

        const intro = createElement("div", "furina-home-intro");
        intro.append(
            createElement("div", "furina-home-kicker", "CURRENT CHAT"),
            createElement(
                "div",
                "furina-home-heading",
                "Your conversation at a glance"
            ),
            createElement(
                "div",
                "furina-home-copy",
                "Open a card to jump directly into that part of the Atelier."
            )
        );

        const theme = themeSummary();
        const scene = sceneSummary();
        const director = directorSummary();
        const reader = readerSummary();

        const grid = createElement("div", "furina-home-grid");
        grid.append(
            createStatusCard({
                icon: "◈",
                label: "Look",
                value: theme.value,
                meta: theme.meta,
                workspace: "look",
                tool: Atelier.PanelState.navigation.tools.look || "themes"
            }),
            createStatusCard({
                icon: "✦",
                label: "Scene",
                value: scene.value,
                meta: scene.meta,
                workspace: "scene",
                tool: Atelier.PanelState.navigation.tools.scene || "atmosphere"
            }),
            createStatusCard({
                icon: "◆",
                label: "Director",
                value: director.value,
                meta: director.meta,
                workspace: "director"
            }),
            createStatusCard({
                icon: "▤",
                label: "Reader",
                value: reader.value,
                meta: reader.meta,
                workspace: "scene",
                tool: "reader"
            })
        );

        const recent = Atelier.PanelState.navigation.lastNonHome;
        const recentLabel = Atelier.WorkspaceRouter?.describeView?.(
            recent.workspace,
            recent.tool
        );

        const resume = createElement("div", "furina-home-resume");
        const resumeText = createElement("div", "furina-home-resume-text");
        resumeText.append(
            createElement("div", "furina-home-kicker", "RESUME"),
            createElement(
                "div",
                "furina-home-resume-title",
                recentLabel || "Look · Themes"
            )
        );

        const resumeButton = createElement(
            "button",
            "furina-secondary-button furina-home-resume-button",
            "Open last tool"
        );
        resumeButton.type = "button";
        resumeButton.addEventListener("click", () => {
            Atelier.PanelShell?.navigate?.(
                recent.workspace || "look",
                recent.tool || "themes"
            );
        });

        resume.append(resumeText, resumeButton);
        root.append(intro, grid, resume);

        return root;
    }

    Atelier.HomeWorkspace = {
        create: createHomeWorkspace
    };

})();
