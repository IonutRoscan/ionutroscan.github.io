"use strict";

/*
    Chat Appearance Panel Section

    Renders controls for chat background, width, avatars, spacing, and compact mode.
*/

(() => {

    const Atelier = window.ClankAtelier;
    const UI = Atelier.PanelUI;
    const State = Atelier.PanelState;
    const Sections = Atelier.PanelSections;

    const {
        createElement,
        createRangeControl,
        createTextControl,
        createSelectControl,
        createColorControl,
        createSection
    } = UI;

    // ── CHAT SECTION ──────────────────────────────────────────────

    function createChatSection() {

        const section =
            createSection(
                "Chat"
            );


        const accent =
            createColorControl(
                "Accent",
                "accent"
            );


        const backgroundMode =
            createSelectControl({

                label:
                    "Background type",

                key:
                    "chatBackgroundMode",

                options: [

                    {
                        label:
                            "Solid",

                        value:
                            "solid"
                    },

                    {
                        label:
                            "Gradient",

                        value:
                            "gradient"
                    },

                    {
                        label:
                            "Image",

                        value:
                            "image"
                    },

                    {
                        label:
                            "Video",

                        value:
                            "video"
                    }

                ]

            });


        const background =
            createColorControl(
                "Background color",
                "chatBackground"
            );


        // --------------------------------------------------------
        // GRADIENT CONTROLS
        // --------------------------------------------------------

        const gradientControls =
            createElement(
                "div",
                "furina-conditional-group"
            );


        const gradientColor =
            createColorControl(
                "Gradient color",
                "chatGradientColor"
            );


        const gradientAngle =
            createRangeControl({

                label:
                    "Gradient angle",

                key:
                    "chatGradientAngle",

                min:
                    0,

                max:
                    360,

                step:
                    5,

                format:
                    value =>
                        `${value}°`

            });


        gradientControls.append(
            gradientColor.wrapper,
            gradientAngle.wrapper
        );


        // --------------------------------------------------------
        // IMAGE CONTROLS
        // --------------------------------------------------------

        const imageControls =
            createElement(
                "div",
                "furina-conditional-group"
            );


        const imageUrl =
            createTextControl({

                label:
                    "Image URL",

                key:
                    "chatImageUrl",

                placeholder:
                    "https://example.com/background.jpg"

            });
        
        const videoUrl =
            createTextControl({

                label:
                    "Video URL",

                key:
                    "chatVideoUrl",

                placeholder:
                    "https://example.com/background.mp4"

            });

        const imageFit =
            createSelectControl({

                label:
                    "Background fit",

                key:
                    "chatImageFit",

                options: [

                    {
                        label:
                            "Cover",

                        value:
                            "cover"
                    },

                    {
                        label:
                            "Contain",

                        value:
                            "contain"
                    },

                    {
                        label:
                            "Original / Auto",

                        value:
                            "auto"
                    }

                ]

            });


        const imagePosition =
            createSelectControl({

                label:
                    "Background position",

                key:
                    "chatImagePosition",

                options: [

                    {
                        label:
                            "Center",

                        value:
                            "center"
                    },

                    {
                        label:
                            "Top",

                        value:
                            "center top"
                    },

                    {
                        label:
                            "Bottom",

                        value:
                            "center bottom"
                    },

                    {
                        label:
                            "Left",

                        value:
                            "left center"
                    },

                    {
                        label:
                            "Right",

                        value:
                            "right center"
                    },

                    {
                        label:
                            "Top left",

                        value:
                            "left top"
                    },

                    {
                        label:
                            "Top right",

                        value:
                            "right top"
                    },

                    {
                        label:
                            "Bottom left",

                        value:
                            "left bottom"
                    },

                    {
                        label:
                            "Bottom right",

                        value:
                            "right bottom"
                    }

                ]

            });


        const imageDarkness =
            createRangeControl({

                label:
                    "Background darkness",

                key:
                    "chatImageDarkness",

                min:
                    0,

                max:
                    0.9,

                step:
                    0.05,

                format:
                    value =>
                        `${Math.round(
                            value * 100
                        )}%`

            });
        
        const overlayColor =
            createColorControl(
                "Overlay tint",
                "chatImageOverlayColor"
            );


        const overlayOpacity =
            createRangeControl({

                label:
                    "Overlay strength",

                key:
                    "chatImageOverlayOpacity",

                min:
                    0,

                max:
                    0.9,

                step:
                    0.05,

                format:
                    value =>
                        `${Math.round(
                            value * 100
                        )}%`

            });


        const vignette =
            createRangeControl({

                label:
                    "Vignette",

                key:
                    "chatImageVignette",

                min:
                    0,

                max:
                    1,

                step:
                    0.05,

                format:
                    value =>
                        `${Math.round(
                            value * 100
                        )}%`

            });


        const imageBlur =
            createRangeControl({

                label:
                    "Background blur",

                key:
                    "chatImageBlur",

                min:
                    0,

                max:
                    20,

                step:
                    1,

                format:
                    value =>
                        `${value}px`

            });


        imageControls.append(
            imageUrl.wrapper,
            videoUrl.wrapper,
            imageFit.wrapper,
            imagePosition.wrapper,
            imageDarkness.wrapper,
            overlayColor.wrapper,
            overlayOpacity.wrapper,
            vignette.wrapper,
            imageBlur.wrapper
        );


        // --------------------------------------------------------
        // CHAT LAYOUT
        // --------------------------------------------------------

        const width =
            createRangeControl({

                label:
                    "Chat width",

                key:
                    "messageWidth",

                min:
                    520,

                max:
                    1000,

                step:
                    10,

                format:
                    value =>
                        `${value}px`

            });


        const avatar =
            createRangeControl({

                label:
                    "Avatar size",

                key:
                    "avatarSize",

                min:
                    28,

                max:
                    84,

                step:
                    2,

                format:
                    value =>
                        `${value}px`

            });


        const messageSpacing =
            createRangeControl({

                label:
                    "Message spacing",

                key:
                    "messageSpacing",

                min:
                    0,

                max:
                    32,

                step:
                    1,

                format:
                    value =>
                        `${value}px`

            });


        section.furinaContent.append(
            accent.wrapper,
            backgroundMode.wrapper,
            background.wrapper,
            gradientControls,
            imageControls,
            width.wrapper,
            avatar.wrapper,
            messageSpacing.wrapper
        );


        // --------------------------------------------------------
        // BACKGROUND CONTROL VISIBILITY
        // --------------------------------------------------------

        function updateBackgroundControls() {

            const mode =
                backgroundMode.select.value;


            gradientControls.hidden =
                mode !==
                "gradient";


            imageControls.hidden =
                mode !==
                    "image" &&
                mode !==
                    "video";


            imageUrl.wrapper.hidden =
                mode !==
                "image";


            videoUrl.wrapper.hidden =
                mode !==
                "video";

        }


        backgroundMode.select
            .addEventListener(
                "change",
                updateBackgroundControls
            );


        updateBackgroundControls();


        // --------------------------------------------------------
        // COMPACT MODE
        // --------------------------------------------------------

        const toggle =
            createElement(
                "label",
                "furina-toggle-row"
            );


        const toggleText =
            createElement(
                "div"
            );


        const toggleTitle =
            createElement(
                "div",
                "furina-toggle-title",
                "Compact mode"
            );


        const toggleDescription =
            createElement(
                "div",
                "furina-toggle-description",
                "Reduce message and control spacing."
            );


        toggleText.append(
            toggleTitle,
            toggleDescription
        );


        const checkbox =
            document.createElement(
                "input"
            );


        checkbox.type =
            "checkbox";


        checkbox.className =
            "furina-checkbox";


        checkbox.checked =
            Boolean(
                Atelier.ThemeManager
                    .settings
                    .compact
            );


        checkbox.addEventListener(
            "change",
            () => {

                Atelier.ThemeManager
                    .update(
                        "compact",
                        checkbox.checked
                    );

            }
        );


        toggle.append(
            toggleText,
            checkbox
        );


        section.furinaContent
            .appendChild(
                toggle
            );


        return section;

    }

    Sections.createChatSection =
        createChatSection;

})();
