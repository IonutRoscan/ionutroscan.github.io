"use strict";

/*
    Atelier Workspace Shell

    This is Furina's persistent application-style panel. The shell itself is
    created once. Navigation swaps only the active workspace content, so a
    small change in Stickers no longer rebuilds every unrelated panel tool.
*/

window.ClankAtelier = window.ClankAtelier || {};

(() => {

    const Atelier = window.ClankAtelier;
    const State = Atelier.PanelState;
    const Router = Atelier.WorkspaceRouter;
    const Navigation = Atelier.PanelNavigation;
    const { createElement } = Atelier.PanelUI;

    let panel = null;
    let launcher = null;
    let primaryNav = null;
    let workspaceTitle = null;
    let workspaceDescription = null;
    let secondaryNav = null;
    let workspaceScroll = null;
    let workspaceContent = null;
    let renderedViewKey = null;
    let initialized = false;

    function isChatRoute() {
        return window.location.pathname.startsWith("/chat/");
    }

    function cancelPortablePreviews() {
        if (State.themeBeforeImportPreview && Atelier.ThemeManager) {
            Atelier.ThemeManager.restorePreviewTheme(
                State.themeBeforeImportPreview
            );
        }

        State.pendingThemeImport = null;
        State.themeBeforeImportPreview = null;

        if (Atelier.SetupManager?.previewBackup) {
            Atelier.SetupManager.revertPreview();
        }

        State.pendingSetupImport = null;
    }

    function saveCurrentScroll() {
        if (!workspaceScroll || !renderedViewKey) {
            return;
        }

        State.ui.viewScroll[renderedViewKey] = workspaceScroll.scrollTop;
    }

    function restoreViewScroll(key) {
        if (!workspaceScroll) {
            return;
        }

        const value = Number(State.ui.viewScroll[key]) || 0;

        requestAnimationFrame(() => {
            if (workspaceScroll) {
                workspaceScroll.scrollTop = value;
            }
        });
    }

    function isPanelOpen() {
        return Boolean(
            panel && panel.classList.contains("furina-panel-open")
        );
    }

    function syncStickerEditing() {
        if (!Atelier.StickerManager) {
            return;
        }

        const active = Router.getActive();
        const shouldEdit = Boolean(
            isPanelOpen() &&
            active.workspace === "scene" &&
            active.tool === "stickers"
        );

        Atelier.StickerManager.setEditing(shouldEdit);
    }

    function refreshNavigation() {
        if (!panel) {
            return;
        }

        Navigation.renderPrimary(primaryNav);
        Navigation.renderSecondary(secondaryNav);
    }

    function renderActiveView({ preserveScroll = true } = {}) {
        if (!panel || !workspaceContent) {
            return;
        }

        if (preserveScroll) {
            saveCurrentScroll();
        }

        const active = Router.getActive();
        const key = Router.viewKey(active.workspace, active.tool);

        workspaceTitle.textContent =
            Atelier.I18n?.t
                ? Atelier.I18n.t(active.config.title)
                : active.config.title;

        workspaceDescription.textContent =
            Atelier.I18n?.t
                ? Atelier.I18n.t(active.config.description)
                : active.config.description;

        refreshNavigation();

        workspaceContent.replaceChildren(
            Router.renderView(active.workspace, active.tool)
        );

        workspaceContent.dataset.workspace = active.workspace;
        workspaceContent.dataset.tool = active.tool || "";

        renderedViewKey = key;
        restoreViewScroll(key);
        syncStickerEditing();
    }

    function navigate(workspace, tool = null) {
        saveCurrentScroll();

        if (!Router.navigate(workspace, tool)) {
            return;
        }

        renderActiveView({ preserveScroll: false });
    }

    function refreshLanguage() {

        /*
            Locale changes do not need to destroy the panel. The i18n layer
            can translate known UI text in either direction, so rebuilding
            only the active workspace keeps navigation, open state, and
            scroll behavior stable.
        */
        renderActiveView({
            preserveScroll: true
        });

        Atelier.I18n?.translateTree?.(
            panel
        );

        Atelier.I18n?.translateTree?.(
            launcher
        );

    }


    Atelier.PanelShell = {
        rebuild: () => renderActiveView(),
        refreshNavigation,
        navigate,
        open: () => openPanel(),
        close: () => closePanel(),
        getActiveView: () => Router.getActive(),
        refreshLanguage
    };

    function createPanelShell() {
        if (panel && document.body.contains(panel)) {
            return;
        }

        panel = createElement("aside", "furina-panel furina-atelier-workspace");
        panel.id = "furina-panel";
        panel.setAttribute("aria-label", Atelier.I18n?.t?.("Furina Clank Chat Atelier") || "Furina Clank Chat Atelier");
        panel.dataset.furinaOwned = "true";

        const header = createElement("header", "furina-panel-header");
        const branding = createElement("div", "furina-branding");
        branding.append(
            createElement("div", "furina-panel-title", "Furina"),
            createElement("div", "furina-panel-subtitle", "Clank Chat Atelier")
        );

                const headerActions =
            createElement(
                "div",
                "furina-panel-header-actions"
            );


        const guideButton =
            createElement(
                "button",
                "furina-guidebook-header-button",
                "?"
            );

        guideButton.type =
            "button";

        guideButton.title =
            "Open Furina Guidebook";

        guideButton.setAttribute(
            "aria-label",
            "Open Furina Guidebook"
        );

        guideButton.setAttribute(
            "aria-haspopup",
            "dialog"
        );

        guideButton.addEventListener(
            "click",
            () => {

                Atelier.GuideManager
                    ?.open?.(
                        "start",
                        guideButton
                    );

            }
        );


        const close =
            createElement(
                "button",
                "furina-close-button",
                "×"
            );

        close.type =
            "button";

        close.title =
            Atelier.I18n?.t?.(
                "Close"
            ) ||
            "Close";

        close.setAttribute(
            "aria-label",
            Atelier.I18n?.t?.(
                "Close Furina panel"
            ) ||
            "Close Furina panel"
        );

        close.addEventListener(
            "click",
            closePanel
        );


        headerActions.append(
            guideButton,
            close
        );

        header.append(
            branding,
            headerActions
        );

        const app = createElement("div", "furina-workspace-app");

        primaryNav = createElement("nav", "furina-primary-nav");
        primaryNav.setAttribute("aria-label", Atelier.I18n?.t?.("Furina workspaces") || "Furina workspaces");

        const workspace = createElement("main", "furina-workspace-main");
        const workspaceHeader = createElement(
            "div",
            "furina-workspace-header"
        );
        const headingArea = createElement(
            "div",
            "furina-workspace-heading-area"
        );
        workspaceTitle = createElement("h2", "furina-workspace-title");
        workspaceDescription = createElement(
            "div",
            "furina-workspace-description"
        );
        headingArea.append(workspaceTitle, workspaceDescription);

        secondaryNav = createElement("nav", "furina-secondary-nav");
        secondaryNav.setAttribute("aria-label", Atelier.I18n?.t?.("Workspace tools") || "Workspace tools");
        workspaceHeader.append(headingArea, secondaryNav);

        workspaceScroll = createElement(
            "div",
            "furina-workspace-scroll"
        );
        workspaceContent = createElement(
            "div",
            "furina-workspace-content"
        );
        workspaceScroll.appendChild(workspaceContent);

        workspace.append(workspaceHeader, workspaceScroll);
        app.append(primaryNav, workspace);
        panel.append(header, app);
        document.body.appendChild(panel);

        Atelier.I18n?.observeRoot?.(
            panel
        );

        renderActiveView({ preserveScroll: false });
    }

    function deactivateUI() {
        Atelier.StickerManager?.setEditing(false);

        if (panel) {
            panel.classList.remove("furina-panel-open");
            panel.style.display = "none";
        }

        if (launcher) {
            launcher.style.display = "none";
            launcher.setAttribute("aria-expanded", "false");
        }
    }

    function activateUI() {
        if (launcher) {
            launcher.style.display = "";
        }

        if (panel) {
            panel.style.display = "";
        }
    }

    function openPanel() {
        if (!isChatRoute()) {
            deactivateUI();
            return;
        }

        createPanelShell();
        activateUI();
        refreshNavigation();

        requestAnimationFrame(() => {
            panel?.classList.add("furina-panel-open");
            launcher?.setAttribute("aria-expanded", "true");
            syncStickerEditing();
        });
    }

    function closePanel() {
        if (!panel) {
            return;
        }

        saveCurrentScroll();
        panel.classList.remove("furina-panel-open");
        launcher?.setAttribute("aria-expanded", "false");
        Atelier.StickerManager?.setEditing(false);
    }

    function togglePanel() {
        if (!isChatRoute()) {
            deactivateUI();
            return;
        }

        if (isPanelOpen()) {
            closePanel();
        } else {
            openPanel();
        }
    }

    function createLauncher() {
        const existing = document.getElementById("furina-launcher");

        if (existing) {
            launcher = existing;
            return;
        }

        launcher = createElement("button", "furina-launcher");
        launcher.id = "furina-launcher";
        launcher.type = "button";
        launcher.title = Atelier.I18n?.t?.("Open Furina") || "Open Furina";
        launcher.setAttribute("aria-label", Atelier.I18n?.t?.("Open Furina customization panel") || "Open Furina customization panel");
        launcher.setAttribute("aria-controls", "furina-panel");
        launcher.setAttribute("aria-expanded", "false");
        launcher.dataset.furinaOwned = "true";

        const icon = createElement("span", "furina-launcher-icon", "✦");
        icon.setAttribute("aria-hidden", "true");
        const label = createElement("span", "furina-launcher-label", "Furina");
        launcher.append(icon, label);
        launcher.addEventListener("click", togglePanel);
        document.body.appendChild(launcher);

        Atelier.I18n?.observeRoot?.(
            launcher
        );
    }

    async function initializeManagers() {
        await Atelier.ThemeManager.init();

        const conversationId = typeof Atelier.getConversationId === "function"
            ? Atelier.getConversationId()
            : null;

        if (typeof Atelier.ReaderManager?.loadConversation === "function") {
            await Atelier.ReaderManager.loadConversation(conversationId);
        }

        if (
            typeof Atelier.SceneStateManager
                ?.loadConversation ===
                "function"
        ) {

            await Atelier.SceneStateManager
                .loadConversation(
                    conversationId
                );
        }

        if (typeof Atelier.ScenePresentationManager?.loadConversation === "function") {
            await Atelier.ScenePresentationManager.loadConversation(conversationId);
        }

        if (typeof Atelier.DirectorManager?.loadConversation === "function") {
            await Atelier.DirectorManager.loadConversation(conversationId);
        }

        if (typeof Atelier.ContinuityManager?.loadConversation === "function") {
            await Atelier.ContinuityManager.loadConversation(conversationId);
        }

        if (typeof Atelier.MemoryCaptureManager?.loadConversation === "function") {
            await Atelier.MemoryCaptureManager.loadConversation(conversationId);
        }

        if (typeof Atelier.Director2Manager?.loadConversation === "function") {
            await Atelier.Director2Manager.loadConversation(conversationId);
        }

        if (typeof Atelier.SceneIntelligenceManager?.loadConversation === "function") {
            await Atelier.SceneIntelligenceManager.loadConversation(conversationId);
        }

        if (typeof Atelier.AdvancedCssManager?.loadConversation === "function") {
            await Atelier.AdvancedCssManager.loadConversation(conversationId);
        }

        if (typeof Atelier.StickerManager?.loadLayouts === "function") {
            await Atelier.StickerManager.loadLayouts();
        }

        if (typeof Atelier.StickerManager?.loadLibrary === "function") {
            await Atelier.StickerManager.loadLibrary();
        }
    }

    async function initialize() {
        if (initialized || !isChatRoute()) {
            return;
        }

        if (!Atelier.Storage || !Atelier.ThemeManager || !Router) {
            console.error("[Clank Atelier] UI dependencies missing.");
            return;
        }

        initialized = true;

        if (
            typeof Atelier.I18n?.init ===
                "function"
        ) {
            await Atelier.I18n.init();
        }

        await initializeManagers();
        await Router.loadState();

        createLauncher();
        createPanelShell();
    }

    function tryInitialize() {
        if (!isChatRoute()) {
            deactivateUI();
            return;
        }

        const chat = document.querySelector(
            "#chat-scroll-container"
        );

        if (!chat) {
            deactivateUI();
            return;
        }

        if (!initialized) {
            initialize();
            return;
        }

        /*
            Normal Clank DOM mutations only need to make sure Furina is
            still available.

            Do NOT rebuild the navigation here. This function is called
            from the page-wide MutationObserver, and rebuilding the nav
            replaces its buttons while the user may be clicking them.

            That can cancel the browser's click event between pointerdown
            and pointerup.
        */

        activateUI();
    }

    let lastPath = window.location.pathname;
    let routeSyncInFlight = false;

    async function syncConversationForPanel() {
        if (!initialized || routeSyncInFlight) {
            return;
        }

        routeSyncInFlight = true;

        try {
            if (typeof Atelier.ThemeManager?.syncConversation === "function") {
                await Atelier.ThemeManager.syncConversation();
            }

            if (typeof Atelier.ReaderManager?.syncConversation === "function") {
                await Atelier.ReaderManager.syncConversation();
            }

            if (
                typeof Atelier.SceneStateManager
                    ?.syncConversation ===
                    "function"
            ) {

                await Atelier.SceneStateManager
                    .syncConversation();
            }

            if (typeof Atelier.ScenePresentationManager?.syncConversation === "function") {
                await Atelier.ScenePresentationManager.syncConversation();
            }

            if (typeof Atelier.DirectorManager?.syncConversation === "function") {
                await Atelier.DirectorManager.syncConversation();
            }

            if (typeof Atelier.ContinuityManager?.syncConversation === "function") {
                await Atelier.ContinuityManager.syncConversation();
            }

            if (typeof Atelier.MemoryCaptureManager?.syncConversation === "function") {
                await Atelier.MemoryCaptureManager.syncConversation();
            }

            if (typeof Atelier.Director2Manager?.syncConversation === "function") {
                await Atelier.Director2Manager.syncConversation();
            }

            if (typeof Atelier.SceneIntelligenceManager?.syncConversation === "function") {
                await Atelier.SceneIntelligenceManager.syncConversation();
            }

            if (panel) {
                renderActiveView();
            }
        } finally {
            routeSyncInFlight = false;
        }
    }

    async function checkRoute() {
        const currentPath = window.location.pathname;

        if (currentPath === lastPath) {
            return;
        }

        cancelPortablePreviews();
        lastPath = currentPath;

        if (initialized) {
            await syncConversationForPanel();
        }

        tryInitialize();
    }

    let uiSyncScheduled = false;

    function scheduleUiSync() {
        if (uiSyncScheduled) {
            return;
        }

        uiSyncScheduled = true;
        requestAnimationFrame(() => {
            uiSyncScheduled = false;
            checkRoute();
            tryInitialize();
        });
    }

    function isFurinaUiNode(node) {
        let element = node;

        if (element?.nodeType === Node.TEXT_NODE) {
            element = element.parentElement;
        }

        if (!(element instanceof HTMLElement)) {
            return false;
        }

        const selector = [
            "#furina-panel",
            "#furina-launcher",
            ".furina-ambience-player",
            ".furina-atmosphere-layer",
            ".furina-sticker-layer",
            ".clank-atelier-lightbox",
            ".clank-atelier-rendered",
            '[data-furina-owned="true"]',
            '[data-clank-atelier-owned="true"]'
        ].join(",");

        return Boolean(
            element.matches?.(selector) ||
            element.closest?.(selector)
        );
    }

    const observer = new MutationObserver(records => {
        const needsSync = records.some(record => {
            if (isFurinaUiNode(record.target)) {
                return false;
            }

            const changedNodes = [
                ...record.addedNodes,
                ...record.removedNodes
            ];

            return changedNodes.length === 0 ||
                changedNodes.some(node => !isFurinaUiNode(node));
        });

        if (needsSync) {
            scheduleUiSync();
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });

    window.addEventListener("popstate", async () => {
        cancelPortablePreviews();
        lastPath = window.location.pathname;
        await syncConversationForPanel();
        tryInitialize();
    });

    document.addEventListener(
        "furina-route-changed",
        () => {
            scheduleUiSync();
        }
    );

    document.addEventListener(
        "furina-language-changed",
        () => {
            if (!initialized) {
                return;
            }

            refreshLanguage();
        }
    );


    tryInitialize();

})();
