"use strict";

/*
    Storage Adapter

    Wraps chrome.storage.local with safe fallbacks and serialized object updates so overlapping feature saves do not accidentally overwrite one another.
*/

window.ClankAtelier =
    window.ClankAtelier || {};


// ============================================================
// STORAGE
// ============================================================

window.ClankAtelier.Storage = {

    _writeQueues:
        new Map(),


    async get(
        key,
        fallback = null
    ) {

        try {

            const result =
                await chrome.storage.local.get(
                    key
                );


            if (
                result[key] === undefined
            ) {

                return fallback;

            }


            return result[key];

        } catch (
            error
        ) {

            console.warn(
                "[Clank Atelier] Storage read failed:",
                error
            );


            return fallback;

        }

    },


    async getObject(
        key,
        fallback = {}
    ) {

        const value =
            await this.get(
                key,
                fallback
            );


        if (
            !value ||
            typeof value !==
                "object" ||
            Array.isArray(
                value
            )
        ) {

            return fallback;

        }


        return value;

    },


    async getArray(
        key,
        fallback = []
    ) {

        const value =
            await this.get(
                key,
                fallback
            );


        return Array.isArray(
            value
        )
            ? value
            : fallback;

    },


    async updateObject(
        key,
        updater
    ) {

        if (
            typeof updater !==
                "function"
        ) {
            return false;
        }


        const previous =
            this._writeQueues.get(
                key
            ) ||
            Promise.resolve();


        const operation =
            previous
                .catch(
                    () => undefined
                )
                .then(
                    async () => {

                        const performUpdate =
                            async () => {

                                const current =
                                    await this.getObject(
                                        key,
                                        {}
                                    );


                                const result =
                                    updater(
                                        current
                                    );


                                const nextValue =
                                    result &&
                                    typeof result ===
                                        "object" &&
                                    !Array.isArray(
                                        result
                                    )
                                        ? result
                                        : current;


                                return await this.set(
                                    key,
                                    nextValue
                                );

                            };


                        /*
                            Web Locks coordinate the read-modify-write
                            sequence across multiple Clank tabs when the
                            browser exposes the API (Clank is HTTPS).

                            The in-memory queue above remains the fallback
                            and also keeps same-tab writes ordered.
                        */

                        if (
                            typeof navigator !==
                                "undefined" &&
                            navigator.locks &&
                            typeof navigator.locks
                                .request ===
                                "function"
                        ) {

                            return await navigator
                                .locks
                                .request(
                                    `furina-storage:${key}`,
                                    {
                                        mode:
                                            "exclusive"
                                    },
                                    performUpdate
                                );

                        }


                        return await performUpdate();

                    }
                );


        this._writeQueues.set(
            key,
            operation
        );


        try {

            return await operation;

        } finally {

            if (
                this._writeQueues.get(
                    key
                ) ===
                operation
            ) {

                this._writeQueues.delete(
                    key
                );

            }

        }

    },


    async set(
        key,
        value
    ) {

        try {

            await chrome.storage.local.set({
                [key]:
                    value
            });


            return true;

        } catch (
            error
        ) {

            console.warn(
                "[Clank Atelier] Storage write failed:",
                error
            );


            return false;

        }

    },


    async remove(
        key
    ) {

        try {

            await chrome.storage.local.remove(
                key
            );


            return true;

        } catch (
            error
        ) {

            console.warn(
                "[Clank Atelier] Storage remove failed:",
                error
            );


            return false;

        }

    }

};